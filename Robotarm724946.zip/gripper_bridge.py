"""
gripper_bridge.py — serial interface to the Nano gripper controller.

Mirrors serial_bridge.py's shape (connect / disconnect / send-and-wait-for-ok)
so it drops into the existing architecture, but talks the ARMGRIP protocol
from nano_gripper/nano_gripper.ino rather than grbl G-code.

This is a SECOND, independent serial connection — the Nano is a separate board
from the Uno running grbl4axis. That's deliberate: grbl owns Timer1 for step
generation so the Servo library can't coexist with it, and the Uno's flash is
nearly full with the 4-axis fork already.

Synchronisation note: because the two boards are independent, a gripper
command issued while grbl still has moves buffered would fire early. For
coordinated sequences the caller must wait until grbl reports Idle first —
see the waypoint integration (not yet built). For manual open/close from the
UI this doesn't arise, since the user is driving one thing at a time.

Protocol summary (see nano_gripper/README.md for the full table):
    V?              identify   -> "ARMGRIP v1 servos=4 pca=ok"
    ?               status     -> "<idle ch=0 pos=90.0 ... >"
    A[angle]        attach, optionally declaring the assumed current angle
    D               detach (limp)
    O / C           open / close preset
    S<a> [T<ms>]    move to angle, optional duration
    R / L / E / U   rate / limits / presets / pulse range
    X / Z           emergency output kill / restore
Every command answers "ok" or "err:<reason>".
"""

import time

import serial
import serial.tools.list_ports

import config


IDENTIFY_TOKEN = "ARMGRIP"


class GripperBridgeError(RuntimeError):
    pass


class GripperCommandError(GripperBridgeError):
    """Raised when the firmware answers err:<reason> to a command."""
    def __init__(self, command, reason):
        super().__init__(f"{command!r} rejected: {reason}")
        self.command = command
        self.reason = reason


class GripperBridge:
    def __init__(self):
        self._ser = None
        self.startup_banner = []
        self.last_status = ""
        self.firmware_id = ""

    # -- connection management ------------------------------------------------

    @staticmethod
    def list_ports():
        """[(label, device), ...] for every serial port currently present."""
        ports = []
        for p in serial.tools.list_ports.comports():
            label = f"{p.device} — {p.description}"
            ports.append((label, p.device))
        return ports

    def is_connected(self):
        return self._ser is not None and self._ser.is_open

    def connect(self, port, baud=None, timeout=2.0):
        if baud is None:
            baud = config.GRIPPER_DEFAULT_BAUD
        if self.is_connected():
            self.disconnect()
        try:
            self._ser = serial.Serial(port, baud, timeout=timeout)
        except serial.SerialException as e:
            self._ser = None
            raise GripperBridgeError(f"Failed to open {port}: {e}") from e

        # The Nano auto-resets on serial open (DTR), then prints its identify
        # banner once setup() runs. Capture it — it also tells us whether the
        # PCA9685 answered on the I2C bus, which is the single most useful
        # thing to know before trying to move anything.
        self.startup_banner = []
        deadline = time.time() + 3.0
        time.sleep(1.5)          # let the bootloader and setup() finish
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line:
                    self.startup_banner.append(line)
            else:
                time.sleep(0.05)

        for line in self.startup_banner:
            if IDENTIFY_TOKEN in line:
                self.firmware_id = line
                break

    def disconnect(self):
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:
                pass
        self._ser = None
        self.firmware_id = ""

    # -- low-level I/O --------------------------------------------------------

    def send_line(self, line, timeout=3.0):
        """
        Send one command and collect reply lines up to the terminating
        'ok' / 'err:'. Returns the list of lines received (including the
        terminator). Raises GripperCommandError if the firmware rejected it.
        """
        if not self.is_connected():
            raise GripperBridgeError("Not connected to the gripper controller.")

        payload = (line.strip() + "\n").encode("utf-8")
        try:
            self._ser.reset_input_buffer()
            self._ser.write(payload)
            self._ser.flush()
        except serial.SerialException as e:
            raise GripperBridgeError(f"Write failed: {e}") from e

        received = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                raw = self._ser.readline()
            except serial.SerialException as e:
                raise GripperBridgeError(f"Read failed: {e}") from e
            if not raw:
                continue
            text = raw.decode("utf-8", errors="replace").strip()
            if not text:
                continue
            received.append(text)
            if text == "ok":
                return received
            if text.startswith("err:"):
                raise GripperCommandError(line.strip(), text[4:])

        raise GripperBridgeError(
            f"Timed out waiting for a reply to {line.strip()!r} "
            f"(got: {received if received else 'nothing'})")

    # -- identification / discovery ------------------------------------------

    def identify(self):
        """Ask the board what it is. Returns the identify line."""
        lines = self.send_line("V?")
        for line in lines:
            if IDENTIFY_TOKEN in line:
                self.firmware_id = line
                return line
        return ""

    def pca_ok(self):
        """True if the firmware reported the PCA9685 responding on I2C.
        A False here is why 'the servo does nothing' — it's a wiring or
        address problem, not a command problem."""
        return "pca=ok" in (self.firmware_id or "")

    @classmethod
    def auto_detect(cls, baud=None, exclude=()):
        """
        Probe each serial port for the ARMGRIP identify banner and return the
        first device that answers. Saves picking the right COM port by trial
        and error when both Arduinos are plugged in.

        exclude: device names to skip (e.g. the port grbl is already on).
        Returns (device, identify_line) or (None, None).
        """
        for _label, device in cls.list_ports():
            if device in exclude:
                continue
            probe = cls()
            try:
                probe.connect(device, baud=baud)
                ident = probe.identify()
                if IDENTIFY_TOKEN in ident:
                    return device, ident
            except (GripperBridgeError, serial.SerialException):
                pass
            finally:
                probe.disconnect()
        return None, None

    # -- commands -------------------------------------------------------------

    @staticmethod
    def _prefix(channel):
        return "" if not channel else f"@{int(channel)} "

    def status(self, channel=0):
        """Query firmware status. Returns the raw '<...>' line."""
        lines = self.send_line(self._prefix(channel) + "?")
        for line in lines:
            if line.startswith("<"):
                self.last_status = line
                return line
        return ""

    def attach(self, angle=None, channel=0):
        cmd = self._prefix(channel) + "A"
        if angle is not None:
            cmd += f"{float(angle):.1f}"
        return self.send_line(cmd)

    def detach(self, channel=0):
        return self.send_line(self._prefix(channel) + "D")

    def open_gripper(self, channel=0):
        return self.send_line(self._prefix(channel) + "O")

    def close_gripper(self, channel=0):
        return self.send_line(self._prefix(channel) + "C")

    def move_to(self, angle, duration_ms=None, channel=0):
        cmd = self._prefix(channel) + f"S{float(angle):.1f}"
        if duration_ms is not None:
            cmd += f" T{int(duration_ms)}"
        return self.send_line(cmd)

    def set_rate(self, deg_per_sec, channel=0):
        return self.send_line(self._prefix(channel) + f"R{float(deg_per_sec):.1f}")

    def set_limits(self, min_angle, max_angle, channel=0):
        return self.send_line(
            self._prefix(channel) + f"L{float(min_angle):.1f} {float(max_angle):.1f}")

    def set_presets(self, open_angle, close_angle, channel=0):
        return self.send_line(
            self._prefix(channel) + f"E{float(open_angle):.1f} {float(close_angle):.1f}")

    def set_pulse_range(self, min_us, max_us, channel=0):
        return self.send_line(
            self._prefix(channel) + f"U{float(min_us):.0f} {float(max_us):.0f}")

    def kill_outputs(self):
        """Hardware output disable via the PCA9685 OE pin — releases the
        gripper immediately regardless of firmware state."""
        return self.send_line("X")

    def restore_outputs(self):
        return self.send_line("Z")

    # -- configuration --------------------------------------------------------

    def push_config(self, cfg=None):
        """
        Push the app's saved gripper configuration into the firmware. The app
        owns this configuration (gripper_config.json) rather than the firmware
        storing it in EEPROM — same pattern as home offsets, tool offset and
        the motion profile, so there's one source of truth instead of two that
        can silently disagree.

        Order matters: limits go first, because the firmware clamps presets
        into the current limits when they're set.

        Returns a list of (command, response) for logging.
        """
        if cfg is None:
            cfg = config.load_gripper_config()
        ch = int(cfg.get("channel", 0))

        results = []
        steps = [
            ("pulse range", lambda: self.set_pulse_range(
                cfg["min_pulse_us"], cfg["max_pulse_us"], channel=ch)),
            ("limits", lambda: self.set_limits(
                cfg["min_angle"], cfg["max_angle"], channel=ch)),
            ("presets", lambda: self.set_presets(
                cfg["open_angle"], cfg["close_angle"], channel=ch)),
            ("rate", lambda: self.set_rate(
                cfg["rate_deg_per_sec"], channel=ch)),
        ]
        for name, fn in steps:
            results.append((name, fn()))
        return results
