"""
config.py

Central place for every number pulled from the project plan:
  - DH parameters (section 5.1)
  - Gear ratios / steps-per-rev (section 2.2 / 4)
  - Home offset calibration (section 5.4) — persisted to home_offsets.json
  - Joint limits (section 8 — measured on real hardware)
  - Serial defaults

Nothing here should need to change as you calibrate the physical arm —
only the *values*, via the GUI's calibration panel or by hand-editing
home_offsets.json.
"""

import json
import os

# ---------------------------------------------------------------------------
# DH parameters: (a [mm], alpha [deg], d [mm])  — theta is the joint variable
# From plan section 5.1. a4 (65mm) is the wrist's own link length, per the
# plan's explicit decision to fold the tool offset into joint 4 rather than
# treat it as a separate fixed 5th link.
# ---------------------------------------------------------------------------
DH_PARAMS = [
    {"a": 21.15,  "alpha_deg": 90.0, "d": 24.25},  # joint 1 - base (yaw)
    {"a": 194.66, "alpha_deg": 0.0,  "d": 0.0},     # joint 2 - shoulder (pitch)
    {"a": 152.0,  "alpha_deg": 0.0,  "d": 0.0},     # joint 3 - elbow (pitch)
    {"a": 65.0,   "alpha_deg": 0.0,  "d": 0.0},     # joint 4 - wrist (pitch)
]

# ---------------------------------------------------------------------------
# Drivetrain (section 2.2 / 4)
# ---------------------------------------------------------------------------
MOTOR_FULL_STEPS_PER_REV = 200          # NEMA17, full-step only (DRV8825, no microstepping)
GEAR_RATIOS = [36, 36, 36, 6]            # base, shoulder, elbow, wrist
STEPS_PER_OUTPUT_REV = [MOTOR_FULL_STEPS_PER_REV * r for r in GEAR_RATIOS]
# -> [7200, 7200, 7200, 1200]

# ---------------------------------------------------------------------------
# Grbl (gcobos/grbl4axis) steps-per-unit settings.
#
# Standard grbl does NOT accept raw step counts from the host — it parses
# G-code axis words in machine "units" (mm by convention, but really just
# whatever $100-$103 says a step is worth) and does the degrees<->steps
# conversion itself, in firmware, using its own EEPROM-stored settings.
#
# We exploit that directly: define 1 G-code "unit" == 1 degree of output
# rotation for every joint, and program grbl's steps/unit settings to match
# our gear reduction. Then the app can just send G-code axis words in plain
# degrees and grbl handles the rest — no step math needed on the host side.
#
#   $100 (X, base)      = steps per degree = 7200/360 = 20.0
#   $101 (Y, shoulder)  = steps per degree = 7200/360 = 20.0
#   $102 (Z, elbow)     = steps per degree = 7200/360 = 20.0
#   $103 (A, wrist)     = steps per degree = 1200/360 = 3.3333
#
# These need to be pushed to grbl's EEPROM once (they persist across power
# cycles after that) — the GUI's "Grbl Setup" panel does this with one
# button click. gcobos/grbl4axis maps its 4th axis to the "E" word on
# Uno pins D12/D13 (variable spindle disabled to free those pins) — NOT "A".
# Confirmed against the actual gcobos/grbl4axis source: it defines
# E_STEP_BIT / E_DIRECTION_BIT on pins 12/13, and the axis word grbl's
# g-code parser accepts for it is "E". Sending "A" gets the whole line
# rejected as an unsupported/invalid g-code block.
# ---------------------------------------------------------------------------
GRBL_AXIS_LETTERS = ["X", "Y", "Z", "E"]   # base, shoulder, elbow, wrist
GRBL_STEPS_PER_DEGREE = [s / 360.0 for s in STEPS_PER_OUTPUT_REV]
# -> [20.0, 20.0, 20.0, 3.3333...]

GRBL_SETTING_NUMBERS = ["$100", "$101", "$102", "$103"]

# Default feed rate for G1 moves, in grbl's units/min — since our "unit" is
# 1 degree, this is degrees/minute. G0 (rapid) ignores this and just seeks
# at $110-$113 max rate settings instead.
#
# Bench-testing finding (bare motors, no arm assembled yet — see build log):
# F300 (the old default) sat right inside a resonance band — motors were
# badly rattly/buzzy, confirmed both by ear and by an audio spectrogram
# (~220Hz fundamental + harmonics that shifted character with feed rate).
# F1600 deg/min cleared it up dramatically for the 36:1 joints
# (base/shoulder/elbow). Very likely classic full-step resonance
# (electromagnetic + detent-torque interaction, worse when unloaded) rather
# than a wiring/driver/gearbox fault — it responded to speed, not to any
# hardware change.
#
# IMPORTANT: this was found with bare, unloaded motors. Steppers lose
# available torque as step rate climbs, so once the arm carries real
# mass/gearing load, re-check whether 1600 is still smooth *and* whether it
# still has enough torque to hold/move the payload — don't assume higher is
# always better once it's loaded.
SAFE_FEED_DEG_PER_MIN = 1600.0   # tuned on base/shoulder/elbow (36:1 joints)

DEFAULT_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN

# The wrist is geared 6:1, not 36:1 — GRBL_STEPS_PER_DEGREE[3] is 6x smaller
# than the other joints', so the same F (deg/min) value drives it at a much
# lower *actual* step rate. Scale the safe feed above so the wrist lands in
# roughly the same physical step-rate sweet spot found on the bench:
WRIST_SAFE_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN * (
    GRBL_STEPS_PER_DEGREE[0] / GRBL_STEPS_PER_DEGREE[3]
)
# -> 1600 * (20 / 3.3333) = 9600.0 deg/min — test this specifically once the
# wrist motor/gearbox is wired up; don't assume 1600 is also its sweet spot.

# ---------------------------------------------------------------------------
# PER-AXIS MOTION PROFILE
#
# Different joints genuinely want different speeds: the 36:1 joints and the
# 6:1 wrist need different feeds to land in the same real step-rate range,
# and individual motors differ too (a taller/heavier-rotor NEMA 17 has more
# rotor inertia and a lower resonant frequency than a short one, so it can
# be rough at a feed that's perfectly smooth on its neighbours).
#
# IMPORTANT — how "per-axis speed" actually works in grbl:
#   G-code F is a SINGLE COORDINATED feed rate for the whole move, not a
#   per-axis value. For a move with deltas d_i and path length
#   L = sqrt(sum(d_i^2)), grbl runs the move at F along that path, so each
#   axis moves at  F * d_i / L.
#
# So per-axis speed is enforced two ways, and we use BOTH:
#   1. grbl's own $110-$113 max-rate settings are hard per-axis ceilings.
#      grbl automatically scales any move down so no axis exceeds its
#      limit. This is the safety net and it lives in the firmware.
#   2. The app computes the largest F that keeps EVERY axis under its own
#      limit (see serial_bridge.coordinated_feed), so we request something
#      sensible instead of always relying on grbl to clamp us.
#
# steps_per_deg is here too because it's now per-axis editable — if you
# enable microstepping on one axis to smooth it out, only that axis's
# $100-$103 value changes, and the app's math has to agree with the
# firmware or every move on that joint will be wrong.
#
# Persisted to motion_profile.json so it survives restarts, and pushable to
# the board's EEPROM from the Motion Tuning tab.
# ---------------------------------------------------------------------------
GRBL_MAX_RATE_SETTINGS = ["$110", "$111", "$112", "$113"]   # per-axis max rate
GRBL_ACCEL_SETTINGS = ["$120", "$121", "$122", "$123"]      # per-axis acceleration

_MOTION_PROFILE_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "motion_profile.json")

_DEFAULT_MOTION_PROFILE = {
    # Max speed per joint, deg/min. Drives both the app's feed calculation
    # and grbl's $110-$113. Wrist defaults higher to match its 6:1 gearing.
    "max_speed_deg_per_min": [
        SAFE_FEED_DEG_PER_MIN,
        SAFE_FEED_DEG_PER_MIN,
        SAFE_FEED_DEG_PER_MIN,
        WRIST_SAFE_FEED_DEG_PER_MIN,
    ],
    # Acceleration per joint, deg/sec^2 -> grbl $120-$123. Higher values
    # punch through a resonance band faster instead of dwelling in it.
    "accel_deg_per_sec2": [10.0, 10.0, 10.0, 10.0],
    # Steps per degree per joint -> grbl $100-$103. Change one of these if
    # you enable microstepping on a single axis.
    "steps_per_deg": list(GRBL_STEPS_PER_DEGREE),
}


def load_motion_profile():
    """Load the per-axis motion profile from disk, falling back to defaults.
    Missing/short keys are filled in from the defaults so an old or partial
    file can't produce a malformed profile."""
    profile = {k: list(v) for k, v in _DEFAULT_MOTION_PROFILE.items()}
    if os.path.exists(_MOTION_PROFILE_FILE):
        try:
            with open(_MOTION_PROFILE_FILE, "r") as f:
                data = json.load(f)
            for key in profile:
                vals = data.get(key)
                if isinstance(vals, list) and len(vals) == 4:
                    profile[key] = [float(v) for v in vals]
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            pass
    return profile


def save_motion_profile(profile):
    """Persist a per-axis motion profile dict to disk."""
    out = {}
    for key in _DEFAULT_MOTION_PROFILE:
        vals = profile.get(key, _DEFAULT_MOTION_PROFILE[key])
        if len(vals) != 4:
            raise ValueError(f"{key} must have exactly 4 values (one per joint)")
        out[key] = [float(v) for v in vals]
    with open(_MOTION_PROFILE_FILE, "w") as f:
        json.dump(out, f, indent=2)

# ---------------------------------------------------------------------------
# Joint limits — measured on the physical hardware (plan section 8, now
# closed out).
#   J1 (base):     confirmed NO hard stop -- true continuous rotation.
#                  +/-180 would just be atan2()'s wrap point, not a real
#                  physical limit, so it's represented as unbounded (+/-inf)
#                  below rather than a fake boundary. check_joint_limits()
#                  will therefore never flag J1 -- there's nothing to flag.
#   J2 (shoulder): 180 deg total, symmetric -> +/-90 deg
#   J3 (elbow):    190 deg total, symmetric -> +/-95 deg
#   J4 (wrist):    204 deg total, symmetric -> +/-102 deg
#
# CAVEAT for J1 being a true continuous-rotation joint: solve_ik()'s
# theta1 = atan2(y, x) always returns a value in (-180, 180], so the IK
# solver itself never asks for more than one turn. But because J1 can
# physically spin either direction with no stop, the same target could be
# reached by going the "short way" or the "long way" around (e.g. -179 deg
# vs +181 deg are the same physical pose) -- and after home-offset
# subtraction, a solved angle near the wrap point could come out on
# whichever side is numerically closer to zero, not necessarily the
# shortest real rotation from the arm's current position. Not handled yet;
# worth revisiting if J1 ever seems to spin the "long way round"
# unnecessarily once you're doing multi-waypoint moves.
# ---------------------------------------------------------------------------
JOINT_LIMITS_DEG = [
    (-float("inf"), float("inf")),   # base -- no hard stop, continuous rotation
    (-90.0, 90.0),                    # shoulder
    (-95.0, 95.0),                    # elbow
    (-102.0, 102.0),                  # wrist
]

# ---------------------------------------------------------------------------
# Tool-angle (psi) presets -- resolves the plan's "wrist/tool-angle strategy
# undecided" open item (section 8). psi is the tool's tilt within the arm's
# vertical plane, measured from horizontal (see kinematics.solve_ik). These
# are named starting points for kinematics.find_feasible_psi() to search
# around, rather than typing a raw degree value every time.
# ---------------------------------------------------------------------------
PSI_PRESETS = {
    "level": 0.0,     # gripper horizontal -- e.g. reaching onto a shelf
    "down": -90.0,    # gripper pointing straight down -- e.g. picking off a table
    "up": 90.0,       # gripper pointing straight up
}

# ---------------------------------------------------------------------------
# Home offset calibration (section 5.4)
#   THETA_HOME_OFFSET[i]: degrees to SUBTRACT from a DH-frame solved angle
#   to get the real motor command angle, i.e.:
#       motor_angle = theta_dh - home_offset
#   Persisted so you don't have to re-measure every session.
# ---------------------------------------------------------------------------
_HOME_OFFSET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "home_offsets.json")
_DEFAULT_HOME_OFFSETS = [0.0, 0.0, 0.0, 0.0]


def load_home_offsets():
    """Load home offsets from disk, falling back to zeros if not yet calibrated."""
    if os.path.exists(_HOME_OFFSET_FILE):
        try:
            with open(_HOME_OFFSET_FILE, "r") as f:
                data = json.load(f)
            offsets = data.get("home_offset_deg", _DEFAULT_HOME_OFFSETS)
            if len(offsets) == 4:
                return [float(v) for v in offsets]
        except (json.JSONDecodeError, OSError):
            pass
    return list(_DEFAULT_HOME_OFFSETS)


def save_home_offsets(offsets):
    """Persist a 4-element list of degree offsets to disk."""
    if len(offsets) != 4:
        raise ValueError("home offsets must have exactly 4 values (base, shoulder, elbow, wrist)")
    with open(_HOME_OFFSET_FILE, "w") as f:
        json.dump({"home_offset_deg": [float(v) for v in offsets]}, f, indent=2)


# ---------------------------------------------------------------------------
# Tool offset (TCP -- Tool Center Point)
#
# The actual working point of the tool (e.g. a marker tip) is NOT at the end
# of link 4 where the DH chain ends -- it's rigidly offset from the wrist
# frame. This is a fixed (dx, dy, dz) translation expressed IN THE WRIST'S
# OWN FRAME (the frame at the end of the DH chain), so it rotates with the
# wrist automatically:
#   dx = along the final link's reach axis (+ = further out past the wrist)
#   dy = sideways, perpendicular to reach in the wrist's frame (+/-)
#   dz = up/down in the wrist's frame
#
# LAYER 1 (implemented): forward_kinematics applies this so the 3D render and
# FK report the TRUE tool-tip position. LAYER 2 (implemented): kinematics.
# solve_ik back-solves so a requested (x, y, z) target places the TOOL TIP
# there rather than the wrist -- see kinematics.solve_ik's docstring for the
# base-angle "Side A/B" branch this introduces for a nonzero lateral (dy)
# offset. The GUI must pass the current tool_offset into every IK/FK call
# (not rely on the None-default here) so a value edited in the Tool Offset
# panel but not yet saved to disk is still what's actually solved/rendered.
#
# Persisted to disk like home offsets so it survives restarts.
# ---------------------------------------------------------------------------
_TOOL_OFFSET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tool_offset.json")
_DEFAULT_TOOL_OFFSET = [0.0, 50.5, 0.0]   # dx, dy, dz mm -- measured: 50.5mm right, no other shift


def load_tool_offset():
    """Load the tool offset (dx, dy, dz mm) from disk, defaulting to zeros."""
    if os.path.exists(_TOOL_OFFSET_FILE):
        try:
            with open(_TOOL_OFFSET_FILE, "r") as f:
                data = json.load(f)
            off = data.get("tool_offset_mm", _DEFAULT_TOOL_OFFSET)
            if len(off) == 3:
                return [float(v) for v in off]
        except (json.JSONDecodeError, OSError):
            pass
    return list(_DEFAULT_TOOL_OFFSET)


def save_tool_offset(offset):
    """Persist a 3-element (dx, dy, dz) tool offset in mm to disk."""
    if len(offset) != 3:
        raise ValueError("tool offset must have exactly 3 values (dx, dy, dz)")
    with open(_TOOL_OFFSET_FILE, "w") as f:
        json.dump({"tool_offset_mm": [float(v) for v in offset]}, f, indent=2)


# ---------------------------------------------------------------------------
# Serial / firmware protocol defaults — real gcobos/grbl4axis over G-code
# ---------------------------------------------------------------------------
DEFAULT_BAUD = 115200   # grbl v0.9+ default; this fork inherits it


# ---------------------------------------------------------------------------
# GRIPPER (Nano servo controller)
#
# The gripper runs on a SECOND Arduino (a Nano) driving servos through a
# PCA9685, independent of the Uno running grbl4axis — grbl owns Timer1 for
# step generation so the Servo library can't coexist with it, and the Uno's
# flash is nearly full with the 4-axis fork already.
#
# The app owns this configuration and pushes it to the firmware on connect,
# rather than the Nano storing it in EEPROM. Same pattern as home offsets,
# tool offset and the motion profile: one source of truth instead of two that
# can drift apart. See nano_gripper/ for the firmware and its protocol.
# ---------------------------------------------------------------------------
GRIPPER_DEFAULT_BAUD = 115200

_GRIPPER_CONFIG_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "gripper_config.json")

_DEFAULT_GRIPPER_CONFIG = {
    "channel": 0,               # PCA9685 channel the gripper servo is on
    "open_angle": 120.0,        # servo angle for "open"
    "close_angle": 60.0,        # servo angle for "closed"
    "min_angle": 0.0,           # travel limits — the firmware refuses to go
    "max_angle": 180.0,         #   outside these, since a servo driven into a
                                #   mechanical stop stalls and overheats
    "rate_deg_per_sec": 120.0,  # default sweep speed
    "min_pulse_us": 500.0,      # MG90S typical pulse range
    "max_pulse_us": 2400.0,
}


def load_gripper_config():
    """Load gripper settings from disk, falling back to defaults. Unknown or
    missing keys are filled from the defaults so a partial/old file can't
    produce a malformed config."""
    cfg = dict(_DEFAULT_GRIPPER_CONFIG)
    if os.path.exists(_GRIPPER_CONFIG_FILE):
        try:
            with open(_GRIPPER_CONFIG_FILE, "r") as f:
                data = json.load(f)
            for key in cfg:
                if key in data:
                    cfg[key] = type(cfg[key])(data[key])
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            pass
    return cfg


def save_gripper_config(cfg):
    """Persist gripper settings to disk."""
    out = dict(_DEFAULT_GRIPPER_CONFIG)
    for key in out:
        if key in cfg:
            out[key] = type(out[key])(cfg[key])
    with open(_GRIPPER_CONFIG_FILE, "w") as f:
        json.dump(out, f, indent=2)

AXIS_LABELS = ["base", "shoulder", "elbow", "wrist"]

# NOTE ON THE 4-AXIS PIN MAPPING:
# gcobos/grbl4axis frees Uno pins D12/D13 for a 4th ("E") axis by disabling
# grbl's variable-spindle PWM feature. Confirm your CNC Shield / wiring
# actually routes the wrist driver's STEP/DIR to D12/D13 accordingly —
# this is a firmware-level pin choice made by that fork, not something this
# app controls.
#
# Protocol is now standard grbl G-code, not a custom line format:
#   - Motion:  "G90 G1 X<deg> Y<deg> Z<deg> E<deg> F<feed>\n" (absolute, feed-rate move)
#              or "G90 G0 X<deg> Y<deg> Z<deg> E<deg>\n" (absolute, rapid move)
#   - Grbl responds "ok\n" per accepted line, or "error:<n>\n" on rejection.
#   - Real-time commands (single character, no newline, no "ok" reply):
#       "?"  status report request
#       "!"  feed hold
#       "~"  cycle start / resume
#       0x18 (Ctrl-X) soft reset
#   - "$X\n" clears an ALARM lock (grbl starts in alarm state if homing is
#     enabled in settings but hasn't been run — common with no limit
#     switches wired up, which this project doesn't have per the plan).
#
# See serial_bridge.py for the implementation and gui.py's "Grbl Setup"
# panel for pushing the $100-$103 steps/unit settings shown above.
