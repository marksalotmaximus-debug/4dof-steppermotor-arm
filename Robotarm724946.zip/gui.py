"""
gui.py

PyQt5 desktop app tying together kinematics.py and serial_bridge.py.

Layout:
  Left column:
    - Joint jog sliders (theta1..theta4) with live degree readout
    - Target pose panel (X, Y, Z, psi, elbow up/down) + "Solve IK" button
    - Home offset calibration panel (4 fields, Save/Reload)
  Right column:
    - Live 3D plot of the arm (matplotlib, driven by forward_kinematics())
  Bottom:
    - Serial connection panel: port dropdown, connect/disconnect, one-time
      $100-$103 grbl settings push, unlock/status/feed-hold/resume/soft-reset,
      feed-rate input, and "Send Current Pose to Grbl" (real G-code, not
      raw step counts — see serial_bridge.py)

Run via main.py.
"""

import sys
import math

import numpy as np
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

import config
import kinematics
import serial_bridge
import gripper_bridge
import hershey_font


# ---------------------------------------------------------------------------
# Visual theme. A single light stylesheet applied app-wide gives every widget
# consistent spacing, readable type, and clear affordances, instead of the
# raw native look. Semantic button classes (primary / danger) are opted into
# per-button via setProperty("kind", ...) so consequential actions read as
# such at a glance.
# ---------------------------------------------------------------------------
APP_STYLE = """
QWidget {
    font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    color: #1f2733;
}
QMainWindow, QWidget#central { background: #f4f6f9; }

QGroupBox {
    background: #ffffff;
    border: 1px solid #d7dee8;
    border-radius: 8px;
    margin-top: 14px;
    padding-top: 6px;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 0 6px;
    color: #3a4658;
}

QTabWidget::pane {
    border: 1px solid #d7dee8;
    border-radius: 8px;
    background: #ffffff;
    top: -1px;
}
QTabBar::tab {
    background: #e7ecf3;
    color: #4a5567;
    padding: 8px 18px;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
    margin-right: 2px;
    font-weight: 600;
}
QTabBar::tab:selected { background: #ffffff; color: #1a56db; }
QTabBar::tab:hover:!selected { background: #eef2f7; }

QPushButton {
    background: #eef1f6;
    border: 1px solid #cbd4e1;
    border-radius: 6px;
    padding: 6px 12px;
    color: #24303f;
}
QPushButton:hover { background: #e2e8f1; }
QPushButton:pressed { background: #d3dbe7; }
QPushButton:disabled { background: #f0f2f5; color: #9aa4b2; border-color: #e0e4ea; }

/* Primary action — the main "do the thing" button in a panel. */
QPushButton[kind="primary"] {
    background: #1a56db;
    border: 1px solid #1546b4;
    color: #ffffff;
    font-weight: 600;
}
QPushButton[kind="primary"]:hover { background: #1c4fc4; }
QPushButton[kind="primary"]:pressed { background: #163f9e; }
QPushButton[kind="primary"]:disabled { background: #a9bde8; border-color: #a9bde8; color: #eef2fb; }

/* Danger action — stop / reset / abort. Reads red so it's never confused
   with a benign button. */
QPushButton[kind="danger"] {
    background: #fdecec;
    border: 1px solid #e6a6a6;
    color: #b42318;
    font-weight: 600;
}
QPushButton[kind="danger"]:hover { background: #fbdcdc; }
QPushButton[kind="danger"]:pressed { background: #f6c9c9; }
QPushButton[kind="danger"]:disabled { background: #f6eeee; border-color: #ecd6d6; color: #cba7a3; }

QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit {
    background: #ffffff;
    border: 1px solid #cbd4e1;
    border-radius: 6px;
    padding: 4px 6px;
    selection-background-color: #1a56db;
    selection-color: #ffffff;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
    border: 1px solid #1a56db;
}
QComboBox::drop-down { border: none; width: 20px; }
QPlainTextEdit { font-family: "Consolas", "Menlo", monospace; font-size: 12px; }

QSlider::groove:horizontal {
    height: 5px; background: #d7dee8; border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #1a56db; width: 15px; margin: -6px 0; border-radius: 8px;
}
QSlider::handle:horizontal:hover { background: #1c4fc4; }
QSlider::sub-page:horizontal { background: #9db8ee; border-radius: 3px; }

QProgressBar {
    border: 1px solid #cbd4e1; border-radius: 6px;
    background: #eef1f6; text-align: center; height: 18px;
}
QProgressBar::chunk { background: #1a56db; border-radius: 5px; }

QRadioButton, QCheckBox { spacing: 6px; }
QTableWidget {
    background: #ffffff; border: 1px solid #cbd4e1; border-radius: 6px;
    gridline-color: #e4e9f0;
}
QHeaderView::section {
    background: #eef1f6; border: none; border-bottom: 1px solid #cbd4e1;
    padding: 4px; font-weight: 600; color: #3a4658;
}
QToolTip {
    background: #24303f; color: #ffffff; border: none;
    padding: 5px 8px; border-radius: 4px;
}
"""


def _style_button(btn, kind):
    """Tag a button with a semantic style class ('primary' or 'danger')."""
    btn.setProperty("kind", kind)
    return btn


class PathStreamWorker(QtCore.QThread):
    """
    Streams a planned waypoint path to grbl on a background thread so the
    GUI stays responsive. Emits progress per acknowledged move and a final
    'finished_streaming' signal. Abort is cooperative: set self._abort and
    the stream stops (with a feed-hold) before the next move.
    """
    progress = QtCore.pyqtSignal(int, int)          # (index, total)
    finished_streaming = QtCore.pyqtSignal(int, bool)  # (sent_count, aborted)
    error = QtCore.pyqtSignal(str)

    def __init__(self, bridge, gcode_lines, feed_deg_per_min, parent=None):
        super().__init__(parent)
        self.bridge = bridge
        self.gcode_lines = gcode_lines
        self.feed = feed_deg_per_min
        self._abort = False

    def request_abort(self):
        self._abort = True

    def run(self):
        try:
            sent, aborted = self.bridge.stream_gcode(
                self.gcode_lines,
                on_progress=lambda i, total, line, resp: self.progress.emit(i + 1, total),
                should_abort=lambda: self._abort,
            )
            self.finished_streaming.emit(sent, aborted)
        except serial_bridge.SerialBridgeError as e:
            self.error.emit(str(e))


class Arm3DCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(5, 5))
        super().__init__(fig)
        self.setParent(parent)
        self.ax = fig.add_subplot(111, projection="3d")
        self._reach = sum(p["a"] for p in config.DH_PARAMS) + 50
        self.plot_pose([0, 0, 0, 0])

    def plot_pose(self, thetas_deg, target_xyz=None, path_xyz=None, tool_offset=None):
        positions, _ = kinematics.forward_kinematics(thetas_deg, tool_offset=tool_offset)
        pts = np.array(positions)

        self.ax.clear()
        # Optional path trace (tool-tip positions along a planned waypoint path)
        if path_xyz is not None and len(path_xyz) > 1:
            path = np.array(path_xyz)
            self.ax.plot(path[:, 0], path[:, 1], path[:, 2], "-",
                         color="#9b59b6", linewidth=1.2, alpha=0.7)
        # Arm links
        self.ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], "-o", color="#2a6fdb",
                     linewidth=3, markersize=6, markerfacecolor="#ff6a3d")
        # Base marker
        self.ax.scatter([0], [0], [0], color="black", s=40, marker="s")

        if target_xyz is not None:
            self.ax.scatter([target_xyz[0]], [target_xyz[1]], [target_xyz[2]],
                             color="green", s=60, marker="*", label="target")
            self.ax.legend(loc="upper left", fontsize=8)

        r = self._reach
        self.ax.set_xlim(-r, r)
        self.ax.set_ylim(-r, r)
        self.ax.set_zlim(0, 2 * r)
        self.ax.set_xlabel("X (mm)")
        self.ax.set_ylabel("Y (mm)")
        self.ax.set_zlabel("Z (mm)")
        self.ax.set_title("4-DOF arm — live DH pose")
        self.draw()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4-DOF Arm Control")
        self.resize(1500, 950)
        self.setMinimumSize(1300, 800)
        self.setStyleSheet(APP_STYLE)

        self.bridge = serial_bridge.SerialBridge()
        self.gripper = gripper_bridge.GripperBridge()
        self.current_thetas = [0.0, 0.0, 0.0, 0.0]
        self.last_target_xyz = None

        central = QtWidgets.QWidget()
        central.setObjectName("central")
        self.setCentralWidget(central)
        root_layout = QtWidgets.QVBoxLayout(central)

        top_layout = QtWidgets.QHBoxLayout()
        root_layout.addLayout(top_layout, stretch=1)

        # Left side is a tab widget so the single-pose controls and the new
        # waypoint-path player each get full room instead of being stacked
        # into one cramped column. Each tab's contents live inside a scroll
        # area so panels keep their natural height and you scroll if the
        # window is short, rather than the panels being crushed to fit.
        self.left_tabs = QtWidgets.QTabWidget()
        self.left_tabs.setMinimumWidth(540)
        top_layout.addWidget(self.left_tabs, stretch=0)

        self.canvas = Arm3DCanvas(self)
        top_layout.addWidget(self.canvas, stretch=1)

        # Tab 1 -- single pose (jog + IK + calibration + tool offset)
        single_pose_tab = QtWidgets.QWidget()
        single_col = QtWidgets.QVBoxLayout(single_pose_tab)
        single_col.setSpacing(10)
        for panel in (self._build_jog_panel(), self._build_ik_panel(),
                      self._build_calibration_panel(), self._build_tool_offset_panel()):
            # Fixed vertical policy => each panel always gets exactly its
            # natural height; the scroll area handles overflow. This is what
            # prevents the rows from being crushed into overlap.
            panel.setSizePolicy(QtWidgets.QSizePolicy.Preferred,
                                QtWidgets.QSizePolicy.Fixed)
            single_col.addWidget(panel)
        single_col.addStretch(1)
        self.left_tabs.addTab(self._wrap_scroll(single_pose_tab), "Single Pose")

        # Tab 2 -- waypoint path player
        self.left_tabs.addTab(self._wrap_scroll(self._build_waypoint_tab()), "Waypoint Path")

        # Tab 3 -- text writing (Hershey single-stroke font)
        self.left_tabs.addTab(self._wrap_scroll(self._build_writing_tab()), "Write Text")

        # Tab 4 -- per-axis motion tuning (speeds / accel / steps per degree)
        self.left_tabs.addTab(self._wrap_scroll(self._build_motion_tab()), "Motion Tuning")

        # Tab 5 -- gripper (separate Nano board over its own serial link)
        self.left_tabs.addTab(self._wrap_scroll(self._build_gripper_tab()), "Gripper")

        root_layout.addWidget(self._build_serial_panel(), stretch=0)

        self._refresh_ports()
        self._update_pose()

    # -- panels ------------------------------------------------------------

    def _wrap_scroll(self, inner_widget):
        """Put a tab's contents in a vertical scroll area so panels keep their
        natural height and the user scrolls if the window is short, instead of
        the panels being compressed into unreadable overlap."""
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setWidget(inner_widget)
        return scroll

    def _build_jog_panel(self):
        box = QtWidgets.QGroupBox("Joint Jog (degrees)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.joint_sliders = []
        self.joint_labels = []
        names = ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"]
        for i, name in enumerate(names):
            lo, hi = config.JOINT_LIMITS_DEG[i]
            # J1 has no hard stop (true continuous rotation), so its real
            # limit is +/-inf -- Qt sliders need a finite range, so give it
            # a generous jog range (a few full turns either way) purely for
            # the UI. This does NOT feed into check_joint_limits(), which
            # still correctly treats J1 as unbounded.
            if not math.isfinite(lo) or not math.isfinite(hi):
                lo, hi = -720.0, 720.0
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setMinimum(int(lo))
            slider.setMaximum(int(hi))
            slider.setValue(0)
            slider.setMinimumWidth(220)
            slider.valueChanged.connect(self._on_jog_changed)

            label = QtWidgets.QLabel(f"{name}: 0.0°")
            label.setMinimumWidth(140)
            layout.addWidget(label, i, 0)
            layout.addWidget(slider, i, 1)
            self.joint_sliders.append(slider)
            self.joint_labels.append(label)

        return box

    def _build_ik_panel(self):
        box = QtWidgets.QGroupBox("Target Pose (Inverse Kinematics)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(10)
        layout.setContentsMargins(12, 16, 12, 12)

        self.x_input = QtWidgets.QDoubleSpinBox()
        self.y_input = QtWidgets.QDoubleSpinBox()
        self.z_input = QtWidgets.QDoubleSpinBox()
        self.psi_input = QtWidgets.QDoubleSpinBox()
        for w in (self.x_input, self.y_input, self.z_input, self.psi_input):
            w.setMinimumWidth(90)
            w.setMinimumHeight(28)
        for w in (self.x_input, self.y_input, self.z_input):
            w.setRange(-1000, 1000)
            w.setDecimals(1)
            w.setSuffix(" mm")
        self.psi_input.setRange(-360, 360)
        self.psi_input.setSuffix(" deg")
        self.z_input.setValue(200.0)
        self.x_input.setValue(300.0)

        self.elbow_up = QtWidgets.QRadioButton("Elbow up")
        self.elbow_down = QtWidgets.QRadioButton("Elbow down")
        self.elbow_up.setChecked(True)
        elbow_group = QtWidgets.QButtonGroup(self)
        elbow_group.addButton(self.elbow_up)
        elbow_group.addButton(self.elbow_down)

        self.side_a = QtWidgets.QRadioButton("Side A (direct)")
        self.side_b = QtWidgets.QRadioButton("Side B (reach-around)")
        self.side_a.setChecked(True)
        side_group = QtWidgets.QButtonGroup(self)
        side_group.addButton(self.side_a)
        side_group.addButton(self.side_b)
        side_tip = (
            "Only matters with a nonzero lateral tool offset (see Tool Offset panel). "
            "'A' is the direct base angle toward the target; 'B' rotates the base to reach "
            "the same tool-tip point from roughly the opposite direction -- only "
            "geometrically possible for targets close enough to the base axis."
        )
        self.side_a.setToolTip(side_tip)
        self.side_b.setToolTip(side_tip)

        solve_btn = _style_button(QtWidgets.QPushButton("Solve IK"), "primary")
        solve_btn.setMinimumHeight(32)
        solve_btn.clicked.connect(self._on_solve_ik)

        preset_row = QtWidgets.QHBoxLayout()
        preset_row.setSpacing(8)
        for name in config.PSI_PRESETS:
            btn = QtWidgets.QPushButton(f"Auto: {name}")
            btn.setMinimumHeight(30)
            btn.setMinimumWidth(110)
            btn.setToolTip(
                f"Finds the psi nearest to the '{name}' preset "
                f"({config.PSI_PRESETS[name]:.0f} deg) that satisfies joint limits "
                "on either elbow/side branch, sets it, and solves."
            )
            btn.clicked.connect(lambda checked, n=name: self._on_preset_psi(n))
            preset_row.addWidget(btn)

        self.ik_status = QtWidgets.QLabel("")
        self.ik_status.setWordWrap(True)
        self.ik_status.setMinimumHeight(60)

        layout.addWidget(QtWidgets.QLabel("X"), 0, 0)
        layout.addWidget(self.x_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Y"), 0, 2)
        layout.addWidget(self.y_input, 0, 3)
        layout.addWidget(QtWidgets.QLabel("Z"), 1, 0)
        layout.addWidget(self.z_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("Tool angle ψ"), 1, 2)
        layout.addWidget(self.psi_input, 1, 3)
        layout.addWidget(self.elbow_up, 2, 0, 1, 2)
        layout.addWidget(self.elbow_down, 2, 2, 1, 2)
        layout.addWidget(self.side_a, 3, 0, 1, 2)
        layout.addWidget(self.side_b, 3, 2, 1, 2)
        layout.addLayout(preset_row, 4, 0, 1, 4)
        layout.addWidget(solve_btn, 5, 0, 1, 4)
        layout.addWidget(self.ik_status, 6, 0, 1, 4)

        return box

    def _build_calibration_panel(self):
        box = QtWidgets.QGroupBox("Home Offset Calibration (plan §5.4)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.offset_inputs = []
        offsets = config.load_home_offsets()
        for i, name in enumerate(config.AXIS_LABELS):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-360, 360)
            spin.setDecimals(2)
            spin.setValue(offsets[i])
            spin.setMinimumWidth(90)
            spin.setMinimumHeight(28)
            label = QtWidgets.QLabel(name)
            label.setMinimumWidth(140)
            layout.addWidget(label, i, 0)
            layout.addWidget(spin, i, 1)
            self.offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offsets")
        save_btn.setMinimumHeight(30)
        save_btn.clicked.connect(self._on_save_offsets)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_offsets)
        layout.addWidget(save_btn, len(config.AXIS_LABELS), 0)
        layout.addWidget(reload_btn, len(config.AXIS_LABELS), 1)

        note = QtWidgets.QLabel(
            "Not yet measured on physical hardware (open item). Jog each joint to a\n"
            "known reference pose on the real arm, read the DH-solved angle above,\n"
            "and enter the difference here."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, len(config.AXIS_LABELS) + 1, 0, 1, 2)

        return box

    def _build_tool_offset_panel(self):
        box = QtWidgets.QGroupBox("Tool Offset — marker tip vs. wrist (mm)")
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        offset = config.load_tool_offset()
        self.tool_offset_inputs = []
        labels = ["dx (out along reach)", "dy (sideways)", "dz (up/down)"]
        for i, lbl in enumerate(labels):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-500, 500)
            spin.setDecimals(1)
            spin.setSuffix(" mm")
            spin.setValue(offset[i])
            spin.setMinimumHeight(28)
            spin.valueChanged.connect(self._on_tool_offset_changed)
            label = QtWidgets.QLabel(lbl)
            label.setMinimumWidth(150)
            layout.addWidget(label, i, 0)
            layout.addWidget(spin, i, 1)
            self.tool_offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offset")
        save_btn.setMinimumHeight(30)
        save_btn.clicked.connect(self._on_save_tool_offset)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_tool_offset)
        layout.addWidget(save_btn, 3, 0)
        layout.addWidget(reload_btn, 3, 1)

        note = QtWidgets.QLabel(
            "Rigid offset from the wrist frame to the actual tool tip. IK now solves "
            "for the TRUE TOOL TIP position here (Layer 2) — a typed XYZ target puts "
            "the actual marker/gripper tip there, not the wrist. A nonzero 'sideways' "
            "(dy) offset adds a 'Side A/B' choice in the IK panel (like elbow up/down, "
            "but for the base) since the tool no longer sits in the arm's own vertical "
            "plane. Measure dx/dy/dz from the wrist's center of rotation to the tool "
            "tip with the wrist at θ4=0."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, 4, 0, 1, 2)

        return box

    def _current_tool_offset(self):
        return [s.value() for s in self.tool_offset_inputs]

    def _on_tool_offset_changed(self):
        self.canvas.plot_pose(self.current_thetas, target_xyz=self.last_target_xyz,
                              tool_offset=self._current_tool_offset())

    def _on_save_tool_offset(self):
        config.save_tool_offset(self._current_tool_offset())
        self._log(f"Saved tool offset {self._current_tool_offset()} mm to disk.")

    def _on_reload_tool_offset(self):
        offset = config.load_tool_offset()
        for spin, v in zip(self.tool_offset_inputs, offset):
            spin.blockSignals(True)
            spin.setValue(v)
            spin.blockSignals(False)
        self._on_tool_offset_changed()
        self._log(f"Reloaded tool offset {offset} mm from disk.")

    # -- waypoint path tab -------------------------------------------------

    def _build_waypoint_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        # --- waypoint table ---
        table_box = QtWidgets.QGroupBox("Waypoints (X, Y, Z mm; ψ deg)")
        table_layout = QtWidgets.QVBoxLayout(table_box)
        self.wp_table = QtWidgets.QTableWidget(0, 4)
        self.wp_table.setHorizontalHeaderLabels(["X", "Y", "Z", "ψ"])
        self.wp_table.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.Stretch)
        self.wp_table.setMinimumHeight(160)
        table_layout.addWidget(self.wp_table)

        row_btns = QtWidgets.QHBoxLayout()
        add_btn = QtWidgets.QPushButton("Add row")
        add_btn.clicked.connect(self._on_wp_add_row)
        add_current_btn = QtWidgets.QPushButton("Add current pose")
        add_current_btn.setToolTip("Adds the current target-pose X/Y/Z/ψ from the Single Pose tab.")
        add_current_btn.clicked.connect(self._on_wp_add_current)
        del_btn = QtWidgets.QPushButton("Delete row")
        del_btn.clicked.connect(self._on_wp_delete_row)
        clear_btn = QtWidgets.QPushButton("Clear")
        clear_btn.clicked.connect(lambda: self.wp_table.setRowCount(0))
        for b in (add_btn, add_current_btn, del_btn, clear_btn):
            b.setMinimumHeight(28)
            row_btns.addWidget(b)
        table_layout.addLayout(row_btns)
        col.addWidget(table_box)

        # --- primitive generators ---
        gen_box = QtWidgets.QGroupBox("Generate a path")
        gen_layout = QtWidgets.QGridLayout(gen_box)
        gen_layout.setHorizontalSpacing(10)
        gen_layout.setVerticalSpacing(8)

        line_btn = QtWidgets.QPushButton("Line sweep")
        line_btn.setToolTip("Straight line from the first waypoint to the last one in the table.")
        line_btn.setMinimumHeight(28)
        line_btn.clicked.connect(self._on_gen_line)

        circle_btn = QtWidgets.QPushButton("Circle")
        circle_btn.setToolTip("Circle centered on the first waypoint in the table, in the chosen plane.")
        circle_btn.setMinimumHeight(28)
        circle_btn.clicked.connect(self._on_gen_circle)

        self.circle_radius = QtWidgets.QDoubleSpinBox()
        self.circle_radius.setRange(1, 500)
        self.circle_radius.setValue(40)
        self.circle_radius.setSuffix(" mm")
        self.circle_radius.setMinimumHeight(28)

        self.circle_plane = QtWidgets.QComboBox()
        self.circle_plane.addItems(["xy", "xz", "yz"])
        self.circle_plane.setCurrentText("xz")
        self.circle_plane.setMinimumHeight(28)

        gen_layout.addWidget(line_btn, 0, 0)
        gen_layout.addWidget(QtWidgets.QLabel("(uses first + last waypoint)"), 0, 1, 1, 3)
        gen_layout.addWidget(circle_btn, 1, 0)
        gen_layout.addWidget(QtWidgets.QLabel("r"), 1, 1)
        gen_layout.addWidget(self.circle_radius, 1, 2)
        gen_layout.addWidget(self.circle_plane, 1, 3)
        col.addWidget(gen_box)

        # --- planning + run controls ---
        run_box = QtWidgets.QGroupBox("Plan & run")
        run_layout = QtWidgets.QGridLayout(run_box)
        run_layout.setHorizontalSpacing(10)
        run_layout.setVerticalSpacing(8)

        self.wp_auto_psi = QtWidgets.QCheckBox("Auto-adjust ψ into joint limits per point")
        self.wp_auto_psi.setChecked(True)

        self.wp_elbow = QtWidgets.QComboBox()
        self.wp_elbow.addItems(["up", "down"])

        self.wp_side = QtWidgets.QComboBox()
        self.wp_side.addItems(["A", "B"])
        self.wp_side.setToolTip(
            "Only matters with a nonzero lateral tool offset. 'A' is the direct base "
            "angle; 'B' reaches around from the opposite side (only valid near the base axis)."
        )

        self.wp_segment = QtWidgets.QDoubleSpinBox()
        self.wp_segment.setRange(0.5, 50)
        self.wp_segment.setValue(5.0)
        self.wp_segment.setSuffix(" mm/seg")
        self.wp_segment.setToolTip(
            "Max segment length. Smaller = smoother motion (grbl blends short "
            "moves) but more commands to stream.")

        self.wp_feed = QtWidgets.QDoubleSpinBox()
        self.wp_feed.setRange(1, 20000)
        self.wp_feed.setValue(config.SAFE_FEED_DEG_PER_MIN)
        self.wp_feed.setSuffix(" deg/min")

        for w in (self.wp_elbow, self.wp_side, self.wp_segment, self.wp_feed):
            w.setMinimumHeight(28)

        simulate_btn = QtWidgets.QPushButton("Simulate (no hardware)")
        simulate_btn.setMinimumHeight(32)
        simulate_btn.clicked.connect(self._on_wp_simulate)

        self.wp_run_btn = _style_button(QtWidgets.QPushButton("Run on Arm"), "primary")
        self.wp_run_btn.setMinimumHeight(32)
        self.wp_run_btn.clicked.connect(self._on_wp_run)

        self.wp_abort_btn = _style_button(QtWidgets.QPushButton("Stop (feed hold)"), "danger")
        self.wp_abort_btn.setMinimumHeight(32)
        self.wp_abort_btn.setEnabled(False)
        self.wp_abort_btn.clicked.connect(self._on_wp_abort)

        self.wp_progress = QtWidgets.QProgressBar()
        self.wp_status = QtWidgets.QLabel("")
        self.wp_status.setWordWrap(True)
        self.wp_status.setMinimumHeight(40)

        run_layout.addWidget(self.wp_auto_psi, 0, 0, 1, 4)
        run_layout.addWidget(QtWidgets.QLabel("Elbow"), 1, 0)
        run_layout.addWidget(self.wp_elbow, 1, 1)
        run_layout.addWidget(QtWidgets.QLabel("Side"), 1, 2)
        run_layout.addWidget(self.wp_side, 1, 3)
        run_layout.addWidget(self.wp_segment, 2, 0)
        run_layout.addWidget(self.wp_feed, 2, 1)
        run_layout.addWidget(simulate_btn, 3, 0, 1, 2)
        run_layout.addWidget(self.wp_run_btn, 3, 2)
        run_layout.addWidget(self.wp_abort_btn, 3, 3)
        run_layout.addWidget(self.wp_progress, 4, 0, 1, 4)
        run_layout.addWidget(self.wp_status, 5, 0, 1, 4)
        col.addWidget(run_box)

        col.addStretch(1)

        self._wp_plan = None       # cached last successful plan
        self._wp_worker = None
        return tab

    def _read_waypoints(self):
        """Read the table into a list of (x, y, z, psi) tuples. Blank/invalid rows raise."""
        poses = []
        for r in range(self.wp_table.rowCount()):
            vals = []
            for c in range(4):
                item = self.wp_table.item(r, c)
                if item is None or not item.text().strip():
                    raise ValueError(f"Row {r + 1} has an empty cell.")
                vals.append(float(item.text()))
            poses.append(tuple(vals))
        return poses

    def _set_waypoints(self, poses):
        self.wp_table.setRowCount(len(poses))
        for r, (x, y, z, psi) in enumerate(poses):
            for c, v in enumerate((x, y, z, psi)):
                self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_add_row(self):
        r = self.wp_table.rowCount()
        self.wp_table.insertRow(r)
        for c, v in enumerate((250.0, 0.0, 300.0, 0.0)):
            self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_add_current(self):
        r = self.wp_table.rowCount()
        self.wp_table.insertRow(r)
        vals = (self.x_input.value(), self.y_input.value(),
                self.z_input.value(), self.psi_input.value())
        for c, v in enumerate(vals):
            self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_delete_row(self):
        r = self.wp_table.currentRow()
        if r >= 0:
            self.wp_table.removeRow(r)

    def _on_gen_line(self):
        try:
            poses = self._read_waypoints()
        except ValueError as e:
            self._wp_set_status(str(e), error=True)
            return
        if len(poses) < 2:
            self._wp_set_status("Need at least 2 waypoints (start + end) for a line sweep.", error=True)
            return
        start = poses[0][:3]
        end = poses[-1][:3]
        psi = poses[0][3]
        self._set_waypoints(kinematics.line_sweep(start, end, psi, num_waypoints=2))
        self._wp_set_status("Generated a line sweep from the first to the last waypoint.")

    def _on_gen_circle(self):
        try:
            poses = self._read_waypoints()
        except ValueError as e:
            self._wp_set_status(str(e), error=True)
            return
        if not poses:
            self._wp_set_status("Add at least one waypoint to use as the circle center.", error=True)
            return
        center = poses[0][:3]
        psi = poses[0][3]
        circle = kinematics.circle_path(center, self.circle_radius.value(), psi,
                                         plane=self.circle_plane.currentText(),
                                         num_waypoints=48)
        self._set_waypoints(circle)
        self._wp_set_status(
            f"Generated a {self.circle_plane.currentText()} circle of r="
            f"{self.circle_radius.value():.0f}mm around the first waypoint.")

    def _plan_current_path(self):
        poses = self._read_waypoints()
        if len(poses) < 2:
            raise ValueError("Need at least 2 waypoints to run a path.")
        return kinematics.plan_waypoint_path(
            poses,
            prefer_elbow=self.wp_elbow.currentText(),
            prefer_side=self.wp_side.currentText(),
            max_segment_mm=self.wp_segment.value(),
            auto_psi=self.wp_auto_psi.isChecked(),
            tool_offset=self._current_tool_offset(),
        )

    def _on_wp_simulate(self):
        try:
            plan = self._plan_current_path()
        except (ValueError, kinematics.PathPlanningError) as e:
            self._wp_set_status(str(e), error=True)
            return

        self._wp_plan = plan
        path_xyz = [p[:3] for p in plan["dense_poses"]]
        self._wp_set_status(
            f"Planned {len(plan['thetas'])} points, all within joint limits. "
            "Animating in the 3D view (no hardware commands sent).")

        # Animate through the poses with a QTimer so the GUI stays responsive.
        self._sim_index = 0
        self._sim_thetas = plan["thetas"]
        self._sim_path = path_xyz
        if not hasattr(self, "_sim_timer"):
            self._sim_timer = QtCore.QTimer(self)
            self._sim_timer.timeout.connect(self._sim_step)
        self._sim_timer.start(40)

    def _sim_step(self):
        if self._sim_index >= len(self._sim_thetas):
            self._sim_timer.stop()
            return
        thetas = self._sim_thetas[self._sim_index]
        self.canvas.plot_pose(thetas, path_xyz=self._sim_path,
                              tool_offset=self._current_tool_offset())
        self._sim_index += 1

    def _on_wp_run(self):
        if not self.bridge.is_connected():
            self._wp_set_status("Not connected to the arm. Connect in the Serial Bridge panel first.", error=True)
            return
        if self._write_worker is not None and self._write_worker.isRunning():
            self._wp_set_status(
                "The Write Text tab is still streaming to the arm — wait for it to "
                "finish (or stop it) before running a waypoint path. Two streams can't "
                "share one serial connection at the same time.", error=True)
            return
        try:
            plan = self._plan_current_path()
        except (ValueError, kinematics.PathPlanningError) as e:
            self._wp_set_status(str(e), error=True)
            return

        # Build the G-code list: home-offset each solved pose, then a move line.
        # Clear the bridge's position tracking first so the FIRST segment's
        # coordinated feed is computed conservatively (we can't know where the
        # physical arm actually is) rather than against a stale leftover pose.
        feed = self.wp_feed.value()
        self.bridge.last_motor_angles = None
        lines = []
        for thetas in plan["thetas"]:
            motor = kinematics.apply_home_offset(thetas)
            lines.append(self.bridge.build_move_gcode(
                motor, feed_deg_per_min=feed,
                per_axis_max_deg_per_min=self._active_axis_speed_limits()))

        self._wp_plan = plan
        self.wp_progress.setMaximum(len(lines))
        self.wp_progress.setValue(0)
        self._wp_set_status(f"Streaming {len(lines)} moves to the arm…")

        self.wp_run_btn.setEnabled(False)
        self.wp_abort_btn.setEnabled(True)

        self._wp_worker = PathStreamWorker(self.bridge, lines, feed)
        self._wp_worker.progress.connect(self._on_wp_progress)
        self._wp_worker.finished_streaming.connect(self._on_wp_finished)
        self._wp_worker.error.connect(self._on_wp_error)
        self._wp_worker.start()

    def _on_wp_progress(self, index, total):
        self.wp_progress.setValue(index)

    def _on_wp_finished(self, sent, aborted):
        self.wp_run_btn.setEnabled(True)
        self.wp_abort_btn.setEnabled(False)
        if aborted:
            self._wp_set_status(
                f"Aborted after {sent} moves (feed-hold sent). Send Resume (~) or "
                "Soft Reset from the Serial Bridge panel to clear the hold.", error=True)
        else:
            self._wp_set_status(f"Path complete — {sent} moves sent.")

    def _on_wp_error(self, msg):
        self.wp_run_btn.setEnabled(True)
        self.wp_abort_btn.setEnabled(False)
        self._wp_set_status(f"Streaming error: {msg}", error=True)

    def _on_wp_abort(self):
        if self._wp_worker is not None and self._wp_worker.isRunning():
            self._wp_worker.request_abort()
            self._wp_set_status("Abort requested — sending feed-hold…", error=True)

    def _wp_set_status(self, text, error=False):
        self.wp_status.setText(text)
        self.wp_status.setStyleSheet("color: red;" if error else "color: green;")

    # -- text writing tab --------------------------------------------------

    def _build_writing_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        # --- text + layout ---
        text_box = QtWidgets.QGroupBox("Text")
        tl = QtWidgets.QGridLayout(text_box)
        tl.setHorizontalSpacing(10)
        tl.setVerticalSpacing(8)
        tl.setContentsMargins(12, 16, 12, 12)

        self.write_text = QtWidgets.QLineEdit("HELLO")
        self.write_text.setMinimumHeight(30)
        self.write_text.setToolTip("A-Z, 0-9, space and basic punctuation. Lowercase is drawn as uppercase.")

        self.write_height = QtWidgets.QDoubleSpinBox()
        self.write_height.setRange(5, 200)
        self.write_height.setValue(30)
        self.write_height.setSuffix(" mm tall")

        self.write_letter_spacing = QtWidgets.QDoubleSpinBox()
        self.write_letter_spacing.setRange(0, 50)
        self.write_letter_spacing.setValue(4)
        self.write_letter_spacing.setSuffix(" mm gap")

        for w in (self.write_height, self.write_letter_spacing):
            w.setMinimumHeight(28)

        tl.addWidget(QtWidgets.QLabel("Word/phrase"), 0, 0)
        tl.addWidget(self.write_text, 0, 1, 1, 3)
        tl.addWidget(QtWidgets.QLabel("Height"), 1, 0)
        tl.addWidget(self.write_height, 1, 1)
        tl.addWidget(QtWidgets.QLabel("Letter gap"), 1, 2)
        tl.addWidget(self.write_letter_spacing, 1, 3)
        col.addWidget(text_box)

        # --- plane placement ---
        place_box = QtWidgets.QGroupBox("Placement on the table (horizontal plane)")
        pl = QtWidgets.QGridLayout(place_box)
        pl.setHorizontalSpacing(10)
        pl.setVerticalSpacing(8)
        pl.setContentsMargins(12, 16, 12, 12)

        self.write_base_x = QtWidgets.QDoubleSpinBox()
        self.write_base_x.setRange(50, 600)
        self.write_base_x.setValue(240)
        self.write_base_x.setSuffix(" mm out")
        self.write_base_x.setToolTip("Reach distance from the base to where the text starts (along X).")

        self.write_center = QtWidgets.QCheckBox("Center left-right")
        self.write_center.setChecked(True)
        self.write_center.setToolTip("Center the word on Y=0 rather than starting at Y=0.")

        self.write_pen_down_z = QtWidgets.QDoubleSpinBox()
        self.write_pen_down_z.setRange(0, 500)
        self.write_pen_down_z.setValue(150)
        self.write_pen_down_z.setSuffix(" mm (paper Z)")
        self.write_pen_down_z.setToolTip(
            "Height of the writing surface — the Z where the marker touches paper. "
            "Adjustable so you can raise/lower the writing plane within the arm's reach.")

        self.write_pen_lift = QtWidgets.QDoubleSpinBox()
        self.write_pen_lift.setRange(2, 100)
        self.write_pen_lift.setValue(20)
        self.write_pen_lift.setSuffix(" mm lift")
        self.write_pen_lift.setToolTip("How far above the paper the marker lifts when travelling between strokes.")

        self.write_max_tilt = QtWidgets.QDoubleSpinBox()
        self.write_max_tilt.setRange(0, 45)
        self.write_max_tilt.setValue(15)
        self.write_max_tilt.setSuffix(" deg tilt")
        self.write_max_tilt.setToolTip(
            "Allowed marker tilt from straight-down. 0 = strictly vertical (cleanest, but "
            "hardest to reach). A few degrees greatly enlarges the writable area and is "
            "visually fine.")

        for w in (self.write_base_x, self.write_pen_down_z, self.write_pen_lift, self.write_max_tilt):
            w.setMinimumHeight(28)

        pl.addWidget(QtWidgets.QLabel("Reach (X)"), 0, 0)
        pl.addWidget(self.write_base_x, 0, 1)
        pl.addWidget(self.write_center, 0, 2, 1, 2)
        pl.addWidget(QtWidgets.QLabel("Paper height"), 1, 0)
        pl.addWidget(self.write_pen_down_z, 1, 1)
        pl.addWidget(QtWidgets.QLabel("Pen lift"), 1, 2)
        pl.addWidget(self.write_pen_lift, 1, 3)
        pl.addWidget(QtWidgets.QLabel("Max tilt"), 2, 0)
        pl.addWidget(self.write_max_tilt, 2, 1)
        col.addWidget(place_box)

        # --- run controls ---
        run_box = QtWidgets.QGroupBox("Plan & write")
        rl = QtWidgets.QGridLayout(run_box)
        rl.setHorizontalSpacing(10)
        rl.setVerticalSpacing(8)
        rl.setContentsMargins(12, 16, 12, 12)

        self.write_feed = QtWidgets.QDoubleSpinBox()
        self.write_feed.setRange(1, 20000)
        self.write_feed.setValue(config.SAFE_FEED_DEG_PER_MIN)
        self.write_feed.setSuffix(" deg/min")
        self.write_feed.setMinimumHeight(28)

        self.write_segment = QtWidgets.QDoubleSpinBox()
        self.write_segment.setRange(0.5, 20)
        self.write_segment.setValue(4.0)
        self.write_segment.setSuffix(" mm/seg")
        self.write_segment.setMinimumHeight(28)
        self.write_segment.setToolTip("Smaller = smoother curves but more commands.")

        preview_btn = QtWidgets.QPushButton("Preview strokes (2D)")
        preview_btn.setMinimumHeight(30)
        preview_btn.clicked.connect(self._on_write_preview)

        simulate_btn = QtWidgets.QPushButton("Simulate (3D, no hardware)")
        simulate_btn.setMinimumHeight(32)
        simulate_btn.clicked.connect(self._on_write_simulate)

        self.write_run_btn = _style_button(QtWidgets.QPushButton("Write on Arm"), "primary")
        self.write_run_btn.setMinimumHeight(32)
        self.write_run_btn.clicked.connect(self._on_write_run)

        self.write_abort_btn = _style_button(QtWidgets.QPushButton("Stop (feed hold)"), "danger")
        self.write_abort_btn.setMinimumHeight(32)
        self.write_abort_btn.setEnabled(False)
        self.write_abort_btn.clicked.connect(self._on_write_abort)

        self.write_progress = QtWidgets.QProgressBar()
        self.write_status = QtWidgets.QLabel("")
        self.write_status.setWordWrap(True)
        self.write_status.setMinimumHeight(48)

        rl.addWidget(QtWidgets.QLabel("Feed"), 0, 0)
        rl.addWidget(self.write_feed, 0, 1)
        rl.addWidget(QtWidgets.QLabel("Segment"), 0, 2)
        rl.addWidget(self.write_segment, 0, 3)
        rl.addWidget(preview_btn, 1, 0, 1, 2)
        rl.addWidget(simulate_btn, 1, 2, 1, 2)
        rl.addWidget(self.write_run_btn, 2, 0, 1, 2)
        rl.addWidget(self.write_abort_btn, 2, 2, 1, 2)
        rl.addWidget(self.write_progress, 3, 0, 1, 4)
        rl.addWidget(self.write_status, 4, 0, 1, 4)

        note = QtWidgets.QLabel(
            "Writes with a single-stroke font, marker pointing ~straight down, on a flat "
            "surface at the 'paper height' Z. The pen lifts between strokes automatically. "
            "The 50.5mm tool offset is accounted for (Layer 2 IK), so the marker tip lands "
            "where planned. Reachability is fully validated before any motion — if the word "
            "doesn't fit, it says which point failed. Writing quality on real hardware "
            "depends on Z-calibration and a compliant marker mount."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        rl.addWidget(note, 5, 0, 1, 4)
        col.addWidget(run_box)

        col.addStretch(1)

        self._write_worker = None
        return tab

    def _build_write_pen_path(self):
        """Build the (x,y,z,psi) pen path from the current writing controls."""
        text = self.write_text.text()
        if not text.strip():
            raise ValueError("Enter a word or phrase to write.")
        height = self.write_height.value()
        strokes, width, _ = hershey_font.text_to_strokes(
            text, height_mm=height, letter_spacing_mm=self.write_letter_spacing.value())
        if not strokes:
            raise ValueError("Nothing to draw (only spaces / unsupported characters).")
        base_y = -width / 2.0 if self.write_center.isChecked() else 0.0
        pen_down_z = self.write_pen_down_z.value()
        pen_up_z = pen_down_z + self.write_pen_lift.value()
        pen_path = hershey_font.strokes_to_pen_path(
            strokes, base_x=self.write_base_x.value(), base_y=base_y,
            pen_down_z=pen_down_z, pen_up_z=pen_up_z, psi_deg=-90.0)
        return pen_path, strokes, width

    def _plan_write(self):
        """Densify + IK-solve the current writing path with clamped tilt. Returns
        (thetas_list, dense_poses, psi_used) or raises."""
        pen_path, _, _ = self._build_write_pen_path()
        return hershey_font.plan_writing_path(
            pen_path,
            solve_fn=lambda x, y, z, psi: kinematics.solve_ik_constrained(
                x, y, z, psi, tool_offset=self._current_tool_offset()),
            interpolate_fn=kinematics._interpolate_poses,
            max_tilt_deg=self.write_max_tilt.value(),
            max_segment_mm=self.write_segment.value())

    def _on_write_preview(self):
        try:
            _, strokes, width = self._build_write_pen_path()
        except ValueError as e:
            self._write_set_status(str(e), error=True)
            return
        # Draw the flat 2D strokes into the 3D canvas at the paper plane, as a preview.
        pen_down_z = self.write_pen_down_z.value()
        base_x = self.write_base_x.value()
        base_y = -width / 2.0 if self.write_center.isChecked() else 0.0
        path_xyz = []
        for st in strokes:
            for (u, v) in st:
                path_xyz.append((base_x + u, base_y + v, pen_down_z))
        self.canvas.plot_pose(self.current_thetas, path_xyz=path_xyz,
                              tool_offset=self._current_tool_offset())
        self._write_set_status(
            f"Preview: '{self.write_text.text()}' = {len(strokes)} strokes, "
            f"{width:.0f}mm wide. (2D layout on the paper plane; not yet reach-checked — "
            "use Simulate for that.)")

    def _on_write_simulate(self):
        try:
            thetas_list, dense, psi_used = self._plan_write()
        except (ValueError, hershey_font.WritingPlanError) as e:
            self._write_set_status(str(e), error=True)
            return

        path_xyz = [p[:3] for p in dense]
        self._write_set_status(
            f"Planned {len(thetas_list)} points, all reachable within joint limits "
            f"(marker tilt stayed within {self.write_max_tilt.value():.0f} deg of vertical). "
            "Animating — no hardware commands sent.")

        self._write_sim_index = 0
        self._write_sim_thetas = thetas_list
        self._write_sim_path = path_xyz
        if not hasattr(self, "_write_sim_timer"):
            self._write_sim_timer = QtCore.QTimer(self)
            self._write_sim_timer.timeout.connect(self._write_sim_step)
        self._write_sim_timer.start(30)

    def _write_sim_step(self):
        if self._write_sim_index >= len(self._write_sim_thetas):
            self._write_sim_timer.stop()
            return
        thetas = self._write_sim_thetas[self._write_sim_index]
        self.canvas.plot_pose(thetas, path_xyz=self._write_sim_path,
                              tool_offset=self._current_tool_offset())
        self._write_sim_index += 1

    def _on_write_run(self):
        if not self.bridge.is_connected():
            self._write_set_status("Not connected. Connect to the arm in the Serial Bridge panel first.", error=True)
            return
        if self._wp_worker is not None and self._wp_worker.isRunning():
            self._write_set_status(
                "The Waypoint Path tab is still streaming to the arm — wait for it to "
                "finish (or stop it) before writing. Two streams can't share one "
                "serial connection at the same time.", error=True)
            return
        try:
            thetas_list, dense, psi_used = self._plan_write()
        except (ValueError, hershey_font.WritingPlanError) as e:
            self._write_set_status(str(e), error=True)
            return

        feed = self.write_feed.value()
        self.bridge.last_motor_angles = None   # see note in _on_wp_run
        lines = []
        for thetas in thetas_list:
            motor = kinematics.apply_home_offset(thetas)
            lines.append(self.bridge.build_move_gcode(
                motor, feed_deg_per_min=feed,
                per_axis_max_deg_per_min=self._active_axis_speed_limits()))

        self.write_progress.setMaximum(len(lines))
        self.write_progress.setValue(0)
        self._write_set_status(f"Writing '{self.write_text.text()}' — streaming {len(lines)} moves…")

        self.write_run_btn.setEnabled(False)
        self.write_abort_btn.setEnabled(True)

        self._write_worker = PathStreamWorker(self.bridge, lines, feed)
        self._write_worker.progress.connect(lambda i, t: self.write_progress.setValue(i))
        self._write_worker.finished_streaming.connect(self._on_write_finished)
        self._write_worker.error.connect(self._on_write_error)
        self._write_worker.start()

    def _on_write_finished(self, sent, aborted):
        self.write_run_btn.setEnabled(True)
        self.write_abort_btn.setEnabled(False)
        if aborted:
            self._write_set_status(
                f"Aborted after {sent} moves (feed-hold sent). Send Resume (~) or Soft Reset "
                "from the Serial Bridge panel to clear the hold.", error=True)
        else:
            self._write_set_status(f"Done — wrote '{self.write_text.text()}' ({sent} moves).")

    def _on_write_error(self, msg):
        self.write_run_btn.setEnabled(True)
        self.write_abort_btn.setEnabled(False)
        self._write_set_status(f"Streaming error: {msg}", error=True)

    def _on_write_abort(self):
        if self._write_worker is not None and self._write_worker.isRunning():
            self._write_worker.request_abort()
            self._write_set_status("Abort requested — sending feed-hold…", error=True)

    def _write_set_status(self, text, error=False):
        self.write_status.setText(text)
        self.write_status.setStyleSheet("color: red;" if error else "color: green;")

    # -- motion tuning tab -------------------------------------------------

    def _build_motion_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        profile = config.load_motion_profile()
        self._motion_profile = profile

        # --- per-axis grid ---
        grid_box = QtWidgets.QGroupBox("Per-joint motion limits")
        gl = QtWidgets.QGridLayout(grid_box)
        gl.setHorizontalSpacing(10)
        gl.setVerticalSpacing(8)
        gl.setContentsMargins(12, 16, 12, 12)

        headers = ["Joint", "Max speed", "Acceleration", "Steps per degree"]
        for c, h in enumerate(headers):
            lbl = QtWidgets.QLabel(h)
            lbl.setStyleSheet("font-weight: 600; color: #3a4658;")
            gl.addWidget(lbl, 0, c)

        self.motion_inputs = {"max_speed_deg_per_min": [],
                              "accel_deg_per_sec2": [],
                              "steps_per_deg": []}

        joint_names = ["Base (36:1)", "Shoulder (36:1)", "Elbow (36:1)", "Wrist (6:1)"]
        for i, name in enumerate(joint_names):
            row = i + 1
            name_lbl = QtWidgets.QLabel(name)
            name_lbl.setMinimumWidth(120)
            gl.addWidget(name_lbl, row, 0)

            speed = QtWidgets.QDoubleSpinBox()
            speed.setRange(1, 60000)
            speed.setDecimals(0)
            speed.setSuffix(" deg/min")
            speed.setValue(profile["max_speed_deg_per_min"][i])
            speed.setMinimumHeight(28)
            speed.setToolTip(
                "Hard speed ceiling for this joint. Pushed to grbl as "
                f"{config.GRBL_MAX_RATE_SETTINGS[i]}, and used by the app to work out a "
                "coordinated feed that keeps every joint under its own limit.")
            gl.addWidget(speed, row, 1)
            self.motion_inputs["max_speed_deg_per_min"].append(speed)

            accel = QtWidgets.QDoubleSpinBox()
            accel.setRange(0.1, 10000)
            accel.setDecimals(1)
            accel.setSuffix(" deg/s²")
            accel.setValue(profile["accel_deg_per_sec2"][i])
            accel.setMinimumHeight(28)
            accel.setToolTip(
                f"Acceleration for this joint (grbl {config.GRBL_ACCEL_SETTINGS[i]}). "
                "Higher values ramp through a resonance band quickly instead of "
                "dwelling in it — often the fix for a joint that's rough at low speed.")
            gl.addWidget(accel, row, 2)
            self.motion_inputs["accel_deg_per_sec2"].append(accel)

            steps = QtWidgets.QDoubleSpinBox()
            steps.setRange(0.001, 10000)
            steps.setDecimals(4)
            steps.setValue(profile["steps_per_deg"][i])
            steps.setMinimumHeight(28)
            steps.setToolTip(
                f"Steps per output degree (grbl {config.GRBL_SETTING_NUMBERS[i]}). "
                "Only change this if you alter that axis's microstepping jumpers — "
                "and if you do, the jumpers and this number must agree or every "
                "move on this joint will be wrong by that factor.")
            gl.addWidget(steps, row, 3)
            self.motion_inputs["steps_per_deg"].append(steps)

        col.addWidget(grid_box)

        # --- microstepping helper ---
        micro_box = QtWidgets.QGroupBox("Microstepping helper")
        ml = QtWidgets.QGridLayout(micro_box)
        ml.setHorizontalSpacing(10)
        ml.setVerticalSpacing(8)
        ml.setContentsMargins(12, 16, 12, 12)

        self.micro_joint = QtWidgets.QComboBox()
        self.micro_joint.addItems(joint_names)
        self.micro_joint.setMinimumHeight(28)

        self.micro_mode = QtWidgets.QComboBox()
        self.micro_mode.addItems(["Full step", "1/2", "1/4", "1/8", "1/16", "1/32"])
        self.micro_mode.setMinimumHeight(28)
        self.micro_mode.setToolTip(
            "Sets that joint's steps/degree to match the chosen microstepping. "
            "You must also set the driver's physical jumpers to match.")

        apply_micro = QtWidgets.QPushButton("Set steps/deg for this microstepping")
        apply_micro.setMinimumHeight(30)
        apply_micro.clicked.connect(self._on_apply_microstepping)

        ml.addWidget(QtWidgets.QLabel("Joint"), 0, 0)
        ml.addWidget(self.micro_joint, 0, 1)
        ml.addWidget(QtWidgets.QLabel("Mode"), 0, 2)
        ml.addWidget(self.micro_mode, 0, 3)
        ml.addWidget(apply_micro, 1, 0, 1, 4)

        micro_note = QtWidgets.QLabel(
            "Microstepping is the most effective fix for a joint that feels like it's "
            "slamming into each step. It subdivides every full step so the rotor eases "
            "between positions instead of being flung there. Remember to install the "
            "matching MODE jumpers under that driver socket — this button only updates "
            "the number, it can't move the jumpers for you."
        )
        micro_note.setWordWrap(True)
        micro_note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        ml.addWidget(micro_note, 2, 0, 1, 4)
        col.addWidget(micro_box)

        # --- actions ---
        act_box = QtWidgets.QGroupBox("Apply")
        al = QtWidgets.QGridLayout(act_box)
        al.setHorizontalSpacing(10)
        al.setVerticalSpacing(8)
        al.setContentsMargins(12, 16, 12, 12)

        save_btn = QtWidgets.QPushButton("Save profile")
        save_btn.setMinimumHeight(30)
        save_btn.setToolTip("Save these values to motion_profile.json so they persist between runs.")
        save_btn.clicked.connect(self._on_save_motion_profile)

        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_motion_profile)

        push_btn = _style_button(QtWidgets.QPushButton("Push to arm (write to EEPROM)"), "primary")
        push_btn.setMinimumHeight(32)
        push_btn.setToolTip(
            "Write $100-$103 (steps/deg), $110-$113 (max rate) and $120-$123 "
            "(acceleration) into the board's EEPROM. Persists across power cycles.")
        push_btn.clicked.connect(self._on_push_motion_profile)

        read_btn = QtWidgets.QPushButton("Read current settings ($$)")
        read_btn.setMinimumHeight(30)
        read_btn.setToolTip("Dump the board's current settings into the log so you can compare.")
        read_btn.clicked.connect(self._on_read_grbl_settings)

        self.motion_status = QtWidgets.QLabel("")
        self.motion_status.setWordWrap(True)
        self.motion_status.setMinimumHeight(40)

        al.addWidget(save_btn, 0, 0)
        al.addWidget(reload_btn, 0, 1)
        al.addWidget(read_btn, 1, 0)
        al.addWidget(push_btn, 1, 1)
        al.addWidget(self.motion_status, 2, 0, 1, 2)

        note = QtWidgets.QLabel(
            "G-code's F is one coordinated feed for the whole move, not a per-axis value — "
            "so per-joint speed is enforced two ways. grbl's $110-$113 are hard ceilings in "
            "firmware (push them here), and the app separately works out the fastest F that "
            "keeps every joint under its own limit for each move. If $110-$113 are left lower "
            "than the feed the app asks for, grbl silently clamps every move to them, so "
            "pushing this profile is what makes these numbers real on the hardware."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        al.addWidget(note, 3, 0, 1, 2)
        col.addWidget(act_box)

        col.addStretch(1)
        return tab

    def _current_motion_profile(self):
        return {key: [w.value() for w in widgets]
                for key, widgets in self.motion_inputs.items()}

    def _on_apply_microstepping(self):
        i = self.micro_joint.currentIndex()
        divisor = [1, 2, 4, 8, 16, 32][self.micro_mode.currentIndex()]
        base_steps = config.GRBL_STEPS_PER_DEGREE[i]   # full-step value for this joint
        new_val = base_steps * divisor
        self.motion_inputs["steps_per_deg"][i].setValue(new_val)
        self._motion_set_status(
            f"{self.micro_joint.currentText()} steps/degree set to {new_val:.4f} "
            f"for {self.micro_mode.currentText()} microstepping. Set the driver's MODE "
            "jumpers to match, then push to the arm.")

    def _on_save_motion_profile(self):
        profile = self._current_motion_profile()
        config.save_motion_profile(profile)
        self._motion_profile = profile
        self._motion_set_status("Motion profile saved to motion_profile.json.")
        self._log("Saved per-axis motion profile to disk.")

    def _on_reload_motion_profile(self):
        profile = config.load_motion_profile()
        for key, widgets in self.motion_inputs.items():
            for w, v in zip(widgets, profile[key]):
                w.blockSignals(True)
                w.setValue(v)
                w.blockSignals(False)
        self._motion_profile = profile
        self._motion_set_status("Reloaded motion profile from disk.")

    def _on_push_motion_profile(self):
        if not self.bridge.is_connected():
            self._motion_set_status("Not connected — connect to the arm first.", error=True)
            return
        if self._serial_busy():
            self._motion_set_status(
                "A waypoint or writing stream is in progress — wait for it to finish "
                "(or stop it) before pushing settings.", error=True)
            return
        profile = self._current_motion_profile()
        try:
            results = self.bridge.push_motion_profile(profile)
        except serial_bridge.SerialBridgeError as e:
            self._motion_set_status(f"Push failed: {e}", error=True)
            return
        self._motion_profile = profile
        for setting, value, response in results:
            self._log(f"  -> {setting}={value}  {' '.join(response)}")
        self._motion_set_status(
            f"Pushed {len(results)} settings to the board's EEPROM "
            "($100-$103, $110-$113, $120-$123). These persist across power cycles.")

    def _on_read_grbl_settings(self):
        if not self.bridge.is_connected():
            self._motion_set_status("Not connected — connect to the arm first.", error=True)
            return
        if self._serial_busy():
            self._motion_set_status(
                "A waypoint or writing stream is in progress — wait for it to finish "
                "(or stop it) before reading settings.", error=True)
            return
        try:
            response = self.bridge.send_raw("$$")
        except serial_bridge.SerialBridgeError as e:
            self._motion_set_status(f"Read failed: {e}", error=True)
            return
        for line in response:
            self._log(f"  <- {line}")
        self._motion_set_status(
            "Current board settings dumped to the log below — compare $100-$103, "
            "$110-$113 and $120-$123 against the values above.")

    def _motion_set_status(self, text, error=False):
        self.motion_status.setText(text)
        self.motion_status.setStyleSheet("color: #b42318;" if error else "color: #1a7f37;")

    def _active_axis_speed_limits(self):
        """Per-axis max speeds currently set in the Motion Tuning tab, used for
        the coordinated feed calculation on every move the app sends."""
        if hasattr(self, "motion_inputs"):
            return [w.value() for w in self.motion_inputs["max_speed_deg_per_min"]]
        return config.load_motion_profile()["max_speed_deg_per_min"]

    def _serial_busy(self):
        """
        True if a background PathStreamWorker (waypoint or writing) is
        already streaming to the arm's serial connection. send_line() blocks
        the calling thread until it sees grbl's next 'ok'/'error' response --
        if the main thread reads from the same port while a worker thread is
        doing the same, the two race for whichever line arrives next, and
        either side can silently steal the other's expected response,
        causing a spurious timeout. This affects any call that reads a
        response (send_line, send_raw, request_status). Only the write-only
        real-time commands -- feed hold (!), resume (~), and soft reset
        (Ctrl-X) -- don't read a reply, so they stay safe to send at any
        time (that's the point: feed hold is the panic-stop for a running
        stream, so it must never be blocked by this guard).
        """
        return ((self._wp_worker is not None and self._wp_worker.isRunning()) or
                (self._write_worker is not None and self._write_worker.isRunning()))

    # -- gripper tab -------------------------------------------------------

    def _build_gripper_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        cfg = config.load_gripper_config()

        # --- connection ---
        conn_box = QtWidgets.QGroupBox("Connection (Nano gripper controller)")
        cl = QtWidgets.QGridLayout(conn_box)
        cl.setHorizontalSpacing(10)
        cl.setVerticalSpacing(8)
        cl.setContentsMargins(12, 16, 12, 12)

        self.grip_port = QtWidgets.QComboBox()
        self.grip_port.setMinimumHeight(28)

        grip_refresh = QtWidgets.QPushButton("Refresh")
        grip_refresh.setMinimumHeight(28)
        grip_refresh.clicked.connect(self._refresh_gripper_ports)

        grip_detect = QtWidgets.QPushButton("Auto-detect")
        grip_detect.setMinimumHeight(28)
        grip_detect.setToolTip(
            "Probe each serial port for the ARMGRIP identify banner. Saves guessing "
            "which COM port is the Nano when both Arduinos are plugged in.")
        grip_detect.clicked.connect(self._on_gripper_autodetect)

        self.grip_connect_btn = _style_button(QtWidgets.QPushButton("Connect"), "primary")
        self.grip_connect_btn.setMinimumHeight(30)
        self.grip_connect_btn.clicked.connect(self._on_gripper_connect_toggle)

        self.grip_conn_status = QtWidgets.QLabel("● Disconnected")
        self.grip_conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
        self.grip_fw_label = QtWidgets.QLabel("")
        self.grip_fw_label.setWordWrap(True)
        self.grip_fw_label.setStyleSheet("font-family: Consolas, Menlo, monospace; color: #3a4658;")

        cl.addWidget(QtWidgets.QLabel("Port"), 0, 0)
        cl.addWidget(self.grip_port, 0, 1)
        cl.addWidget(grip_refresh, 0, 2)
        cl.addWidget(grip_detect, 0, 3)
        cl.addWidget(self.grip_connect_btn, 1, 3)
        cl.addWidget(self.grip_conn_status, 1, 0, 1, 3)
        cl.addWidget(self.grip_fw_label, 2, 0, 1, 4)
        col.addWidget(conn_box)

        # --- manual control ---
        ctrl_box = QtWidgets.QGroupBox("Manual control")
        ml = QtWidgets.QGridLayout(ctrl_box)
        ml.setHorizontalSpacing(10)
        ml.setVerticalSpacing(8)
        ml.setContentsMargins(12, 16, 12, 12)

        self.grip_open_btn = _style_button(QtWidgets.QPushButton("Open"), "primary")
        self.grip_open_btn.setMinimumHeight(40)
        self.grip_open_btn.clicked.connect(lambda: self._gripper_cmd(
            lambda: self.gripper.open_gripper(channel=self._gripper_channel()), "Opened"))

        self.grip_close_btn = _style_button(QtWidgets.QPushButton("Close"), "primary")
        self.grip_close_btn.setMinimumHeight(40)
        self.grip_close_btn.clicked.connect(lambda: self._gripper_cmd(
            lambda: self.gripper.close_gripper(channel=self._gripper_channel()), "Closed"))

        self.grip_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.grip_slider.setMinimum(int(cfg["min_angle"]))
        self.grip_slider.setMaximum(int(cfg["max_angle"]))
        self.grip_slider.setValue(int(cfg["open_angle"]))
        self.grip_slider.setMinimumWidth(200)
        self.grip_slider.valueChanged.connect(self._on_gripper_slider)

        self.grip_angle = QtWidgets.QDoubleSpinBox()
        self.grip_angle.setRange(0, 180)
        self.grip_angle.setDecimals(1)
        self.grip_angle.setSuffix("°")
        self.grip_angle.setValue(cfg["open_angle"])
        self.grip_angle.setMinimumHeight(28)
        self.grip_angle.valueChanged.connect(
            lambda v: self.grip_slider.setValue(int(v)))

        go_btn = QtWidgets.QPushButton("Go to angle")
        go_btn.setMinimumHeight(30)
        go_btn.clicked.connect(self._on_gripper_goto)

        detach_btn = QtWidgets.QPushButton("Detach (go limp)")
        detach_btn.setMinimumHeight(30)
        detach_btn.setToolTip(
            "Stop sending pulses so the servo releases its holding torque. "
            "Useful to stop it buzzing/heating while idle.")
        detach_btn.clicked.connect(lambda: self._gripper_cmd(
            lambda: self.gripper.detach(channel=self._gripper_channel()), "Detached"))

        status_btn = QtWidgets.QPushButton("Query status")
        status_btn.setMinimumHeight(30)
        status_btn.clicked.connect(self._on_gripper_status)

        ml.addWidget(self.grip_open_btn, 0, 0, 1, 2)
        ml.addWidget(self.grip_close_btn, 0, 2, 1, 2)
        ml.addWidget(QtWidgets.QLabel("Position"), 1, 0)
        ml.addWidget(self.grip_slider, 1, 1, 1, 2)
        ml.addWidget(self.grip_angle, 1, 3)
        ml.addWidget(go_btn, 2, 0, 1, 2)
        ml.addWidget(detach_btn, 2, 2)
        ml.addWidget(status_btn, 2, 3)
        col.addWidget(ctrl_box)

        # --- calibration ---
        cal_box = QtWidgets.QGroupBox("Calibration")
        gl = QtWidgets.QGridLayout(cal_box)
        gl.setHorizontalSpacing(10)
        gl.setVerticalSpacing(8)
        gl.setContentsMargins(12, 16, 12, 12)

        def spin(val, lo, hi, suffix, dec=1):
            s = QtWidgets.QDoubleSpinBox()
            s.setRange(lo, hi); s.setDecimals(dec); s.setSuffix(suffix)
            s.setValue(val); s.setMinimumHeight(28)
            return s

        self.grip_cfg = {
            "open_angle":       spin(cfg["open_angle"], 0, 180, "°"),
            "close_angle":      spin(cfg["close_angle"], 0, 180, "°"),
            "min_angle":        spin(cfg["min_angle"], 0, 180, "°"),
            "max_angle":        spin(cfg["max_angle"], 0, 180, "°"),
            "rate_deg_per_sec": spin(cfg["rate_deg_per_sec"], 1, 1000, " °/s"),
            "min_pulse_us":     spin(cfg["min_pulse_us"], 200, 3000, " µs", 0),
            "max_pulse_us":     spin(cfg["max_pulse_us"], 200, 3000, " µs", 0),
        }
        self.grip_cfg["min_angle"].setToolTip(
            "Travel limits. The firmware REFUSES angles outside these rather than "
            "silently clamping — a servo driven into a mechanical stop stalls and "
            "overheats, so an out-of-range request is worth surfacing as an error.")
        self.grip_cfg["max_angle"].setToolTip(self.grip_cfg["min_angle"].toolTip())
        self.grip_cfg["min_pulse_us"].setToolTip(
            "Servo pulse-width range. 500–2400µs suits an MG90S; adjust if your "
            "servo has a different range or you want to restrict its sweep.")

        self.grip_channel = QtWidgets.QSpinBox()
        self.grip_channel.setRange(0, 3)
        self.grip_channel.setValue(int(cfg["channel"]))
        self.grip_channel.setMinimumHeight(28)
        self.grip_channel.setToolTip("Which PCA9685 channel the gripper servo is plugged into.")

        gl.addWidget(QtWidgets.QLabel("Open angle"), 0, 0)
        gl.addWidget(self.grip_cfg["open_angle"], 0, 1)
        gl.addWidget(QtWidgets.QLabel("Close angle"), 0, 2)
        gl.addWidget(self.grip_cfg["close_angle"], 0, 3)
        gl.addWidget(QtWidgets.QLabel("Min limit"), 1, 0)
        gl.addWidget(self.grip_cfg["min_angle"], 1, 1)
        gl.addWidget(QtWidgets.QLabel("Max limit"), 1, 2)
        gl.addWidget(self.grip_cfg["max_angle"], 1, 3)
        gl.addWidget(QtWidgets.QLabel("Sweep rate"), 2, 0)
        gl.addWidget(self.grip_cfg["rate_deg_per_sec"], 2, 1)
        gl.addWidget(QtWidgets.QLabel("Channel"), 2, 2)
        gl.addWidget(self.grip_channel, 2, 3)
        gl.addWidget(QtWidgets.QLabel("Pulse min"), 3, 0)
        gl.addWidget(self.grip_cfg["min_pulse_us"], 3, 1)
        gl.addWidget(QtWidgets.QLabel("Pulse max"), 3, 2)
        gl.addWidget(self.grip_cfg["max_pulse_us"], 3, 3)

        save_btn = QtWidgets.QPushButton("Save")
        save_btn.setMinimumHeight(30)
        save_btn.clicked.connect(self._on_gripper_save_config)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_gripper_reload_config)
        push_btn = _style_button(QtWidgets.QPushButton("Push to Nano"), "primary")
        push_btn.setMinimumHeight(30)
        push_btn.setToolTip("Send these settings to the firmware. Done automatically on connect.")
        push_btn.clicked.connect(self._on_gripper_push_config)

        gl.addWidget(save_btn, 4, 0)
        gl.addWidget(reload_btn, 4, 1)
        gl.addWidget(push_btn, 4, 2, 1, 2)
        col.addWidget(cal_box)

        # --- safety ---
        safe_box = QtWidgets.QGroupBox("Safety")
        sl = QtWidgets.QHBoxLayout(safe_box)
        sl.setSpacing(10)
        sl.setContentsMargins(12, 16, 12, 12)

        kill_btn = _style_button(QtWidgets.QPushButton("■  Release outputs"), "danger")
        kill_btn.setMinimumHeight(34)
        kill_btn.setToolTip(
            "Hardware output disable via the PCA9685 OE pin — kills every servo "
            "signal instantly regardless of firmware state.")
        kill_btn.clicked.connect(lambda: self._gripper_cmd(
            self.gripper.kill_outputs, "Outputs released (OE high)"))

        restore_btn = QtWidgets.QPushButton("Restore outputs")
        restore_btn.setMinimumHeight(34)
        restore_btn.clicked.connect(lambda: self._gripper_cmd(
            self.gripper.restore_outputs, "Outputs restored"))

        sl.addWidget(kill_btn)
        sl.addWidget(restore_btn)
        col.addWidget(safe_box)

        self.grip_status = QtWidgets.QLabel("")
        self.grip_status.setWordWrap(True)
        self.grip_status.setMinimumHeight(40)
        col.addWidget(self.grip_status)

        note = QtWidgets.QLabel(
            "The gripper runs on a separate Nano over its own USB connection — grbl owns "
            "Timer1 on the Uno, so servos can't share it. Because the two boards are "
            "independent, a gripper command sent while the arm still has moves buffered "
            "would fire early; for now drive them one at a time. Coordinated "
            "move-then-grip sequencing is the next piece of work."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        col.addWidget(note)

        col.addStretch(1)
        self._refresh_gripper_ports()
        self._set_gripper_controls_enabled(False)
        return tab

    # -- gripper handlers ---------------------------------------------------

    def _gripper_channel(self):
        return int(self.grip_channel.value())

    def _current_gripper_config(self):
        cfg = {k: w.value() for k, w in self.grip_cfg.items()}
        cfg["channel"] = self._gripper_channel()
        return cfg

    def _set_gripper_controls_enabled(self, enabled):
        for w in (self.grip_open_btn, self.grip_close_btn, self.grip_slider,
                  self.grip_angle):
            w.setEnabled(enabled)

    def _grip_set_status(self, text, error=False):
        self.grip_status.setText(text)
        self.grip_status.setStyleSheet("color: #b42318;" if error else "color: #1a7f37;")

    def _refresh_gripper_ports(self):
        self.grip_port.clear()
        for label, device in gripper_bridge.GripperBridge.list_ports():
            self.grip_port.addItem(label, device)
        if self.grip_port.count() == 0:
            self.grip_port.addItem("(no serial ports found)", None)

    def _on_gripper_autodetect(self):
        # Skip the port grbl is already using so we don't disturb it.
        exclude = ()
        try:
            if self.bridge.is_connected():
                exclude = (self.port_combo.currentData(),)
        except Exception:
            pass
        self._grip_set_status("Probing serial ports for the ARMGRIP banner…")
        QtWidgets.QApplication.processEvents()
        device, ident = gripper_bridge.GripperBridge.auto_detect(exclude=exclude)
        if device is None:
            self._grip_set_status(
                "No ARMGRIP controller found. Check the Nano is plugged in and "
                "flashed with nano_gripper.ino.", error=True)
            return
        for i in range(self.grip_port.count()):
            if self.grip_port.itemData(i) == device:
                self.grip_port.setCurrentIndex(i)
                break
        self._grip_set_status(f"Found gripper controller on {device} — {ident}")

    def _on_gripper_connect_toggle(self):
        if self.gripper.is_connected():
            self.gripper.disconnect()
            self.grip_connect_btn.setText("Connect")
            self.grip_conn_status.setText("● Disconnected")
            self.grip_conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
            self.grip_fw_label.setText("")
            self._set_gripper_controls_enabled(False)
            self._log("Gripper: disconnected.")
            return

        device = self.grip_port.currentData()
        if not device:
            self._grip_set_status("No serial port selected.", error=True)
            return
        try:
            self.gripper.connect(device)
        except gripper_bridge.GripperBridgeError as e:
            self.grip_conn_status.setText("● Connection failed")
            self.grip_conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
            self._grip_set_status(str(e), error=True)
            return

        for line in self.gripper.startup_banner:
            self._log(f"  gripper <- {line}")

        if gripper_bridge.IDENTIFY_TOKEN not in (self.gripper.firmware_id or ""):
            self._grip_set_status(
                f"Connected to {device}, but it didn't identify as an ARMGRIP controller. "
                "Is this the right port, or does the Nano need flashing?", error=True)

        self.grip_connect_btn.setText("Disconnect")
        self.grip_conn_status.setText(f"● Connected  ({device})")
        self.grip_conn_status.setStyleSheet("color: #1a7f37; font-weight: 600;")
        self.grip_fw_label.setText(self.gripper.firmware_id)
        self._set_gripper_controls_enabled(True)

        if not self.gripper.pca_ok():
            # This is the difference between "the command failed" and "the
            # servo driver isn't on the bus at all", and it's worth calling out
            # loudly because the symptom otherwise is a silent dead servo.
            self._grip_set_status(
                "Connected, but the firmware reports the PCA9685 is NOT responding on I2C. "
                "Check SDA/SCL wiring and that the board is at address 0x40 — servos "
                "won't move until this is fixed.", error=True)
            return

        # Push the saved configuration so firmware and app agree immediately.
        try:
            self.gripper.push_config(self._current_gripper_config())
            self._grip_set_status(f"Connected to {device}. Settings pushed to the Nano.")
        except gripper_bridge.GripperBridgeError as e:
            self._grip_set_status(f"Connected, but pushing settings failed: {e}", error=True)

    def _gripper_cmd(self, fn, success_msg):
        """Run a gripper command, turning firmware errors into readable status."""
        if not self.gripper.is_connected():
            self._grip_set_status("Not connected to the gripper controller.", error=True)
            return False
        try:
            fn()
        except gripper_bridge.GripperCommandError as e:
            self._grip_set_status(f"Rejected by firmware: {e.reason}", error=True)
            return False
        except gripper_bridge.GripperBridgeError as e:
            self._grip_set_status(str(e), error=True)
            return False
        self._grip_set_status(success_msg)
        return True

    def _on_gripper_slider(self, value):
        self.grip_angle.blockSignals(True)
        self.grip_angle.setValue(float(value))
        self.grip_angle.blockSignals(False)

    def _on_gripper_goto(self):
        angle = self.grip_angle.value()
        self._gripper_cmd(
            lambda: self.gripper.move_to(angle, channel=self._gripper_channel()),
            f"Moving to {angle:.1f}°")

    def _on_gripper_status(self):
        if not self.gripper.is_connected():
            self._grip_set_status("Not connected to the gripper controller.", error=True)
            return
        try:
            line = self.gripper.status(channel=self._gripper_channel())
        except gripper_bridge.GripperBridgeError as e:
            self._grip_set_status(str(e), error=True)
            return
        self._log(f"  gripper <- {line}")
        self._grip_set_status(line)

    def _on_gripper_save_config(self):
        cfg = self._current_gripper_config()
        config.save_gripper_config(cfg)
        self.grip_slider.setMinimum(int(cfg["min_angle"]))
        self.grip_slider.setMaximum(int(cfg["max_angle"]))
        self._grip_set_status("Gripper settings saved to gripper_config.json.")
        self._log("Saved gripper configuration to disk.")

    def _on_gripper_reload_config(self):
        cfg = config.load_gripper_config()
        for key, w in self.grip_cfg.items():
            w.blockSignals(True); w.setValue(cfg[key]); w.blockSignals(False)
        self.grip_channel.setValue(int(cfg["channel"]))
        self.grip_slider.setMinimum(int(cfg["min_angle"]))
        self.grip_slider.setMaximum(int(cfg["max_angle"]))
        self._grip_set_status("Reloaded gripper settings from disk.")

    def _on_gripper_push_config(self):
        if not self.gripper.is_connected():
            self._grip_set_status("Not connected to the gripper controller.", error=True)
            return
        try:
            results = self.gripper.push_config(self._current_gripper_config())
        except gripper_bridge.GripperBridgeError as e:
            self._grip_set_status(f"Push failed: {e}", error=True)
            return
        for name, _resp in results:
            self._log(f"  gripper -> {name} set")
        self._grip_set_status("Settings pushed to the Nano.")

    def _build_serial_panel(self):
        box = QtWidgets.QGroupBox("Arm Connection && Machine Control")
        outer = QtWidgets.QVBoxLayout(box)
        outer.setSpacing(10)
        outer.setContentsMargins(12, 16, 12, 12)

        # --- Row of three sub-groups: Connection | Machine control | Motion defaults ---
        top_row = QtWidgets.QHBoxLayout()
        top_row.setSpacing(12)

        # Connection sub-group
        conn_box = QtWidgets.QGroupBox("Connection")
        conn = QtWidgets.QGridLayout(conn_box)
        conn.setHorizontalSpacing(8)
        conn.setVerticalSpacing(8)

        self.port_combo = QtWidgets.QComboBox()
        self.port_combo.setMinimumHeight(28)
        refresh_btn = QtWidgets.QPushButton("Refresh")
        refresh_btn.setToolTip("Re-scan for available serial ports.")
        refresh_btn.clicked.connect(self._refresh_ports)

        self.baud_input = QtWidgets.QSpinBox()
        self.baud_input.setRange(1200, 921600)
        self.baud_input.setValue(config.DEFAULT_BAUD)
        self.baud_input.setMinimumHeight(28)

        self.connect_btn = _style_button(QtWidgets.QPushButton("Connect"), "primary")
        self.connect_btn.setMinimumHeight(30)
        self.connect_btn.clicked.connect(self._on_connect_toggle)

        self.conn_status = QtWidgets.QLabel("● Disconnected")
        self.conn_status.setStyleSheet("color: #b42318; font-weight: 600;")

        conn.addWidget(QtWidgets.QLabel("Port"), 0, 0)
        conn.addWidget(self.port_combo, 0, 1)
        conn.addWidget(refresh_btn, 0, 2)
        conn.addWidget(QtWidgets.QLabel("Baud"), 1, 0)
        conn.addWidget(self.baud_input, 1, 1)
        conn.addWidget(self.connect_btn, 1, 2)
        conn.addWidget(self.conn_status, 2, 0, 1, 3)
        top_row.addWidget(conn_box, 2)

        # Machine control sub-group
        mc_box = QtWidgets.QGroupBox("Machine Control")
        mc = QtWidgets.QGridLayout(mc_box)
        mc.setHorizontalSpacing(8)
        mc.setVerticalSpacing(8)

        self.hold_btn = _style_button(QtWidgets.QPushButton("■  Stop (feed hold)"), "danger")
        self.hold_btn.setToolTip("Immediately pause motion (grbl realtime feed-hold '!'). Use as a panic stop.")
        self.hold_btn.clicked.connect(self._on_feed_hold)

        resume_btn = QtWidgets.QPushButton("▶  Resume")
        resume_btn.setToolTip("Resume after a feed-hold (grbl realtime '~').")
        resume_btn.clicked.connect(self._on_resume)

        reset_btn = _style_button(QtWidgets.QPushButton("⟳  Soft reset"), "danger")
        reset_btn.setToolTip("Soft-reset grbl (Ctrl-X). Clears motion state; needed after some alarms.")
        reset_btn.clicked.connect(self._on_soft_reset)

        unlock_btn = QtWidgets.QPushButton("Unlock alarm")
        unlock_btn.setToolTip("Clear a grbl ALARM state so moves are accepted again (sends $X).")
        unlock_btn.clicked.connect(self._on_unlock)

        status_btn = QtWidgets.QPushButton("Query status")
        status_btn.setToolTip("Ask grbl for its current state and position (sends '?').")
        status_btn.clicked.connect(self._on_status)

        setup_btn = QtWidgets.QPushButton("Push steps/mm setup")
        setup_btn.setToolTip("One-time: write the $100-$103 steps-per-unit settings to the board's EEPROM. "
                             "Only needed on a fresh grbl4axis board.")
        setup_btn.clicked.connect(self._on_push_settings)

        for b in (self.hold_btn, resume_btn, reset_btn, unlock_btn, status_btn, setup_btn):
            b.setMinimumHeight(30)
        mc.addWidget(self.hold_btn, 0, 0)
        mc.addWidget(resume_btn, 0, 1)
        mc.addWidget(reset_btn, 0, 2)
        mc.addWidget(unlock_btn, 1, 0)
        mc.addWidget(status_btn, 1, 1)
        mc.addWidget(setup_btn, 1, 2)
        top_row.addWidget(mc_box, 3)

        # Motion defaults sub-group
        md_box = QtWidgets.QGroupBox("Motion Defaults")
        md = QtWidgets.QGridLayout(md_box)
        md.setHorizontalSpacing(8)
        md.setVerticalSpacing(8)

        self.feed_input = QtWidgets.QDoubleSpinBox()
        self.feed_input.setRange(1, 20000)
        self.feed_input.setValue(config.DEFAULT_FEED_DEG_PER_MIN)
        self.feed_input.setSuffix(" deg/min")
        self.feed_input.setMinimumHeight(28)

        wrist_feed_btn = QtWidgets.QPushButton("Set wrist-safe feed")
        wrist_feed_btn.setToolTip(
            f"Sets feed rate to {config.WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min — scaled from the "
            f"{config.SAFE_FEED_DEG_PER_MIN:.0f} deg/min bench finding to match the wrist's 6:1 "
            "gearing (vs. 36:1 for the other joints). Use before a wrist-only move."
        )
        wrist_feed_btn.setMinimumHeight(30)
        wrist_feed_btn.clicked.connect(self._on_use_wrist_safe_feed)

        self.rapid_checkbox = QtWidgets.QCheckBox("Rapid moves (G0)")
        self.rapid_checkbox.setToolTip("Use rapid G0 moves instead of feed-rate-limited G1 moves.")

        self.send_btn = _style_button(QtWidgets.QPushButton("Send current pose →"), "primary")
        self.send_btn.setToolTip("Send the pose currently shown in the 3D view to the arm as one move.")
        self.send_btn.setMinimumHeight(30)
        self.send_btn.clicked.connect(self._on_send_pose)

        md.addWidget(QtWidgets.QLabel("Feed rate"), 0, 0)
        md.addWidget(self.feed_input, 0, 1)
        md.addWidget(wrist_feed_btn, 1, 0, 1, 2)
        md.addWidget(self.rapid_checkbox, 2, 0, 1, 2)
        md.addWidget(self.send_btn, 3, 0, 1, 2)
        top_row.addWidget(md_box, 2)

        outer.addLayout(top_row)

        # --- Status line + log console ---
        status_row = QtWidgets.QHBoxLayout()
        status_row.addWidget(QtWidgets.QLabel("Last status:"))
        self.status_label = QtWidgets.QLabel("(not connected)")
        self.status_label.setStyleSheet("font-family: Consolas, Menlo, monospace; color: #3a4658;")
        status_row.addWidget(self.status_label, 1)
        outer.addLayout(status_row)

        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(150)
        self.log.setMinimumHeight(110)
        outer.addWidget(self.log)

        # --- Raw command row ---
        raw_row = QtWidgets.QHBoxLayout()
        raw_row.addWidget(QtWidgets.QLabel("Raw command"))
        self.raw_input = QtWidgets.QLineEdit()
        self.raw_input.setPlaceholderText("Advanced: type a grbl command, e.g.  $$   or   $110=3000   then press Enter")
        self.raw_input.setMinimumHeight(28)
        self.raw_input.returnPressed.connect(self._on_send_raw)
        raw_send_btn = QtWidgets.QPushButton("Send")
        raw_send_btn.setMinimumHeight(28)
        raw_send_btn.clicked.connect(self._on_send_raw)
        raw_row.addWidget(self.raw_input, 1)
        raw_row.addWidget(raw_send_btn)
        outer.addLayout(raw_row)

        note = QtWidgets.QLabel(
            f"First time on a fresh board? Click “Push steps/mm setup” once (saved to EEPROM). "
            f"If moves are rejected with an ALARM, click “Unlock alarm”. The raw-command box handles "
            f"anything else — e.g. type $$ + Enter to dump all grbl settings. Default feed "
            f"{config.SAFE_FEED_DEG_PER_MIN:.0f} deg/min clears full-step resonance on the 36:1 joints; "
            f"use “Set wrist-safe feed” before a wrist-only move."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        outer.addWidget(note)

        return box

    # -- behavior ------------------------------------------------------------

    def _log(self, msg):
        self.log.appendPlainText(msg)

    def _refresh_ports(self):
        self.port_combo.clear()
        for device, desc in serial_bridge.SerialBridge.list_ports():
            self.port_combo.addItem(f"{device} — {desc}", userData=device)
        if self.port_combo.count() == 0:
            self.port_combo.addItem("(no ports found)", userData=None)

    def _on_connect_toggle(self):
        if self.bridge.is_connected():
            self.bridge.disconnect()
            self.connect_btn.setText("Connect")
            self.conn_status.setText("● Disconnected")
            self.conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
            self.status_label.setText("(not connected)")
            self._log("Disconnected.")
            return

        port = self.port_combo.currentData()
        if not port:
            self._log("No serial port selected.")
            return
        try:
            self.bridge.connect(port, self.baud_input.value())
            self.connect_btn.setText("Disconnect")
            self.conn_status.setText(f"● Connected  ({port})")
            self.conn_status.setStyleSheet("color: #1a7f37; font-weight: 600;")
            self._log(f"Connected to {port} @ {self.baud_input.value()} baud.")
            if self.bridge.startup_banner:
                for line in self.bridge.startup_banner:
                    self._log(f"  <- {line}")
            else:
                self._log("  (no startup banner seen — grbl may already be running, or baud is wrong)")
        except serial_bridge.SerialBridgeError as e:
            self.conn_status.setText("● Connection failed")
            self.conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
            self._log(f"Connection failed: {e}")

    def _on_jog_changed(self):
        self.current_thetas = [s.value() for s in self.joint_sliders]
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       self.current_thetas):
            label.setText(f"{name}: {theta:.1f}°")
        self.last_target_xyz = None
        self.canvas.plot_pose(self.current_thetas, tool_offset=self._current_tool_offset())

    def _on_solve_ik(self):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        psi = self.psi_input.value()
        prefer_elbow = "up" if self.elbow_up.isChecked() else "down"
        prefer_side = "A" if self.side_a.isChecked() else "B"

        tool_offset = self._current_tool_offset()
        try:
            result = kinematics.solve_ik_constrained(x, y, z, psi, prefer_elbow=prefer_elbow,
                                                      prefer_side=prefer_side,
                                                      tool_offset=tool_offset)
        except kinematics.IKUnreachableError as e:
            self.ik_status.setText(str(e))
            self.ik_status.setStyleSheet("color: red;")
            return

        thetas = result["thetas"]
        violations = result["violations"]
        ok, residual = kinematics.verify_ik(thetas, (x, y, z), tool_offset=tool_offset)

        # Reflect whichever branch was actually used, so the radio buttons
        # never silently disagree with what's on the sliders.
        if result["elbow_used"] == "up":
            self.elbow_up.setChecked(True)
        else:
            self.elbow_down.setChecked(True)
        if result["side_used"] == "A":
            self.side_a.setChecked(True)
        else:
            self.side_b.setChecked(True)

        # Push solved angles onto the sliders (blocking signals to avoid
        # feedback loops, then update once manually).
        for slider, theta in zip(self.joint_sliders, thetas):
            slider.blockSignals(True)
            slider.setValue(int(round(theta)))
            slider.blockSignals(False)

        self.current_thetas = list(thetas)
        self.last_target_xyz = (x, y, z)
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       thetas):
            label.setText(f"{name}: {theta:.1f}°")

        self.canvas.plot_pose(thetas, target_xyz=(x, y, z), tool_offset=tool_offset)

        status_lines = [f"Solved θ = [{', '.join(f'{t:.1f}°' for t in thetas)}]",
                         f"FK residual (true tool tip): {residual:.2f} mm"]
        if result["elbow_switched"]:
            status_lines.append(
                f"Auto-switched to elbow-{result['elbow_used']} "
                f"(elbow-{prefer_elbow} was requested but violated a joint limit)."
            )
        if result["side_switched"]:
            status_lines.append(
                f"Auto-switched to side {result['side_used']} "
                f"(side {prefer_side} was requested but violated a joint limit)."
            )
        if violations:
            status_lines.append(
                "UNREACHABLE WITHIN LIMITS on all elbow/side branches (measured hardware "
                "limits): "
                + "; ".join(f"joint {i} = {t:.1f}° (limit {lo}..{hi})" for i, t, lo, hi in violations)
            )
        self.ik_status.setText("\n".join(status_lines))
        self.ik_status.setStyleSheet("color: red;" if violations else "color: green;")

    def _on_preset_psi(self, preset_name):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        prefer_elbow = "up" if self.elbow_up.isChecked() else "down"
        prefer_side = "A" if self.side_a.isChecked() else "B"
        base_psi = config.PSI_PRESETS[preset_name]

        result = kinematics.find_feasible_psi(x, y, z, base_psi, prefer_elbow=prefer_elbow,
                                               prefer_side=prefer_side,
                                               tool_offset=self._current_tool_offset())
        if result is None:
            self.ik_status.setText(
                f"No feasible tool angle found near '{preset_name}' "
                f"({base_psi:.0f} deg) within +/-178 deg search -- target may be out of reach entirely."
            )
            self.ik_status.setStyleSheet("color: red;")
            return

        self.psi_input.setValue(result["psi_used"])
        self._on_solve_ik()

        offset = result["offset_from_base_deg"]
        if abs(offset) < 0.05:
            note = f"'{preset_name}' preset used exactly ({base_psi:.0f} deg)."
        else:
            note = (
                f"'{preset_name}' exact ({base_psi:.0f} deg) violated a joint limit -- "
                f"used nearest feasible tilt instead: {result['psi_used']:.1f} deg "
                f"({offset:+.1f} deg from preset)."
            )
        self.ik_status.setText(note + "\n" + self.ik_status.text())

    def _on_save_offsets(self):
        offsets = [w.value() for w in self.offset_inputs]
        config.save_home_offsets(offsets)
        self._log(f"Saved home offsets: {offsets}")

    def _on_reload_offsets(self):
        offsets = config.load_home_offsets()
        for w, v in zip(self.offset_inputs, offsets):
            w.setValue(v)
        self._log("Reloaded home offsets from disk.")

    def _on_push_settings(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        if self._serial_busy():
            self._log("A waypoint or writing stream is in progress — wait for it to finish (or stop it) first.")
            return
        self._log("Pushing $100-$103 steps/degree settings...")
        try:
            results = self.bridge.push_steps_per_unit_settings()
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Settings push failed: {e}")
            return
        for setting, value, response in results:
            self._log(f"  {setting}={value:.4f}  -> {', '.join(response)}")
        self._log("Done. These persist in grbl's EEPROM across power cycles.")

    def _on_unlock(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        if self._serial_busy():
            self._log("A waypoint or writing stream is in progress — wait for it to finish (or stop it) first.")
            return
        try:
            response = self.bridge.unlock()
            self._log(f"$X -> {', '.join(response)}")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Unlock failed: {e}")

    def _on_send_raw(self):
        line = self.raw_input.text().strip()
        if not line:
            return
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        if self._serial_busy():
            self._log("A waypoint or writing stream is in progress — wait for it to finish (or stop it) first.")
            return
        self._log(f"Sending raw: {line}")
        try:
            response = self.bridge.send_raw(line)
            for r in response:
                self._log(f"  <- {r}")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Raw send failed: {e}")
        finally:
            self.raw_input.clear()

    def _on_use_wrist_safe_feed(self):
        self.feed_input.setValue(config.WRIST_SAFE_FEED_DEG_PER_MIN)
        self._log(
            f"Feed rate set to {config.WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min "
            "(wrist-safe — scaled from the bench-tested 36:1-joint value for the wrist's 6:1 gearing)."
        )

    def _on_status(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        if self._serial_busy():
            self._log(
                "A waypoint or writing stream is in progress — querying status now could "
                "steal the response the stream is waiting for. Wait for it to finish (or "
                "stop it) first.")
            return
        status = self.bridge.request_status()
        if status:
            self.status_label.setText(status)
            self._log(f"Status: {status}")
        else:
            self._log("No status response received (older grbl builds may not support '?').")

    def _on_feed_hold(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.feed_hold()
        self._log("Sent feed hold (!).")

    def _on_resume(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.cycle_start_resume()
        self._log("Sent cycle start/resume (~).")

    def _on_soft_reset(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.soft_reset()
        self._log("Sent soft reset (Ctrl-X). Grbl will reprint its startup banner.")

    def _on_send_pose(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        if self._serial_busy():
            self._log("A waypoint or writing stream is in progress — wait for it to finish (or stop it) first.")
            return

        offsets = [w.value() for w in self.offset_inputs]
        motor_angles = kinematics.apply_home_offset(self.current_thetas, offsets)
        rapid = self.rapid_checkbox.isChecked()
        feed = self.feed_input.value()

        line = self.bridge.build_move_gcode(
            motor_angles, feed_deg_per_min=feed, rapid=rapid,
            per_axis_max_deg_per_min=self._active_axis_speed_limits())
        est_steps = kinematics.estimated_steps_for_display(self.current_thetas, offsets)
        self._log(f"Sending: {line}")
        self._log(f"  (thetas {[round(t,1) for t in self.current_thetas]}, "
                   f"est. steps {est_steps} — for reference only, not sent)")
        try:
            response = self.bridge.send_line(line)
        except serial_bridge.GrblAlarmError as e:
            self._log(f"ALARM: {e}")
            self._log("  -> Click 'Unlock ($X)' and try again.")
            return
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Send failed: {e}")
            return
        for resp_line in response:
            self._log(f"  <- {resp_line}")

    def _update_pose(self):
        self.canvas.plot_pose(self.current_thetas, self.last_target_xyz,
                              tool_offset=self._current_tool_offset())

    def closeEvent(self, event):
        """
        Without this, closing the window while a waypoint or writing stream
        is running would destroy the PathStreamWorker QThread while its
        run() is still executing on the arm -- Qt considers that undefined
        behavior (it prints "QThread: Destroyed while thread is still
        running" at best), and the serial port gets yanked mid-move with no
        chance to feed-hold first. Confirm, abort cleanly, then disconnect.
        """
        running = [w for w in (getattr(self, "_wp_worker", None), getattr(self, "_write_worker", None))
                   if w is not None and w.isRunning()]
        if running:
            reply = QtWidgets.QMessageBox.question(
                self, "Motion in progress",
                "The arm is still streaming a move. Stop it and close anyway?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if reply != QtWidgets.QMessageBox.Yes:
                event.ignore()
                return
            for w in running:
                w.request_abort()
                w.wait(5000)

        if self.bridge.is_connected():
            try:
                self.bridge.disconnect()
            except serial_bridge.SerialBridgeError:
                pass
        if self.gripper.is_connected():
            try:
                self.gripper.disconnect()
            except gripper_bridge.GripperBridgeError:
                pass
        event.accept()


def main():
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
