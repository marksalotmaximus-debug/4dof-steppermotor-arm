#!/usr/bin/env python3
"""
arm_control.py — single-file build of the 4-DOF robotic arm control app.

Talks to a real gcobos/grbl4axis controller over standard grbl G-code
(not a custom line protocol) — see the py section below.

Package into a standalone executable with:

    pyinstaller --onefile --windowed --name ArmControl arm_control.py

Run directly with:

    python arm_control.py
"""

import sys
import math
import os
import json
import time

import numpy as np
import serial
import serial.tools.list_ports
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


# ---------------------------------------------------------------------------
# Visual theme. A single light stylesheet applied app-wide gives every widget
# consistent spacing, readable type, and clear affordances, instead of the
# raw native look. Semantic button classes (primary / danger) are opted into
# per-button via setProperty("kind", ...) so consequential actions read as
# such at a glance.
# ---------------------------------------------------------------------------
APP_STYLE = """
QWidget {
    font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    color: #1f2733;
}
QMainWindow, QWidget#central { background: #f4f6f9; }

QGroupBox {
    background: #ffffff;
    border: 1px solid #d7dee8;
    border-radius: 8px;
    margin-top: 14px;
    padding-top: 6px;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 0 6px;
    color: #3a4658;
}

QTabWidget::pane {
    border: 1px solid #d7dee8;
    border-radius: 8px;
    background: #ffffff;
    top: -1px;
}
QTabBar::tab {
    background: #e7ecf3;
    color: #4a5567;
    padding: 8px 18px;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
    margin-right: 2px;
    font-weight: 600;
}
QTabBar::tab:selected { background: #ffffff; color: #1a56db; }
QTabBar::tab:hover:!selected { background: #eef2f7; }

QPushButton {
    background: #eef1f6;
    border: 1px solid #cbd4e1;
    border-radius: 6px;
    padding: 6px 12px;
    color: #24303f;
}
QPushButton:hover { background: #e2e8f1; }
QPushButton:pressed { background: #d3dbe7; }
QPushButton:disabled { background: #f0f2f5; color: #9aa4b2; border-color: #e0e4ea; }

/* Primary action — the main "do the thing" button in a panel. */
QPushButton[kind="primary"] {
    background: #1a56db;
    border: 1px solid #1546b4;
    color: #ffffff;
    font-weight: 600;
}
QPushButton[kind="primary"]:hover { background: #1c4fc4; }
QPushButton[kind="primary"]:pressed { background: #163f9e; }
QPushButton[kind="primary"]:disabled { background: #a9bde8; border-color: #a9bde8; color: #eef2fb; }

/* Danger action — stop / reset / abort. Reads red so it's never confused
   with a benign button. */
QPushButton[kind="danger"] {
    background: #fdecec;
    border: 1px solid #e6a6a6;
    color: #b42318;
    font-weight: 600;
}
QPushButton[kind="danger"]:hover { background: #fbdcdc; }
QPushButton[kind="danger"]:pressed { background: #f6c9c9; }
QPushButton[kind="danger"]:disabled { background: #f6eeee; border-color: #ecd6d6; color: #cba7a3; }

QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit {
    background: #ffffff;
    border: 1px solid #cbd4e1;
    border-radius: 6px;
    padding: 4px 6px;
    selection-background-color: #1a56db;
    selection-color: #ffffff;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
    border: 1px solid #1a56db;
}
QComboBox::drop-down { border: none; width: 20px; }
QPlainTextEdit { font-family: "Consolas", "Menlo", monospace; font-size: 12px; }

QSlider::groove:horizontal {
    height: 5px; background: #d7dee8; border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #1a56db; width: 15px; margin: -6px 0; border-radius: 8px;
}
QSlider::handle:horizontal:hover { background: #1c4fc4; }
QSlider::sub-page:horizontal { background: #9db8ee; border-radius: 3px; }

QProgressBar {
    border: 1px solid #cbd4e1; border-radius: 6px;
    background: #eef1f6; text-align: center; height: 18px;
}
QProgressBar::chunk { background: #1a56db; border-radius: 5px; }

QRadioButton, QCheckBox { spacing: 6px; }
QTableWidget {
    background: #ffffff; border: 1px solid #cbd4e1; border-radius: 6px;
    gridline-color: #e4e9f0;
}
QHeaderView::section {
    background: #eef1f6; border: none; border-bottom: 1px solid #cbd4e1;
    padding: 4px; font-weight: 600; color: #3a4658;
}
QToolTip {
    background: #24303f; color: #ffffff; border: none;
    padding: 5px 8px; border-radius: 4px;
}
"""


def _style_button(btn, kind):
    """Tag a button with a semantic style class ('primary' or 'danger')."""
    btn.setProperty("kind", kind)
    return btn




# ============================================================================
# py
# ============================================================================
"""
py

Central place for every number pulled from the project plan:
  - DH parameters (section 5.1)
  - Gear ratios / steps-per-rev (section 2.2 / 4)
  - Home offset calibration (section 5.4) — persisted to home_offsets.json
  - Joint limits (section 8 — measured on real hardware)
  - Serial defaults

Nothing here should need to change as you calibrate the physical arm —
only the *values*, via the GUI's calibration panel or by hand-editing
home_offsets.json.
"""

import json
import os

# ---------------------------------------------------------------------------
# DH parameters: (a [mm], alpha [deg], d [mm])  — theta is the joint variable
# From plan section 5.1. a4 (65mm) is the wrist's own link length, per the
# plan's explicit decision to fold the tool offset into joint 4 rather than
# treat it as a separate fixed 5th link.
# ---------------------------------------------------------------------------
DH_PARAMS = [
    {"a": 21.15,  "alpha_deg": 90.0, "d": 24.25},  # joint 1 - base (yaw)
    {"a": 194.66, "alpha_deg": 0.0,  "d": 0.0},     # joint 2 - shoulder (pitch)
    {"a": 152.0,  "alpha_deg": 0.0,  "d": 0.0},     # joint 3 - elbow (pitch)
    {"a": 65.0,   "alpha_deg": 0.0,  "d": 0.0},     # joint 4 - wrist (pitch)
]

# ---------------------------------------------------------------------------
# Drivetrain (section 2.2 / 4)
# ---------------------------------------------------------------------------
MOTOR_FULL_STEPS_PER_REV = 200          # NEMA17, full-step only (DRV8825, no microstepping)
GEAR_RATIOS = [36, 36, 36, 6]            # base, shoulder, elbow, wrist
STEPS_PER_OUTPUT_REV = [MOTOR_FULL_STEPS_PER_REV * r for r in GEAR_RATIOS]
# -> [7200, 7200, 7200, 1200]

# ---------------------------------------------------------------------------
# Grbl (gcobos/grbl4axis) steps-per-unit settings.
#
# Standard grbl does NOT accept raw step counts from the host — it parses
# G-code axis words in machine "units" (mm by convention, but really just
# whatever $100-$103 says a step is worth) and does the degrees<->steps
# conversion itself, in firmware, using its own EEPROM-stored settings.
#
# We exploit that directly: define 1 G-code "unit" == 1 degree of output
# rotation for every joint, and program grbl's steps/unit settings to match
# our gear reduction. Then the app can just send G-code axis words in plain
# degrees and grbl handles the rest — no step math needed on the host side.
#
#   $100 (X, base)      = steps per degree = 7200/360 = 20.0
#   $101 (Y, shoulder)  = steps per degree = 7200/360 = 20.0
#   $102 (Z, elbow)     = steps per degree = 7200/360 = 20.0
#   $103 (E, wrist)     = steps per degree = 1200/360 = 3.3333
#
# These need to be pushed to grbl's EEPROM once (they persist across power
# cycles after that) — the GUI's "Grbl Setup" panel does this with one
# button click. gcobos/grbl4axis maps its 4th axis to the "E" word on
# Uno pins D12/D13 (variable spindle disabled to free those pins) — NOT "A".
# Confirmed against the actual gcobos/grbl4axis source: E_STEP_BIT /
# E_DIRECTION_BIT on pins 12/13, axis word "E". Sending "A" gets the whole
# line rejected as an unsupported/invalid g-code block.
# ---------------------------------------------------------------------------
GRBL_AXIS_LETTERS = ["X", "Y", "Z", "E"]   # base, shoulder, elbow, wrist
GRBL_STEPS_PER_DEGREE = [s / 360.0 for s in STEPS_PER_OUTPUT_REV]
# -> [20.0, 20.0, 20.0, 3.3333...]

GRBL_SETTING_NUMBERS = ["$100", "$101", "$102", "$103"]

# Default feed rate for G1 moves, in grbl's units/min — since our "unit" is
# 1 degree, this is degrees/minute. G0 (rapid) ignores this and just seeks
# at $110-$113 max rate settings instead.
#
# Bench-testing finding (bare motors, no arm assembled yet — see build log):
# F300 (the old default) sat right inside a resonance band — motors were
# badly rattly/buzzy, confirmed both by ear and by an audio spectrogram
# (~220Hz fundamental + harmonics that shifted character with feed rate).
# F1600 deg/min cleared it up dramatically for the 36:1 joints
# (base/shoulder/elbow). Very likely classic full-step resonance
# (electromagnetic + detent-torque interaction, worse when unloaded) rather
# than a wiring/driver/gearbox fault — it responded to speed, not to any
# hardware change.
#
# IMPORTANT: this was found with bare, unloaded motors. Steppers lose
# available torque as step rate climbs, so once the arm carries real
# mass/gearing load, re-check whether 1600 is still smooth *and* whether it
# still has enough torque to hold/move the payload — don't assume higher is
# always better once it's loaded.
SAFE_FEED_DEG_PER_MIN = 1600.0   # tuned on base/shoulder/elbow (36:1 joints)

DEFAULT_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN

# The wrist is geared 6:1, not 36:1 — GRBL_STEPS_PER_DEGREE[3] is 6x smaller
# than the other joints', so the same F (deg/min) value drives it at a much
# lower *actual* step rate. Scale the safe feed above so the wrist lands in
# roughly the same physical step-rate sweet spot found on the bench:
WRIST_SAFE_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN * (
    GRBL_STEPS_PER_DEGREE[0] / GRBL_STEPS_PER_DEGREE[3]
)
# -> 1600 * (20 / 3.3333) = 9600.0 deg/min — test this specifically once the
# wrist motor/gearbox is wired up; don't assume 1600 is also its sweet spot.

# ---------------------------------------------------------------------------
# PER-AXIS MOTION PROFILE
#
# Different joints genuinely want different speeds: the 36:1 joints and the
# 6:1 wrist need different feeds to land in the same real step-rate range,
# and individual motors differ too (a taller/heavier-rotor NEMA 17 has more
# rotor inertia and a lower resonant frequency than a short one, so it can
# be rough at a feed that's perfectly smooth on its neighbours).
#
# IMPORTANT — how "per-axis speed" actually works in grbl:
#   G-code F is a SINGLE COORDINATED feed rate for the whole move, not a
#   per-axis value. For a move with deltas d_i and path length
#   L = sqrt(sum(d_i^2)), grbl runs the move at F along that path, so each
#   axis moves at  F * d_i / L.
#
# So per-axis speed is enforced two ways, and we use BOTH:
#   1. grbl's own $110-$113 max-rate settings are hard per-axis ceilings.
#      grbl automatically scales any move down so no axis exceeds its
#      limit. This is the safety net and it lives in the firmware.
#   2. The app computes the largest F that keeps EVERY axis under its own
#      limit (see serial_bridge.coordinated_feed), so we request something
#      sensible instead of always relying on grbl to clamp us.
#
# steps_per_deg is here too because it's now per-axis editable — if you
# enable microstepping on one axis to smooth it out, only that axis's
# $100-$103 value changes, and the app's math has to agree with the
# firmware or every move on that joint will be wrong.
#
# Persisted to motion_profile.json so it survives restarts, and pushable to
# the board's EEPROM from the Motion Tuning tab.
# ---------------------------------------------------------------------------
GRBL_MAX_RATE_SETTINGS = ["$110", "$111", "$112", "$113"]   # per-axis max rate
GRBL_ACCEL_SETTINGS = ["$120", "$121", "$122", "$123"]      # per-axis acceleration

_MOTION_PROFILE_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "motion_profile.json")

_DEFAULT_MOTION_PROFILE = {
    # Max speed per joint, deg/min. Drives both the app's feed calculation
    # and grbl's $110-$113. Wrist defaults higher to match its 6:1 gearing.
    "max_speed_deg_per_min": [
        SAFE_FEED_DEG_PER_MIN,
        SAFE_FEED_DEG_PER_MIN,
        SAFE_FEED_DEG_PER_MIN,
        WRIST_SAFE_FEED_DEG_PER_MIN,
    ],
    # Acceleration per joint, deg/sec^2 -> grbl $120-$123. Higher values
    # punch through a resonance band faster instead of dwelling in it.
    "accel_deg_per_sec2": [10.0, 10.0, 10.0, 10.0],
    # Steps per degree per joint -> grbl $100-$103. Change one of these if
    # you enable microstepping on a single axis.
    "steps_per_deg": list(GRBL_STEPS_PER_DEGREE),
}


def load_motion_profile():
    """Load the per-axis motion profile from disk, falling back to defaults.
    Missing/short keys are filled in from the defaults so an old or partial
    file can't produce a malformed profile."""
    profile = {k: list(v) for k, v in _DEFAULT_MOTION_PROFILE.items()}
    if os.path.exists(_MOTION_PROFILE_FILE):
        try:
            with open(_MOTION_PROFILE_FILE, "r") as f:
                data = json.load(f)
            for key in profile:
                vals = data.get(key)
                if isinstance(vals, list) and len(vals) == 4:
                    profile[key] = [float(v) for v in vals]
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            pass
    return profile


def save_motion_profile(profile):
    """Persist a per-axis motion profile dict to disk."""
    out = {}
    for key in _DEFAULT_MOTION_PROFILE:
        vals = profile.get(key, _DEFAULT_MOTION_PROFILE[key])
        if len(vals) != 4:
            raise ValueError(f"{key} must have exactly 4 values (one per joint)")
        out[key] = [float(v) for v in vals]
    with open(_MOTION_PROFILE_FILE, "w") as f:
        json.dump(out, f, indent=2)

# ---------------------------------------------------------------------------
# Joint limits — measured on the physical hardware (plan section 8, now
# closed out).
#   J1 (base):     confirmed NO hard stop -- true continuous rotation.
#                  +/-180 would just be atan2()'s wrap point, not a real
#                  physical limit, so it's represented as unbounded (+/-inf)
#                  below rather than a fake boundary. check_joint_limits()
#                  will therefore never flag J1 -- there's nothing to flag.
#   J2 (shoulder): 180 deg total, symmetric -> +/-90 deg
#   J3 (elbow):    190 deg total, symmetric -> +/-95 deg
#   J4 (wrist):    204 deg total, symmetric -> +/-102 deg
#
# CAVEAT for J1 being a true continuous-rotation joint: solve_ik()'s
# theta1 = atan2(y, x) always returns a value in (-180, 180], so the IK
# solver itself never asks for more than one turn. But because J1 can
# physically spin either direction with no stop, the same target could be
# reached by going the "short way" or the "long way" around (e.g. -179 deg
# vs +181 deg are the same physical pose) -- and after home-offset
# subtraction, a solved angle near the wrap point could come out on
# whichever side is numerically closer to zero, not necessarily the
# shortest real rotation from the arm's current position. Not handled yet;
# worth revisiting if J1 ever seems to spin the "long way round"
# unnecessarily once you're doing multi-waypoint moves.
# ---------------------------------------------------------------------------
JOINT_LIMITS_DEG = [
    (-float("inf"), float("inf")),   # base -- no hard stop, continuous rotation
    (-90.0, 90.0),                    # shoulder
    (-95.0, 95.0),                    # elbow
    (-102.0, 102.0),                  # wrist
]

# ---------------------------------------------------------------------------
# Tool-angle (psi) presets -- resolves the plan's "wrist/tool-angle strategy
# undecided" open item (section 8). psi is the tool's tilt within the arm's
# vertical plane, measured from horizontal (see solve_ik). These are named
# starting points for find_feasible_psi() to search around, rather than
# typing a raw degree value every time.
# ---------------------------------------------------------------------------
PSI_PRESETS = {
    "level": 0.0,     # gripper horizontal -- e.g. reaching onto a shelf
    "down": -90.0,    # gripper pointing straight down -- e.g. picking off a table
    "up": 90.0,       # gripper pointing straight up
}

# ---------------------------------------------------------------------------
# Home offset calibration (section 5.4)
#   THETA_HOME_OFFSET[i]: degrees to SUBTRACT from a DH-frame solved angle
#   to get the real motor command angle, i.e.:
#       motor_angle = theta_dh - home_offset
#   Persisted so you don't have to re-measure every session.
# ---------------------------------------------------------------------------
_HOME_OFFSET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "home_offsets.json")
_DEFAULT_HOME_OFFSETS = [0.0, 0.0, 0.0, 0.0]


def load_home_offsets():
    """Load home offsets from disk, falling back to zeros if not yet calibrated."""
    if os.path.exists(_HOME_OFFSET_FILE):
        try:
            with open(_HOME_OFFSET_FILE, "r") as f:
                data = json.load(f)
            offsets = data.get("home_offset_deg", _DEFAULT_HOME_OFFSETS)
            if len(offsets) == 4:
                return [float(v) for v in offsets]
        except (json.JSONDecodeError, OSError):
            pass
    return list(_DEFAULT_HOME_OFFSETS)


def save_home_offsets(offsets):
    """Persist a 4-element list of degree offsets to disk."""
    if len(offsets) != 4:
        raise ValueError("home offsets must have exactly 4 values (base, shoulder, elbow, wrist)")
    with open(_HOME_OFFSET_FILE, "w") as f:
        json.dump({"home_offset_deg": [float(v) for v in offsets]}, f, indent=2)


# ---------------------------------------------------------------------------
# Tool offset (TCP). Rigid (dx, dy, dz) translation in the wrist's own frame
# from the end of the DH chain to the actual tool tip (e.g. marker point).
#   dx = along the final link's reach axis; dy = sideways; dz = up/down.
# LAYER 1: forward_kinematics applies it so the render/FK show the true tip.
# LAYER 2 (not yet): IK back-solving so a target places the TOOL TIP there.
# Persisted to disk like home offsets.
# ---------------------------------------------------------------------------
_TOOL_OFFSET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tool_offset.json")
_DEFAULT_TOOL_OFFSET = [0.0, 50.5, 0.0]   # dx, dy, dz mm -- measured: 50.5mm right, no other shift


def load_tool_offset():
    """Load the tool offset (dx, dy, dz mm) from disk, defaulting to zeros."""
    if os.path.exists(_TOOL_OFFSET_FILE):
        try:
            with open(_TOOL_OFFSET_FILE, "r") as f:
                data = json.load(f)
            off = data.get("tool_offset_mm", _DEFAULT_TOOL_OFFSET)
            if len(off) == 3:
                return [float(v) for v in off]
        except (json.JSONDecodeError, OSError):
            pass
    return list(_DEFAULT_TOOL_OFFSET)


def save_tool_offset(offset):
    """Persist a 3-element (dx, dy, dz) tool offset in mm to disk."""
    if len(offset) != 3:
        raise ValueError("tool offset must have exactly 3 values (dx, dy, dz)")
    with open(_TOOL_OFFSET_FILE, "w") as f:
        json.dump({"tool_offset_mm": [float(v) for v in offset]}, f, indent=2)


# ============================================================================
# Embedded single-stroke (Hershey-style) font + text engine.
# (Same content as the standalone hershey_font.py module, inlined here so
# arm_control.py stays a single self-contained file. See that module for
# full docs.)
# ============================================================================

# Each glyph: list of strokes; each stroke: list of (x, y) vertices.
# Empty list = no ink (e.g. space). Designed on a ~0..1 em square,
# baseline y=0, cap height y=1, nominal advance width ~0.8.
_GLYPHS = {
    " ": [],
    "A": [[(0.0, 0.0), (0.4, 1.0), (0.8, 0.0)], [(0.15, 0.4), (0.65, 0.4)]],
    "B": [[(0.0, 0.0), (0.0, 1.0), (0.55, 1.0), (0.7, 0.85), (0.7, 0.6),
           (0.55, 0.5), (0.0, 0.5)],
          [(0.55, 0.5), (0.72, 0.38), (0.72, 0.12), (0.55, 0.0), (0.0, 0.0)]],
    "C": [[(0.75, 0.8), (0.5, 1.0), (0.25, 1.0), (0.05, 0.8), (0.0, 0.5),
           (0.05, 0.2), (0.25, 0.0), (0.5, 0.0), (0.75, 0.2)]],
    "D": [[(0.0, 0.0), (0.0, 1.0), (0.45, 1.0), (0.7, 0.8), (0.75, 0.5),
           (0.7, 0.2), (0.45, 0.0), (0.0, 0.0)]],
    "E": [[(0.7, 1.0), (0.0, 1.0), (0.0, 0.0), (0.7, 0.0)],
          [(0.0, 0.5), (0.5, 0.5)]],
    "F": [[(0.7, 1.0), (0.0, 1.0), (0.0, 0.0)], [(0.0, 0.5), (0.5, 0.5)]],
    "G": [[(0.75, 0.8), (0.5, 1.0), (0.25, 1.0), (0.05, 0.8), (0.0, 0.5),
           (0.05, 0.2), (0.25, 0.0), (0.5, 0.0), (0.75, 0.2), (0.75, 0.45),
           (0.45, 0.45)]],
    "H": [[(0.0, 1.0), (0.0, 0.0)], [(0.7, 1.0), (0.7, 0.0)],
          [(0.0, 0.5), (0.7, 0.5)]],
    "I": [[(0.1, 1.0), (0.5, 1.0)], [(0.3, 1.0), (0.3, 0.0)],
          [(0.1, 0.0), (0.5, 0.0)]],
    "J": [[(0.6, 1.0), (0.6, 0.2), (0.45, 0.0), (0.2, 0.0), (0.05, 0.2)]],
    "K": [[(0.0, 1.0), (0.0, 0.0)], [(0.7, 1.0), (0.0, 0.45)],
          [(0.2, 0.6), (0.7, 0.0)]],
    "L": [[(0.0, 1.0), (0.0, 0.0), (0.7, 0.0)]],
    "M": [[(0.0, 0.0), (0.0, 1.0), (0.4, 0.4), (0.8, 1.0), (0.8, 0.0)]],
    "N": [[(0.0, 0.0), (0.0, 1.0), (0.7, 0.0), (0.7, 1.0)]],
    "O": [[(0.25, 1.0), (0.05, 0.8), (0.0, 0.5), (0.05, 0.2), (0.25, 0.0),
           (0.5, 0.0), (0.7, 0.2), (0.75, 0.5), (0.7, 0.8), (0.5, 1.0),
           (0.25, 1.0)]],
    "P": [[(0.0, 0.0), (0.0, 1.0), (0.55, 1.0), (0.72, 0.85), (0.72, 0.62),
           (0.55, 0.5), (0.0, 0.5)]],
    "Q": [[(0.25, 1.0), (0.05, 0.8), (0.0, 0.5), (0.05, 0.2), (0.25, 0.0),
           (0.5, 0.0), (0.7, 0.2), (0.75, 0.5), (0.7, 0.8), (0.5, 1.0),
           (0.25, 1.0)],
          [(0.45, 0.25), (0.75, -0.05)]],
    "R": [[(0.0, 0.0), (0.0, 1.0), (0.55, 1.0), (0.72, 0.85), (0.72, 0.62),
           (0.55, 0.5), (0.0, 0.5)],
          [(0.35, 0.5), (0.72, 0.0)]],
    "S": [[(0.72, 0.8), (0.5, 1.0), (0.22, 1.0), (0.05, 0.85), (0.05, 0.62),
           (0.22, 0.5), (0.5, 0.5), (0.67, 0.38), (0.67, 0.15), (0.5, 0.0),
           (0.22, 0.0), (0.0, 0.2)]],
    "T": [[(0.0, 1.0), (0.7, 1.0)], [(0.35, 1.0), (0.35, 0.0)]],
    "U": [[(0.0, 1.0), (0.0, 0.2), (0.2, 0.0), (0.5, 0.0), (0.7, 0.2),
           (0.7, 1.0)]],
    "V": [[(0.0, 1.0), (0.35, 0.0), (0.7, 1.0)]],
    "W": [[(0.0, 1.0), (0.2, 0.0), (0.4, 0.6), (0.6, 0.0), (0.8, 1.0)]],
    "X": [[(0.0, 1.0), (0.7, 0.0)], [(0.0, 0.0), (0.7, 1.0)]],
    "Y": [[(0.0, 1.0), (0.35, 0.5), (0.7, 1.0)], [(0.35, 0.5), (0.35, 0.0)]],
    "Z": [[(0.0, 1.0), (0.7, 1.0), (0.0, 0.0), (0.7, 0.0)]],
    "0": [[(0.25, 1.0), (0.05, 0.8), (0.0, 0.5), (0.05, 0.2), (0.25, 0.0),
           (0.5, 0.0), (0.7, 0.2), (0.75, 0.5), (0.7, 0.8), (0.5, 1.0),
           (0.25, 1.0)], [(0.1, 0.15), (0.65, 0.85)]],
    "1": [[(0.15, 0.8), (0.35, 1.0), (0.35, 0.0)], [(0.1, 0.0), (0.6, 0.0)]],
    "2": [[(0.05, 0.8), (0.25, 1.0), (0.5, 1.0), (0.7, 0.8), (0.7, 0.6),
           (0.0, 0.0), (0.72, 0.0)]],
    "3": [[(0.05, 0.85), (0.3, 1.0), (0.55, 1.0), (0.7, 0.85), (0.55, 0.55),
           (0.3, 0.55)], [(0.55, 0.55), (0.72, 0.35), (0.55, 0.05),
           (0.3, 0.0), (0.05, 0.15)]],
    "4": [[(0.5, 0.0), (0.5, 1.0), (0.0, 0.35), (0.72, 0.35)]],
    "5": [[(0.65, 1.0), (0.1, 1.0), (0.05, 0.55), (0.35, 0.62), (0.6, 0.5),
           (0.7, 0.3), (0.6, 0.08), (0.35, 0.0), (0.1, 0.05)]],
    "6": [[(0.6, 0.9), (0.4, 1.0), (0.2, 0.9), (0.05, 0.55), (0.05, 0.2),
           (0.2, 0.0), (0.45, 0.0), (0.65, 0.15), (0.68, 0.4), (0.5, 0.55),
           (0.2, 0.55), (0.05, 0.4)]],
    "7": [[(0.0, 1.0), (0.72, 1.0), (0.3, 0.0)]],
    "8": [[(0.3, 0.55), (0.1, 0.68), (0.1, 0.85), (0.3, 1.0), (0.5, 1.0),
           (0.68, 0.85), (0.68, 0.68), (0.5, 0.55), (0.3, 0.55),
           (0.08, 0.4), (0.08, 0.15), (0.3, 0.0), (0.5, 0.0), (0.72, 0.15),
           (0.72, 0.4), (0.5, 0.55)]],
    "9": [[(0.65, 0.6), (0.5, 0.45), (0.25, 0.45), (0.08, 0.6), (0.1, 0.85),
           (0.3, 1.0), (0.5, 1.0), (0.67, 0.85), (0.7, 0.45), (0.55, 0.1),
           (0.35, 0.0), (0.15, 0.08)]],
    "-": [[(0.1, 0.5), (0.6, 0.5)]],
    ".": [[(0.3, 0.0), (0.35, 0.05), (0.3, 0.1), (0.25, 0.05), (0.3, 0.0)]],
    ",": [[(0.32, 0.1), (0.28, 0.0), (0.22, -0.1)]],
    "!": [[(0.3, 1.0), (0.3, 0.25)], [(0.3, 0.05), (0.32, 0.07),
           (0.3, 0.09), (0.28, 0.07), (0.3, 0.05)]],
    "?": [[(0.05, 0.8), (0.25, 1.0), (0.5, 1.0), (0.68, 0.82), (0.68, 0.62),
           (0.35, 0.45), (0.35, 0.3)], [(0.35, 0.05), (0.37, 0.07),
           (0.35, 0.09), (0.33, 0.07), (0.35, 0.05)]],
    "'": [[(0.35, 1.0), (0.32, 0.8)]],
    ":": [[(0.3, 0.65), (0.33, 0.68), (0.3, 0.71), (0.27, 0.68), (0.3, 0.65)],
          [(0.3, 0.2), (0.33, 0.23), (0.3, 0.26), (0.27, 0.23), (0.3, 0.2)]],
}

# Per-glyph advance width (where the next glyph starts, in em units).
# Defaults to 0.8 for anything unlisted; space and narrow glyphs differ.
_ADVANCE = {
    " ": 0.5, "I": 0.6, "!": 0.5, ".": 0.5, ",": 0.5, "'": 0.4, ":": 0.5,
    "-": 0.7, "M": 0.95, "W": 0.95, "1": 0.65,
}
_DEFAULT_ADVANCE = 0.82


def available_chars():
    """Return the set of directly-supported characters (uppercase + digits + punct)."""
    return set(_GLYPHS.keys())


def text_to_strokes(text, height_mm=40.0, letter_spacing_mm=4.0,
                    word_spacing_mm=None, origin=(0.0, 0.0)):
    """
    Convert a text string into a list of strokes in millimetres, laid out
    left-to-right along +x, baseline at origin[1], starting at origin[0].

    Each returned stroke is a list of (x_mm, y_mm) points; the pen is DOWN
    while tracing a stroke and lifts between strokes. Lowercase is folded to
    uppercase. Unsupported characters are skipped (they still advance as a
    space so spacing stays sensible).

    Returns (strokes, width_mm, height_mm):
      strokes    : list of [(x, y), ...] polylines, in mm, on the plane
      width_mm   : total advance width of the rendered text
      height_mm  : cap height used (== height_mm arg)
    """
    if word_spacing_mm is None:
        word_spacing_mm = height_mm * 0.4

    ox, oy = origin
    cursor = ox
    strokes = []

    for ch in text:
        up = ch.upper()
        if ch == " ":
            cursor += word_spacing_mm
            continue
        glyph = _GLYPHS.get(up)
        if glyph is None:
            # Unsupported: advance like a space so layout stays readable.
            cursor += _DEFAULT_ADVANCE * height_mm + letter_spacing_mm
            continue
        for stroke in glyph:
            pts = [(cursor + px * height_mm, oy + py * height_mm) for (px, py) in stroke]
            strokes.append(pts)
        adv = _ADVANCE.get(up, _DEFAULT_ADVANCE)
        cursor += adv * height_mm + letter_spacing_mm

    width_mm = cursor - ox
    return strokes, width_mm, height_mm


def strokes_to_pen_path(strokes, plane="xy_table", pen_down_z=0.0,
                        pen_up_z=15.0, base_x=250.0, base_y=0.0, psi_deg=-90.0,
                        travel_first=True):
    """
    Turn 2D strokes (in the plane's own u,v mm coords) into a full 4D pen
    path of (x, y, z, psi) waypoints in the arm's world frame, inserting
    pen-up / pen-down Z transitions between strokes.

    plane:
      "xy_table" — writing flat on a horizontal surface. The glyph's local
        u -> world X (reach direction offset by base_x), v -> world Y
        (offset by base_y). Pen height is world Z, controlled by pen_down_z
        (marker touching paper) and pen_up_z (lifted clear). psi_deg is the
        fixed tool tilt (default -90 = pointing straight down).

    The sequence for each stroke is:
      (move to stroke start at pen_up_z) -> (lower to pen_down_z) ->
      (trace the stroke at pen_down_z) -> (raise to pen_up_z)
    so the marker only touches paper during the stroke itself.

    Returns a flat list of (x, y, z, psi) waypoints ready for
    kinematics.plan_waypoint_path (which will densify + IK + validate).
    """
    path = []

    def world(u, v, z):
        # xy_table: u along +X (reach), v along +Y, z world height.
        return (base_x + u, base_y + v, z, psi_deg)

    for si, stroke in enumerate(strokes):
        if not stroke:
            continue
        u0, v0 = stroke[0]
        # Travel to the start of this stroke with the pen up.
        path.append(world(u0, v0, pen_up_z))
        # Lower the pen.
        path.append(world(u0, v0, pen_down_z))
        # Trace the stroke on the paper.
        for (u, v) in stroke:
            path.append(world(u, v, pen_down_z))
        # Lift the pen at the end.
        uL, vL = stroke[-1]
        path.append(world(uL, vL, pen_up_z))

    return path


def plan_writing_path(pen_path, solve_fn, interpolate_fn, max_tilt_deg=15.0,
                      max_segment_mm=6.0, tilt_step_deg=1.0):
    """
    Densify a pen path and solve IK at every point, keeping the marker within
    +/- max_tilt_deg of straight-down (psi = -90) rather than a single fixed
    angle. At each densified point we try psi = -90 first, then small tilts
    outward (+/-1, +/-2, ...) up to max_tilt_deg, taking the first that's
    fully within joint limits.

    Why clamped tilt instead of a hard fixed psi: a perfectly vertical marker
    is the most reach-constrained pose, and small tilts (a few degrees) are
    visually fine for writing while dramatically enlarging the reachable
    writing area. max_tilt_deg=0 forces strictly vertical.

    This is passed the solver/interpolator as callables so the font module
    stays free of a hard dependency on the kinematics module:
      solve_fn(x, y, z, psi_deg) -> result dict with "thetas" and "violations",
                                     or raises the unreachable exception
      interpolate_fn(poses, max_seg_mm, max_seg_psi_deg) -> densified poses

    Returns (thetas_list, dense_poses, psi_used_list) on success, or raises
    WritingPlanError(index, point) at the first point that can't be solved
    within the tilt band and joint limits.
    """
    dense = interpolate_fn(pen_path, max_segment_mm, 3.0)

    # Build the tilt search order: 0, +step, -step, +2*step, -2*step, ...
    tilts = [0.0]
    d = tilt_step_deg
    while d <= max_tilt_deg + 1e-9:
        tilts.append(d)
        tilts.append(-d)
        d += tilt_step_deg

    thetas_list = []
    psi_used = []
    for i, (x, y, z, psi_base) in enumerate(dense):
        solved = None
        for dp in tilts:
            psi = psi_base + dp
            try:
                r = solve_fn(x, y, z, psi)
            except Exception:
                continue
            if not r["violations"]:
                solved = (r["thetas"], psi)
                break
        if solved is None:
            raise WritingPlanError(
                f"Writing point {i} ({x:.1f}, {y:.1f}, {z:.1f}) can't be reached "
                f"with the marker within {max_tilt_deg:.0f} deg of vertical and "
                f"inside joint limits. Try moving the text (position/height), "
                f"shrinking it, or allowing more tilt.",
                index=i, point=(x, y, z))
        thetas_list.append(solved[0])
        psi_used.append(solved[1])

    return thetas_list, dense, psi_used


class WritingPlanError(ValueError):
    """Raised when a writing path can't be solved within the tilt band + limits."""
    def __init__(self, message, index=None, point=None):
        super().__init__(message)
        self.index = index
        self.point = point




# ---------------------------------------------------------------------------
# Serial / firmware protocol defaults — real gcobos/grbl4axis over G-code
# ---------------------------------------------------------------------------
DEFAULT_BAUD = 115200   # grbl v0.9+ default; this fork inherits it

AXIS_LABELS = ["base", "shoulder", "elbow", "wrist"]

# NOTE ON THE 4-AXIS PIN MAPPING:
# gcobos/grbl4axis frees Uno pins D12/D13 for a 4th ("E") axis by disabling
# grbl's variable-spindle PWM feature. Confirm your CNC Shield / wiring
# actually routes the wrist driver's STEP/DIR to D12/D13 accordingly —
# this is a firmware-level pin choice made by that fork, not something this
# app controls.
#
# Protocol is now standard grbl G-code, not a custom line format:
#   - Motion:  "G90 G1 X<deg> Y<deg> Z<deg> E<deg> F<feed>\n" (absolute, feed-rate move)
#              or "G90 G0 X<deg> Y<deg> Z<deg> E<deg>\n" (absolute, rapid move)
#   - Grbl responds "ok\n" per accepted line, or "error:<n>\n" on rejection.
#   - Real-time commands (single character, no newline, no "ok" reply):
#       "?"  status report request
#       "!"  feed hold
#       "~"  cycle start / resume
#       0x18 (Ctrl-X) soft reset
#   - "$X\n" clears an ALARM lock (grbl starts in alarm state if homing is
#     enabled in settings but hasn't been run — common with no limit
#     switches wired up, which this project doesn't have per the plan).
#
# See py for the implementation and gui.py's "Grbl Setup"
# panel for pushing the $100-$103 steps/unit settings shown above.


# ============================================================================
# py
# ============================================================================
"""
py

Ported from the browser JS FK/IK simulator (plan section 5) into Python.

Two independent code paths, deliberately kept separate so one can validate
the other:

  1. forward_kinematics() — a fully general 4x4 DH matrix chain. Used for
     the live 3D view and to sanity-check IK solutions (re-run FK on a
     solved pose and compare against the requested target).

  2. solve_ik() — the closed-form geometric solver as derived in the plan:
       - theta1 = atan2(target_y, target_x), locked first
       - project the remaining target into the shoulder/elbow/wrist plane
         (which is tilted purely in the vertical, base-offset-shifted plane
         established by joint 1's alpha=90 twist)
       - subtract the wrist link (L3) along the desired tool angle psi to
         get a "wrist point", then solve a classic 2-link (L1, L2) planar
         IK via law of cosines
       - theta4 = psi - theta2 - theta3
       - elbow branch ('up' / 'down') selectable — this directly resolves
         the "elbow-up/elbow-down not yet implemented" open item.
"""

import numpy as np



def dh_matrix(theta_deg, d, a, alpha_deg):
    """Standard DH transform: Rot_z(theta) * Trans_z(d) * Trans_x(a) * Rot_x(alpha)."""
    t = np.radians(theta_deg)
    al = np.radians(alpha_deg)
    ct, st = np.cos(t), np.sin(t)
    ca, sa = np.cos(al), np.sin(al)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0.0,      sa,       ca,      d],
        [0.0,     0.0,      0.0,    1.0],
    ])


def _translation(dx, dy, dz):
    """A pure-translation 4x4 homogeneous transform."""
    M = np.eye(4)
    M[0, 3] = dx
    M[1, 3] = dy
    M[2, 3] = dz
    return M


def forward_kinematics(thetas_deg, dh_params=None, tool_offset=None):
    """
    Given 4 joint angles (degrees), return:
      - joint_positions: list of numpy 3-vectors (base origin, then each
        joint frame origin, ending at the TOOL TIP if a nonzero tool_offset
        is applied, otherwise at the wrist frame origin)
      - T_final: the full 4x4 transform of the tool frame in world coords

    tool_offset: (dx, dy, dz) mm in the wrist's own frame, applied as a final
    translation after the DH chain (rotates with the wrist). Defaults to
    load_tool_offset(). A nonzero offset appends the true tool tip as an
    extra point.
    """
    if dh_params is None:
        dh_params = DH_PARAMS
    if tool_offset is None:
        tool_offset = load_tool_offset()

    T = np.eye(4)
    positions = [T[:3, 3].copy()]
    for theta, params in zip(thetas_deg, dh_params):
        T = T @ dh_matrix(theta, params["d"], params["a"], params["alpha_deg"])
        positions.append(T[:3, 3].copy())

    # Axis mapping (verified empirically): dx->local x (reach, rotates w/ psi),
    # dy->local z (true sideways, rotates w/ theta1 only), dz->local y
    # (in-plane vertical, rotates w/ psi) -- matches the UI labels.
    dx, dy, dz = tool_offset
    if dx or dy or dz:
        T_tool = T @ _translation(dx, dz, dy)
        positions.append(T_tool[:3, 3].copy())
        return positions, T_tool

    return positions, T


class IKUnreachableError(ValueError):
    """Raised when the requested target/psi combination has no real solution."""
    pass


def solve_ik(x, y, z, psi_deg, elbow="up", side="A", tool_offset=None, dh_params=None):
    """
    Closed-form IK, extended from plan section 5.3 to target the TRUE TOOL
    TIP (Layer 2), not the wrist -- i.e. it accounts for the rigid tool
    offset (see load_tool_offset() / TOOL_OFFSET panel) so a requested
    (x, y, z) places the actual marker/gripper tip there, not the wrist.

    x, y, z     : target TOOL TIP position in world mm
    psi_deg     : desired tool angle within the arm's vertical plane (deg),
                  i.e. theta2+theta3+theta4
    elbow       : "up" or "down" -- selects the elbow branch (unchanged
                  from the original 3-link-only solver)
    side        : "A" or "B" -- NEW. Only matters when the tool has a
                  nonzero lateral ("dy", sideways) offset. "A" is the
                  direct solution (base pointing generally at the target);
                  "B" is the base rotated to reach the same tool-tip point
                  from roughly the opposite direction, valid only when the
                  target is close enough to the base axis for that to be
                  geometrically possible. With no lateral offset, both
                  sides give the same answer.
    tool_offset : (dx, dy, dz) mm in the wrist's own frame; defaults to
                  load_tool_offset(). dx = along reach (rotates with psi),
                  dy = true lateral/sideways (rotates with theta1 only),
                  dz = in-plane perpendicular to reach (rotates with psi).
                  See forward_kinematics for the verified mapping.

    Returns (theta1, theta2, theta3, theta4) in degrees.
    Raises IKUnreachableError if unreachable -- either because the lateral
    offset exceeds the target's distance from the base axis (no theta1
    solves the lateral equation on the requested side), or because the
    resulting 2-link reach is outside [|L1-L2|, L1+L2] (as before).
    """
    if dh_params is None:
        dh_params = DH_PARAMS
    if tool_offset is None:
        tool_offset = load_tool_offset()

    a1 = dh_params[0]["a"]
    L1 = dh_params[1]["a"]
    L2 = dh_params[2]["a"]
    L3 = dh_params[3]["a"]
    d1 = dh_params[0]["d"]

    dx_off, dy_off, dz_off = tool_offset

    # Step 1: base yaw. With no lateral offset this is the original plain
    # atan2. With a lateral offset (dy_off), the tool traces a plane shifted
    # sideways from the base axis by dy_off, so theta1 must satisfy
    # Px*sin(theta1) - Py*cos(theta1) = dy_off -- one equation, two branches
    # ("side" A/B), analogous to elbow up/down but for the base instead.
    R = np.hypot(x, y)
    if abs(dy_off) > R + 1e-9:
        raise IKUnreachableError(
            f"Target (x={x:.1f}, y={y:.1f}, z={z:.1f}) is too close to the base "
            f"axis (R={R:.1f}mm) for the {dy_off:.1f}mm lateral tool offset to "
            f"reach it on either side."
        )
    phi = np.arctan2(y, x)
    # Guard the asin domain against tiny float overshoot at the boundary.
    ratio = np.clip(dy_off / R, -1.0, 1.0) if R > 1e-9 else 0.0
    asin_term = np.arcsin(ratio)
    if side == "B":
        theta1 = np.degrees(phi + np.pi - asin_term)
    else:
        theta1 = np.degrees(phi + asin_term)
    t1 = np.radians(theta1)

    # Step 2: remove the lateral offset from the target to get the point's
    # true position IN the arm's vertical plane (see forward_kinematics: the
    # plane's normal is (sin(theta1), -cos(theta1), 0)).
    nx, ny = np.sin(t1), -np.cos(t1)
    xp = x - dy_off * nx
    yp = y - dy_off * ny
    zp = z  # normal has no z-component

    # Step 3: project into the plane (u, v), same as the original derivation,
    # now using the lateral-corrected point.
    u = (xp - a1 * np.cos(t1)) * np.cos(t1) + (yp - a1 * np.sin(t1)) * np.sin(t1)
    v = zp - d1

    # Step 4: subtract the in-plane tool offset components (dx_off along
    # psi, dz_off perpendicular to psi) plus the wrist link L3, to get the
    # 2-link wrist point. dx_off=dz_off=0 reduces exactly to the original
    # "subtract L3 along psi" formula.
    psi = np.radians(psi_deg)
    uw = u - (L3 + dx_off) * np.cos(psi) + dz_off * np.sin(psi)
    vw = v - (L3 + dx_off) * np.sin(psi) - dz_off * np.cos(psi)

    # Step 5: classic 2-link planar IK, law of cosines (unchanged).
    r2 = uw ** 2 + vw ** 2
    D = (r2 - L1 ** 2 - L2 ** 2) / (2 * L1 * L2)

    if abs(D) > 1.0 + 1e-9:
        raise IKUnreachableError(
            f"Target (x={x:.1f}, y={y:.1f}, z={z:.1f}) with psi={psi_deg:.1f} deg "
            f"is out of reach (|D|={abs(D):.3f} > 1)."
        )
    D = np.clip(D, -1.0, 1.0)

    sign = 1.0 if elbow == "down" else -1.0
    theta3 = np.degrees(np.arctan2(sign * np.sqrt(max(0.0, 1 - D ** 2)), D))

    t3 = np.radians(theta3)
    theta2 = np.degrees(
        np.arctan2(vw, uw) - np.arctan2(L2 * np.sin(t3), L1 + L2 * np.cos(t3))
    )

    theta4 = psi_deg - theta2 - theta3

    return theta1, theta2, theta3, theta4


def verify_ik(thetas_deg, target_xyz, tol_mm=0.5, tool_offset=None):
    """
    Re-run FK on a solved pose and check the TOOL TIP (Layer 2: solve_ik now
    targets the tip, using the same tool_offset default) lands within
    tol_mm of the requested target. Returns (ok: bool, residual_mm: float).
    """
    positions, _ = forward_kinematics(thetas_deg, tool_offset=tool_offset)
    tip = positions[-1]
    residual = float(np.linalg.norm(tip - np.array(target_xyz)))
    return residual <= tol_mm, residual


def apply_home_offset(thetas_deg, home_offset_deg=None):
    """
    Convert DH-frame solved joint angles into real motor angles by applying
    the home offset calibration (plan section 5.4):

        motor_angle = theta_dh - home_offset

    With grbl doing the degrees->steps conversion itself (via its $100-$103
    steps-per-unit settings, see py), this motor_angle in degrees is
    exactly what gets sent as the G-code axis word — no step math needed on
    the host side.
    """
    if home_offset_deg is None:
        home_offset_deg = load_home_offsets()
    return [theta - offset for theta, offset in zip(thetas_deg, home_offset_deg)]


def remove_home_offset(motor_angles_deg, home_offset_deg=None):
    """Inverse of apply_home_offset — e.g. to interpret a status report back into DH-frame angles."""
    if home_offset_deg is None:
        home_offset_deg = load_home_offsets()
    return [angle + offset for angle, offset in zip(motor_angles_deg, home_offset_deg)]


def estimated_steps_for_display(thetas_deg, home_offset_deg=None):
    """
    Informational only — NOT sent to grbl. Shows the equivalent raw step
    count for a given pose, purely so you can sanity-check against the
    physical gearbox (e.g. confirm a move "looks like" a sensible number of
    steps) without grbl actually receiving step counts directly.
    """
    motor_angles = apply_home_offset(thetas_deg, home_offset_deg)
    return [int(round(angle * spd)) for angle, spd in zip(motor_angles, GRBL_STEPS_PER_DEGREE)]


def check_joint_limits(thetas_deg, limits=None):
    """
    Returns a list of (index, theta, lo, hi) for any violations.
    Empty list means all clear. JOINT_LIMITS_DEG holds the measured
    hardware limits (plan section 8, closed out).
    """
    if limits is None:
        limits = JOINT_LIMITS_DEG
    violations = []
    for i, (theta, (lo, hi)) in enumerate(zip(thetas_deg, limits)):
        if not (lo <= theta <= hi):
            violations.append((i, theta, lo, hi))
    return violations


def _violation_severity(violations):
    """Sum of how far out-of-range each violation is, in degrees. Used only
    to pick the "less bad" of two invalid branches -- not a measure of safety."""
    total = 0.0
    for _, theta, lo, hi in violations:
        total += max(lo - theta, theta - hi, 0.0)
    return total


def solve_ik_constrained(x, y, z, psi_deg, limits=None, prefer_elbow="up",
                          prefer_side="A", tool_offset=None, dh_params=None):
    """
    Joint-limit-aware wrapper around solve_ik(). Tries the preferred
    elbow/side combination first; if it violates a joint limit, retries the
    other combinations (up to 4: elbow up/down x side A/B). Returns
    whichever combination is fully valid, preferring ones closest to what
    was requested, or (if none are) the one with the smaller total
    violation -- so the caller always gets an actual answer plus an honest
    account of what's wrong with it.

    prefer_side only matters when a nonzero lateral tool offset is active
    (see solve_ik's "side" parameter) -- with no lateral offset, "A" and
    "B" solve to the same angles, so this is a no-op for the un-offset case.

    IMPORTANT: JOINT_LIMITS_DEG holds the measured hardware limits (plan
    section 8, closed out). One caveat: J1's +/-180 deg range assumes it's
    a true continuous-rotation joint with no hard stop -- double-check that
    before trusting base-yaw moves near that boundary.
    """
    if limits is None:
        limits = JOINT_LIMITS_DEG

    other_elbow = "down" if prefer_elbow == "up" else "up"
    other_side = "B" if prefer_side == "A" else "A"

    combos = [
        (prefer_elbow, prefer_side),
        (other_elbow, prefer_side),
        (prefer_elbow, other_side),
        (other_elbow, other_side),
    ]

    candidates = []
    for elbow, side in combos:
        try:
            thetas = solve_ik(x, y, z, psi_deg, elbow=elbow, side=side,
                               tool_offset=tool_offset, dh_params=dh_params)
        except IKUnreachableError:
            continue
        violations = check_joint_limits(thetas, limits)
        candidates.append((elbow, side, thetas, violations))

    if not candidates:
        solve_ik(x, y, z, psi_deg, elbow=prefer_elbow, side=prefer_side,
                 tool_offset=tool_offset, dh_params=dh_params)

    valid = [c for c in candidates if not c[3]]
    if valid:
        for elbow, side, thetas, violations in valid:
            if elbow == prefer_elbow and side == prefer_side:
                return {"thetas": thetas, "elbow_used": elbow, "elbow_switched": False,
                        "side_used": side, "side_switched": False, "violations": []}
        elbow, side, thetas, violations = valid[0]
        return {"thetas": thetas, "elbow_used": elbow,
                "elbow_switched": elbow != prefer_elbow,
                "side_used": side, "side_switched": side != prefer_side,
                "violations": []}

    candidates.sort(key=lambda c: _violation_severity(c[3]))
    elbow, side, thetas, violations = candidates[0]
    return {"thetas": thetas, "elbow_used": elbow,
            "elbow_switched": elbow != prefer_elbow,
            "side_used": side, "side_switched": side != prefer_side,
            "violations": violations}


def find_feasible_psi(x, y, z, base_psi_deg, limits=None, prefer_elbow="up",
                       prefer_side="A", tool_offset=None, dh_params=None,
                       search_step_deg=2.0, max_offset_deg=178.0):
    """
    Search for the psi value nearest to base_psi_deg (e.g. a named preset
    like "level" = 0 deg) for which solve_ik_constrained() finds a fully
    joint-limit-valid solution (searching elbow AND side branches). Returns
    the FIRST feasible hit found while searching outward from base_psi_deg,
    or None if nothing within +/-max_offset_deg is fully valid.
    """
    if limits is None:
        limits = JOINT_LIMITS_DEG

    offsets = [0.0]
    n = 1
    while n * search_step_deg <= max_offset_deg:
        offsets.append(n * search_step_deg)
        offsets.append(-n * search_step_deg)
        n += 1

    for offset in offsets:
        psi = base_psi_deg + offset
        try:
            result = solve_ik_constrained(x, y, z, psi, limits=limits,
                                           prefer_elbow=prefer_elbow, prefer_side=prefer_side,
                                           tool_offset=tool_offset, dh_params=dh_params)
        except IKUnreachableError:
            continue
        if not result["violations"]:
            result["psi_used"] = psi
            result["offset_from_base_deg"] = offset
            return result

    return None


def find_feasible_psi_presets(x, y, z, presets=None, limits=None, prefer_elbow="up",
                               prefer_side="A", tool_offset=None, dh_params=None):
    """Runs find_feasible_psi() for every named preset in PSI_PRESETS."""
    if presets is None:
        presets = PSI_PRESETS
    return {
        name: find_feasible_psi(x, y, z, base_psi, limits=limits,
                                 prefer_elbow=prefer_elbow, prefer_side=prefer_side,
                                 tool_offset=tool_offset, dh_params=dh_params)
        for name, base_psi in presets.items()
    }


# ---------------------------------------------------------------------------
# Waypoint path planning (plan sections 6 & 7). A path is a list of Cartesian
# (x, y, z, psi) poses; we densify into short segments (so grbl 0.9 blends
# them into smooth motion), solve IK at every point, and validate against
# joint limits BEFORE any hardware command is sent.
# ---------------------------------------------------------------------------


class PathPlanningError(ValueError):
    """Raised when a waypoint path can't be fully solved within joint limits."""
    def __init__(self, message, index=None, point=None):
        super().__init__(message)
        self.index = index
        self.point = point


def _interpolate_poses(poses, max_segment_mm=5.0, max_segment_psi_deg=3.0):
    if len(poses) < 2:
        return list(poses)
    dense = [tuple(poses[0])]
    for a, b in zip(poses[:-1], poses[1:]):
        ax, ay, az, apsi = a
        bx, by, bz, bpsi = b
        dist = np.sqrt((bx - ax) ** 2 + (by - ay) ** 2 + (bz - az) ** 2)
        dpsi = abs(bpsi - apsi)
        n_pos = int(np.ceil(dist / max_segment_mm)) if max_segment_mm > 0 else 1
        n_psi = int(np.ceil(dpsi / max_segment_psi_deg)) if max_segment_psi_deg > 0 else 1
        n = max(1, n_pos, n_psi)
        for k in range(1, n + 1):
            t = k / n
            dense.append((ax + (bx - ax) * t, ay + (by - ay) * t,
                          az + (bz - az) * t, apsi + (bpsi - apsi) * t))
    return dense


def plan_waypoint_path(poses, limits=None, prefer_elbow="up", prefer_side="A",
                        tool_offset=None, dh_params=None,
                        max_segment_mm=5.0, max_segment_psi_deg=3.0,
                        auto_psi=False, psi_presets=None):
    """
    Turn a list of (x, y, z, psi) waypoints into a validated list of joint-
    angle solutions ready to stream. If auto_psi, psi is nudged into limits
    at each point via find_feasible_psi. Raises PathPlanningError (with
    .index / .point) at the first unsolvable/limit-violating point.

    Returns {"dense_poses", "thetas", "elbow_used", "side_used", "psi_used"}.
    """
    if limits is None:
        limits = JOINT_LIMITS_DEG
    dense = _interpolate_poses(poses, max_segment_mm, max_segment_psi_deg)
    thetas_list, elbow_list, side_list, psi_list = [], [], [], []
    for i, (x, y, z, psi) in enumerate(dense):
        if auto_psi:
            result = find_feasible_psi(x, y, z, psi, limits=limits,
                                        prefer_elbow=prefer_elbow, prefer_side=prefer_side,
                                        tool_offset=tool_offset, dh_params=dh_params)
            if result is None:
                raise PathPlanningError(
                    f"Path point {i} ({x:.1f}, {y:.1f}, {z:.1f}) has no feasible "
                    f"tool angle near psi={psi:.1f} within joint limits.",
                    index=i, point=(x, y, z, psi))
        else:
            try:
                result = solve_ik_constrained(x, y, z, psi, limits=limits,
                                               prefer_elbow=prefer_elbow, prefer_side=prefer_side,
                                               tool_offset=tool_offset, dh_params=dh_params)
            except IKUnreachableError as e:
                raise PathPlanningError(
                    f"Path point {i} ({x:.1f}, {y:.1f}, {z:.1f}) is geometrically "
                    f"unreachable: {e}", index=i, point=(x, y, z, psi)) from e
            if result["violations"]:
                v = result["violations"]
                raise PathPlanningError(
                    f"Path point {i} ({x:.1f}, {y:.1f}, {z:.1f}, psi={psi:.1f}) "
                    f"violates joint limits: "
                    + "; ".join(f"j{j}={t:.1f} (limit {lo}..{hi})" for j, t, lo, hi in v),
                    index=i, point=(x, y, z, psi))
        thetas_list.append(result["thetas"])
        elbow_list.append(result["elbow_used"])
        side_list.append(result.get("side_used", "A"))
        psi_list.append(result.get("psi_used", psi))
    return {"dense_poses": dense, "thetas": thetas_list,
            "elbow_used": elbow_list, "side_used": side_list, "psi_used": psi_list}


def line_sweep(start_xyz, end_xyz, psi_deg, num_waypoints=2):
    """Straight line between two Cartesian points at fixed tool angle."""
    sx, sy, sz = start_xyz
    ex, ey, ez = end_xyz
    n = max(2, num_waypoints)
    poses = []
    for k in range(n):
        t = k / (n - 1)
        poses.append((sx + (ex - sx) * t, sy + (ey - sy) * t,
                      sz + (ez - sz) * t, psi_deg))
    return poses


def circle_path(center_xyz, radius_mm, psi_deg, plane="xy", num_waypoints=48,
                 start_angle_deg=0.0, revolutions=1.0):
    """Waypoints tracing a circle at fixed tool angle. plane in {xy,xz,yz}."""
    cx, cy, cz = center_xyz
    n = max(8, int(num_waypoints * revolutions))
    poses = []
    for k in range(n + 1):
        ang = np.radians(start_angle_deg) + 2 * np.pi * revolutions * (k / n)
        c, s = np.cos(ang), np.sin(ang)
        if plane == "xy":
            poses.append((cx + radius_mm * c, cy + radius_mm * s, cz, psi_deg))
        elif plane == "xz":
            poses.append((cx + radius_mm * c, cy, cz + radius_mm * s, psi_deg))
        elif plane == "yz":
            poses.append((cx, cy + radius_mm * c, cz + radius_mm * s, psi_deg))
        else:
            raise ValueError(f"Unknown plane '{plane}' (use 'xy', 'xz', or 'yz').")
    return poses


# ============================================================================
# py
# ============================================================================
"""
py

Talks to a real grbl / gcobos/grbl4axis controller over serial using
standard grbl semantics — NOT a custom line protocol.

Key facts about how grbl actually behaves, baked into this module:

  - On opening the serial port, grbl resets and prints a startup banner
    like "Grbl 0.9j ['$' for help]" after ~1-2 seconds. We wait for and
    capture that.
  - Every G-code line you send gets exactly one response line back:
    "ok" on success, or "error:<n>" on rejection. We send one line at a
    time and block until that response arrives (grbl's RX buffer is small
    — 127 bytes — so this simple one-at-a-time flow is the safe way to
    drive it from a GUI that sends one pose at a time, as opposed to
    streaming a whole G-code file, which would need character-counting).
  - Real-time commands are single bytes, sent with NO trailing newline,
    and do NOT get an "ok" response: "?" (status query), "!" (feed hold),
    "~" (cycle start/resume), and 0x18 / Ctrl-X (soft reset).
  - Grbl settings ($100, $101, ...) are pushed the same way as a G-code
    line: "$100=20.000\n" gets an "ok" back and is stored in EEPROM
    immediately (persists across power cycles).
  - If grbl's homing-required setting is on but no homing cycle has been
    run (this project has no limit switches per the plan), grbl boots
    into ALARM state and rejects all motion until you send "$X\n" to
    clear the lock, or run a homing cycle it doesn't have hardware for.
    This bridge exposes unlock() for that.
"""

import time

import serial
import serial.tools.list_ports



class SerialBridgeError(RuntimeError):
    pass


class GrblAlarmError(SerialBridgeError):
    """Raised when grbl rejects a move because it's in ALARM state."""
    pass


def coordinated_feed(prev_angles_deg, target_angles_deg, per_axis_max_deg_per_min,
                      requested_feed=None):
    """
    Work out the fastest single G-code feed rate F that respects a DIFFERENT
    speed limit on every joint.

    Why this is needed: G-code's F is one coordinated rate for the whole
    move, not a per-axis value. For per-joint deltas d_i and path length
    L = sqrt(sum(d_i^2)), grbl traverses the path at F, so joint i actually
    moves at  F * |d_i| / L.

    Requiring  F * |d_i| / L  <=  max_i  for every joint gives
        F  <=  max_i * L / |d_i|
    so the usable feed is the minimum of that expression over all moving
    joints. A joint that isn't moving (d_i == 0) imposes no limit.

    prev_angles_deg may be None (position unknown, e.g. right after
    connecting) — in that case we can't compute deltas, so we fall back to
    the most conservative choice: the slowest joint's limit.

    Returns a feed in deg/min, never above requested_feed when that's given.
    """
    limits = [abs(float(m)) for m in per_axis_max_deg_per_min]

    if prev_angles_deg is None or len(prev_angles_deg) != len(target_angles_deg):
        feed = min(limits)
        return min(feed, requested_feed) if requested_feed is not None else feed

    deltas = [float(t) - float(p) for t, p in zip(target_angles_deg, prev_angles_deg)]
    length = math.sqrt(sum(d * d for d in deltas))

    if length <= 1e-9:
        # Zero-length move; nothing to scale. Just honour the request.
        return requested_feed if requested_feed is not None else min(limits)

    allowed = []
    for d, lim in zip(deltas, limits):
        if abs(d) > 1e-9:
            allowed.append(lim * length / abs(d))

    feed = min(allowed) if allowed else min(limits)
    if requested_feed is not None:
        feed = min(feed, requested_feed)
    return max(feed, 1.0)   # grbl rejects F0; keep it positive


class SerialBridge:
    def __init__(self):
        self._ser = None
        self.startup_banner = []
        self.last_status = ""
        # Last absolute motor position this bridge commanded, used to derive
        # per-axis deltas for the coordinated feed calculation.
        self.last_motor_angles = None

    # -- connection management ------------------------------------------------

    @staticmethod
    def list_ports():
        return [(p.device, p.description) for p in serial.tools.list_ports.comports()]

    def connect(self, port, baud=None, timeout=2.0):
        if baud is None:
            baud = DEFAULT_BAUD
        if self.is_connected():
            self.disconnect()
        try:
            self._ser = serial.Serial(port, baud, timeout=timeout)
        except serial.SerialException as e:
            self._ser = None
            raise SerialBridgeError(f"Failed to open {port}: {e}") from e

        # Grbl resets on serial open (Arduino auto-reset via DTR) and prints
        # a startup banner a moment later. Capture it rather than discarding
        # it, since it also confirms which grbl version/build is on there.
        self.startup_banner = []
        deadline = time.time() + 3.0
        time.sleep(1.5)  # let the bootloader/grbl init finish before reading
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line:
                    self.startup_banner.append(line)
            else:
                time.sleep(0.05)

    def disconnect(self):
        if self._ser is not None:
            try:
                self._ser.close()
            finally:
                self._ser = None

    def is_connected(self):
        return self._ser is not None and self._ser.is_open

    # -- core line protocol ------------------------------------------------

    def send_line(self, line, timeout=10.0):
        """
        Send one G-code / '$' line, block until grbl responds with 'ok' or
        'error:<n>'. Returns the full list of lines received (there may be
        extra informational lines before the ok/error, e.g. for '$$').
        Raises GrblAlarmError on ALARM responses, SerialBridgeError on
        error:<n> responses or a timeout.
        """
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")

        if not line.endswith("\n"):
            line += "\n"
        self._ser.write(line.encode("utf-8"))

        lines = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._ser.in_waiting:
                raw = self._ser.readline().decode("utf-8", errors="replace").strip()
                if not raw:
                    continue
                lines.append(raw)
                lower = raw.lower()
                if lower == "ok":
                    return lines
                if lower.startswith("error:"):
                    raise SerialBridgeError(f"Grbl rejected '{line.strip()}': {raw}")
                if lower.startswith("alarm:"):
                    raise GrblAlarmError(
                        f"Grbl is in ALARM state ({raw}). Send $X to unlock before moving."
                    )
            else:
                time.sleep(0.02)

        raise SerialBridgeError(f"Timed out waiting for response to '{line.strip()}'.")

    # -- real-time single-byte commands (no newline, no 'ok') ---------------

    def request_status(self):
        """Send '?' and capture the '<...>' status report line grbl sends back."""
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"?")
        deadline = time.time() + 2.0
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line.startswith("<") and line.endswith(">"):
                    self.last_status = line
                    return line
            else:
                time.sleep(0.02)
        return ""

    def feed_hold(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"!")

    def cycle_start_resume(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"~")

    def soft_reset(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(bytes([0x18]))
        time.sleep(0.5)

    def unlock(self):
        """Clear an ALARM lock (grbl boots into alarm if homing-required but not yet homed)."""
        return self.send_line("$X")

    # -- G-code construction & sending --------------------------------------

    def build_move_gcode(self, motor_angles_deg, feed_deg_per_min=None, rapid=False,
                          per_axis_max_deg_per_min=None, prev_angles_deg=None):
        """
        motor_angles_deg: 4 values already home-offset-adjusted (see
        kinematics.apply_home_offset) — these get sent directly as axis
        words, in absolute positioning mode (G90).

        feed_deg_per_min: ignored if rapid=True (uses G0). Required
        (falls back to DEFAULT_FEED_DEG_PER_MIN) for G1 moves.

        per_axis_max_deg_per_min: optional 4-element list of per-joint speed
        ceilings. When given, the requested feed is reduced (never raised) to
        the largest value that keeps EVERY axis under its own limit — see
        coordinated_feed(). grbl's $110-$113 still act as the hard backstop
        in firmware regardless; this just means we ask for something sane
        rather than always being clamped.

        prev_angles_deg: the position this move starts from, used to compute
        the per-axis deltas. Defaults to the last position this bridge sent
        (tracked automatically), so callers streaming a path don't have to
        thread it through manually.
        """
        axis_words = " ".join(
            f"{letter}{angle:.3f}"
            for letter, angle in zip(GRBL_AXIS_LETTERS, motor_angles_deg)
        )

        if rapid:
            self.last_motor_angles = list(motor_angles_deg)
            return f"G90 G0 {axis_words}"

        feed = feed_deg_per_min if feed_deg_per_min is not None else DEFAULT_FEED_DEG_PER_MIN

        if per_axis_max_deg_per_min is not None:
            start = prev_angles_deg if prev_angles_deg is not None else self.last_motor_angles
            feed = coordinated_feed(start, motor_angles_deg,
                                     per_axis_max_deg_per_min, requested_feed=feed)

        self.last_motor_angles = list(motor_angles_deg)
        return f"G90 G1 {axis_words} F{feed:.1f}"

    def send_move(self, motor_angles_deg, feed_deg_per_min=None, rapid=False, timeout=15.0,
                   per_axis_max_deg_per_min=None):
        """Build and send an absolute-position move. Returns grbl's response lines."""
        line = self.build_move_gcode(motor_angles_deg, feed_deg_per_min, rapid,
                                      per_axis_max_deg_per_min=per_axis_max_deg_per_min)
        return self.send_line(line, timeout=timeout)

    def push_steps_per_unit_settings(self):
        """
        One-time setup helper: push steps-per-degree into grbl's $100-$103
        EEPROM settings so 1 G-code unit == 1 output degree for every joint.
        Returns a list of (setting, value, response_lines).

        Reads from the SAVED MOTION PROFILE rather than the static full-step
        constants, so this can't silently undo a per-axis microstepping change
        made in the Motion Tuning tab. Use push_motion_profile() to write the
        speeds and accelerations as well.
        """
        steps = load_motion_profile()["steps_per_deg"]
        results = []
        for setting, value in zip(GRBL_SETTING_NUMBERS, steps):
            line = f"{setting}={value:.4f}"
            response = self.send_line(line)
            results.append((setting, value, response))
        return results

    def push_motion_profile(self, profile=None):
        """
        Push a full per-axis motion profile into grbl's EEPROM:
          $100-$103  steps per degree
          $110-$113  max rate  (deg/min)  -- the hard per-axis speed ceiling
          $120-$123  acceleration (deg/sec^2)

        These persist across power cycles. Returns a list of
        (setting, value, response_lines) for logging.

        NOTE: $110-$113 are what actually stop one joint from being driven
        faster than it can handle. If they're left lower than the feed the
        app requests, grbl silently clamps every move to them — so pushing
        this profile is what makes the per-axis speeds real on the hardware.
        """
        if profile is None:
            profile = load_motion_profile()

        results = []
        groups = [
            (GRBL_SETTING_NUMBERS, profile["steps_per_deg"], 4),
            (GRBL_MAX_RATE_SETTINGS, profile["max_speed_deg_per_min"], 2),
            (GRBL_ACCEL_SETTINGS, profile["accel_deg_per_sec2"], 2),
        ]
        for settings, values, decimals in groups:
            for setting, value in zip(settings, values):
                line = f"{setting}={value:.{decimals}f}"
                response = self.send_line(line)
                results.append((setting, value, response))
        return results

    def send_raw(self, line):
        """Send an arbitrary raw line and wait for ok/error — for manual debugging."""
        return self.send_line(line)

    def stream_gcode(self, lines, on_progress=None, should_abort=None, timeout=15.0):
        """
        Stream a whole list of G-code lines continuously, one after another,
        WITHOUT pausing between them -- this is what produces SMOOTH motion
        on grbl 0.9 (no jog mode): keeping lines flowing keeps grbl's planner
        buffer full so it blends cornering velocity between short moves.

        should_abort() is checked before each line; if it returns True we
        send a feed-hold (!) and stop. Returns (sent_count, aborted).
        Run on a background thread since send_line blocks.
        """
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")

        total = len(lines)
        for i, line in enumerate(lines):
            if should_abort is not None and should_abort():
                try:
                    self.feed_hold()
                except SerialBridgeError:
                    pass
                return i, True
            response = self.send_line(line, timeout=timeout)
            if on_progress is not None:
                on_progress(i, total, line, response)
        return total, False

    def read_available(self):
        """Non-blocking read of whatever's currently buffered (e.g. unsolicited grbl messages)."""
        if not self.is_connected():
            return []
        lines = []
        while self._ser.in_waiting:
            line = self._ser.readline().decode("utf-8", errors="replace").strip()
            if line:
                lines.append(line)
        return lines


# ============================================================================
# gui.py
# ============================================================================
"""
gui.py

PyQt5 desktop app tying together py and py.

Layout:
  Left column:
    - Joint jog sliders (theta1..theta4) with live degree readout
    - Target pose panel (X, Y, Z, psi, elbow up/down) + "Solve IK" button
    - Home offset calibration panel (4 fields, Save/Reload)
  Right column:
    - Live 3D plot of the arm (matplotlib, driven by forward_kinematics())
  Bottom:
    - Serial connection panel: port dropdown, connect/disconnect, one-time
      $100-$103 grbl settings push, unlock/status/feed-hold/resume/soft-reset,
      feed-rate input, and "Send Current Pose to Grbl" (real G-code, not
      raw step counts — see py)

Run via main.py.
"""

import sys

import numpy as np
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure



class PathStreamWorker(QtCore.QThread):
    """Streams a planned waypoint path to grbl on a background thread."""
    progress = QtCore.pyqtSignal(int, int)
    finished_streaming = QtCore.pyqtSignal(int, bool)
    error = QtCore.pyqtSignal(str)

    def __init__(self, bridge, gcode_lines, feed_deg_per_min, parent=None):
        super().__init__(parent)
        self.bridge = bridge
        self.gcode_lines = gcode_lines
        self.feed = feed_deg_per_min
        self._abort = False

    def request_abort(self):
        self._abort = True

    def run(self):
        try:
            sent, aborted = self.bridge.stream_gcode(
                self.gcode_lines,
                on_progress=lambda i, total, line, resp: self.progress.emit(i + 1, total),
                should_abort=lambda: self._abort,
            )
            self.finished_streaming.emit(sent, aborted)
        except SerialBridgeError as e:
            self.error.emit(str(e))


class Arm3DCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(5, 5))
        super().__init__(fig)
        self.setParent(parent)
        self.ax = fig.add_subplot(111, projection="3d")
        self._reach = sum(p["a"] for p in DH_PARAMS) + 50
        self.plot_pose([0, 0, 0, 0])

    def plot_pose(self, thetas_deg, target_xyz=None, path_xyz=None, tool_offset=None):
        positions, _ = forward_kinematics(thetas_deg, tool_offset=tool_offset)
        pts = np.array(positions)

        self.ax.clear()
        if path_xyz is not None and len(path_xyz) > 1:
            path = np.array(path_xyz)
            self.ax.plot(path[:, 0], path[:, 1], path[:, 2], "-",
                         color="#9b59b6", linewidth=1.2, alpha=0.7)
        # Arm links
        self.ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], "-o", color="#2a6fdb",
                     linewidth=3, markersize=6, markerfacecolor="#ff6a3d")
        # Base marker
        self.ax.scatter([0], [0], [0], color="black", s=40, marker="s")

        if target_xyz is not None:
            self.ax.scatter([target_xyz[0]], [target_xyz[1]], [target_xyz[2]],
                             color="green", s=60, marker="*", label="target")
            self.ax.legend(loc="upper left", fontsize=8)

        r = self._reach
        self.ax.set_xlim(-r, r)
        self.ax.set_ylim(-r, r)
        self.ax.set_zlim(0, 2 * r)
        self.ax.set_xlabel("X (mm)")
        self.ax.set_ylabel("Y (mm)")
        self.ax.set_zlabel("Z (mm)")
        self.ax.set_title("4-DOF arm — live DH pose")
        self.draw()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4-DOF Arm Control")
        self.resize(1500, 950)
        self.setMinimumSize(1300, 800)
        self.setStyleSheet(APP_STYLE)

        self.bridge = SerialBridge()
        self.current_thetas = [0.0, 0.0, 0.0, 0.0]
        self.last_target_xyz = None

        central = QtWidgets.QWidget()
        central.setObjectName("central")
        self.setCentralWidget(central)
        root_layout = QtWidgets.QVBoxLayout(central)

        top_layout = QtWidgets.QHBoxLayout()
        root_layout.addLayout(top_layout, stretch=1)

        self.left_tabs = QtWidgets.QTabWidget()
        self.left_tabs.setMinimumWidth(540)
        top_layout.addWidget(self.left_tabs, stretch=0)

        self.canvas = Arm3DCanvas(self)
        top_layout.addWidget(self.canvas, stretch=1)

        single_pose_tab = QtWidgets.QWidget()
        single_col = QtWidgets.QVBoxLayout(single_pose_tab)
        single_col.setSpacing(10)
        for panel in (self._build_jog_panel(), self._build_ik_panel(),
                      self._build_calibration_panel(), self._build_tool_offset_panel()):
            panel.setSizePolicy(QtWidgets.QSizePolicy.Preferred,
                                QtWidgets.QSizePolicy.Fixed)
            single_col.addWidget(panel)
        single_col.addStretch(1)
        self.left_tabs.addTab(self._wrap_scroll(single_pose_tab), "Single Pose")

        self.left_tabs.addTab(self._wrap_scroll(self._build_waypoint_tab()), "Waypoint Path")
        self.left_tabs.addTab(self._wrap_scroll(self._build_writing_tab()), "Write Text")
        self.left_tabs.addTab(self._wrap_scroll(self._build_motion_tab()), "Motion Tuning")

        root_layout.addWidget(self._build_serial_panel(), stretch=0)

        self._refresh_ports()
        self._update_pose(send=False)

    # -- panels ------------------------------------------------------------

    def _wrap_scroll(self, inner_widget):
        """Put a tab's contents in a vertical scroll area so panels keep their
        natural height instead of being compressed into unreadable overlap."""
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setWidget(inner_widget)
        return scroll

    def _build_jog_panel(self):
        box = QtWidgets.QGroupBox("Joint Jog (degrees)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.joint_sliders = []
        self.joint_labels = []
        names = ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"]
        for i, name in enumerate(names):
            lo, hi = JOINT_LIMITS_DEG[i]
            # J1 has no hard stop (true continuous rotation), so its real
            # limit is +/-inf -- Qt sliders need a finite range, so give it
            # a generous jog range (a few full turns either way) purely for
            # the UI. This does NOT feed into check_joint_limits(), which
            # still correctly treats J1 as unbounded.
            if not math.isfinite(lo) or not math.isfinite(hi):
                lo, hi = -720.0, 720.0
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setMinimum(int(lo))
            slider.setMaximum(int(hi))
            slider.setValue(0)
            slider.setMinimumWidth(220)
            slider.valueChanged.connect(self._on_jog_changed)

            label = QtWidgets.QLabel(f"{name}: 0.0°")
            label.setMinimumWidth(140)
            layout.addWidget(label, i, 0)
            layout.addWidget(slider, i, 1)
            self.joint_sliders.append(slider)
            self.joint_labels.append(label)

        return box

    def _build_ik_panel(self):
        box = QtWidgets.QGroupBox("Target Pose (Inverse Kinematics)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(10)
        layout.setContentsMargins(12, 16, 12, 12)

        self.x_input = QtWidgets.QDoubleSpinBox()
        self.y_input = QtWidgets.QDoubleSpinBox()
        self.z_input = QtWidgets.QDoubleSpinBox()
        self.psi_input = QtWidgets.QDoubleSpinBox()
        for w in (self.x_input, self.y_input, self.z_input, self.psi_input):
            w.setMinimumWidth(90)
            w.setMinimumHeight(28)
        for w in (self.x_input, self.y_input, self.z_input):
            w.setRange(-1000, 1000)
            w.setDecimals(1)
            w.setSuffix(" mm")
        self.psi_input.setRange(-360, 360)
        self.psi_input.setSuffix(" deg")
        self.z_input.setValue(200.0)
        self.x_input.setValue(300.0)

        self.elbow_up = QtWidgets.QRadioButton("Elbow up")
        self.elbow_down = QtWidgets.QRadioButton("Elbow down")
        self.elbow_up.setChecked(True)
        elbow_group = QtWidgets.QButtonGroup(self)
        elbow_group.addButton(self.elbow_up)
        elbow_group.addButton(self.elbow_down)

        self.side_a = QtWidgets.QRadioButton("Side A (direct)")
        self.side_b = QtWidgets.QRadioButton("Side B (reach-around)")
        self.side_a.setChecked(True)
        side_group = QtWidgets.QButtonGroup(self)
        side_group.addButton(self.side_a)
        side_group.addButton(self.side_b)
        side_tip = (
            "Only matters with a nonzero lateral tool offset (see Tool Offset panel). "
            "'A' is the direct base angle toward the target; 'B' rotates the base to reach "
            "the same tool-tip point from roughly the opposite direction -- only "
            "geometrically possible for targets close enough to the base axis."
        )
        self.side_a.setToolTip(side_tip)
        self.side_b.setToolTip(side_tip)

        solve_btn = _style_button(QtWidgets.QPushButton("Solve IK"), "primary")
        solve_btn.setMinimumHeight(32)
        solve_btn.clicked.connect(self._on_solve_ik)

        preset_row = QtWidgets.QHBoxLayout()
        preset_row.setSpacing(8)
        for name in PSI_PRESETS:
            btn = QtWidgets.QPushButton(f"Auto: {name}")
            btn.setMinimumHeight(30)
            btn.setMinimumWidth(110)
            btn.setToolTip(
                f"Finds the psi nearest to the '{name}' preset "
                f"({PSI_PRESETS[name]:.0f} deg) that satisfies joint limits "
                "on either elbow/side branch, sets it, and solves."
            )
            btn.clicked.connect(lambda checked, n=name: self._on_preset_psi(n))
            preset_row.addWidget(btn)

        self.ik_status = QtWidgets.QLabel("")
        self.ik_status.setWordWrap(True)
        self.ik_status.setMinimumHeight(60)

        layout.addWidget(QtWidgets.QLabel("X"), 0, 0)
        layout.addWidget(self.x_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Y"), 0, 2)
        layout.addWidget(self.y_input, 0, 3)
        layout.addWidget(QtWidgets.QLabel("Z"), 1, 0)
        layout.addWidget(self.z_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("Tool angle ψ"), 1, 2)
        layout.addWidget(self.psi_input, 1, 3)
        layout.addWidget(self.elbow_up, 2, 0, 1, 2)
        layout.addWidget(self.elbow_down, 2, 2, 1, 2)
        layout.addWidget(self.side_a, 3, 0, 1, 2)
        layout.addWidget(self.side_b, 3, 2, 1, 2)
        layout.addLayout(preset_row, 4, 0, 1, 4)
        layout.addWidget(solve_btn, 5, 0, 1, 4)
        layout.addWidget(self.ik_status, 6, 0, 1, 4)

        return box

    def _build_calibration_panel(self):
        box = QtWidgets.QGroupBox("Home Offset Calibration (plan §5.4)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.offset_inputs = []
        offsets = load_home_offsets()
        for i, name in enumerate(AXIS_LABELS):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-360, 360)
            spin.setDecimals(2)
            spin.setValue(offsets[i])
            spin.setMinimumWidth(90)
            spin.setMinimumHeight(28)
            label = QtWidgets.QLabel(name)
            label.setMinimumWidth(140)
            layout.addWidget(label, i, 0)
            layout.addWidget(spin, i, 1)
            self.offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offsets")
        save_btn.setMinimumHeight(30)
        save_btn.clicked.connect(self._on_save_offsets)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_offsets)
        layout.addWidget(save_btn, len(AXIS_LABELS), 0)
        layout.addWidget(reload_btn, len(AXIS_LABELS), 1)

        note = QtWidgets.QLabel(
            "Not yet measured on physical hardware (open item). Jog each joint to a\n"
            "known reference pose on the real arm, read the DH-solved angle above,\n"
            "and enter the difference here."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, len(AXIS_LABELS) + 1, 0, 1, 2)

        return box

    def _build_tool_offset_panel(self):
        box = QtWidgets.QGroupBox("Tool Offset — marker tip vs. wrist (mm)")
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        offset = load_tool_offset()
        self.tool_offset_inputs = []
        labels = ["dx (out along reach)", "dy (sideways)", "dz (up/down)"]
        for i, lbl in enumerate(labels):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-500, 500)
            spin.setDecimals(1)
            spin.setSuffix(" mm")
            spin.setValue(offset[i])
            spin.setMinimumHeight(28)
            spin.valueChanged.connect(self._on_tool_offset_changed)
            label = QtWidgets.QLabel(lbl)
            label.setMinimumWidth(150)
            layout.addWidget(label, i, 0)
            layout.addWidget(spin, i, 1)
            self.tool_offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offset")
        save_btn.setMinimumHeight(30)
        save_btn.clicked.connect(self._on_save_tool_offset)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_tool_offset)
        layout.addWidget(save_btn, 3, 0)
        layout.addWidget(reload_btn, 3, 1)

        note = QtWidgets.QLabel(
            "Rigid offset from the wrist frame to the actual tool tip. IK now solves "
            "for the TRUE TOOL TIP position here (Layer 2) — a typed XYZ target puts "
            "the actual marker/gripper tip there, not the wrist. A nonzero 'sideways' "
            "(dy) offset adds a 'Side A/B' choice in the IK panel (like elbow up/down, "
            "but for the base) since the tool no longer sits in the arm's own vertical "
            "plane. Measure dx/dy/dz from the wrist's center of rotation to the tool "
            "tip with the wrist at θ4=0."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, 4, 0, 1, 2)

        return box

    def _current_tool_offset(self):
        return [s.value() for s in self.tool_offset_inputs]

    def _on_tool_offset_changed(self):
        self.canvas.plot_pose(self.current_thetas, target_xyz=self.last_target_xyz,
                              tool_offset=self._current_tool_offset())

    def _on_save_tool_offset(self):
        save_tool_offset(self._current_tool_offset())
        self._log(f"Saved tool offset {self._current_tool_offset()} mm to disk.")

    def _on_reload_tool_offset(self):
        offset = load_tool_offset()
        for spin, v in zip(self.tool_offset_inputs, offset):
            spin.blockSignals(True)
            spin.setValue(v)
            spin.blockSignals(False)
        self._on_tool_offset_changed()
        self._log(f"Reloaded tool offset {offset} mm from disk.")

    # -- waypoint path tab -------------------------------------------------

    def _build_waypoint_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        table_box = QtWidgets.QGroupBox("Waypoints (X, Y, Z mm; ψ deg)")
        table_layout = QtWidgets.QVBoxLayout(table_box)
        self.wp_table = QtWidgets.QTableWidget(0, 4)
        self.wp_table.setHorizontalHeaderLabels(["X", "Y", "Z", "ψ"])
        self.wp_table.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.Stretch)
        self.wp_table.setMinimumHeight(160)
        table_layout.addWidget(self.wp_table)

        row_btns = QtWidgets.QHBoxLayout()
        add_btn = QtWidgets.QPushButton("Add row")
        add_btn.clicked.connect(self._on_wp_add_row)
        add_current_btn = QtWidgets.QPushButton("Add current pose")
        add_current_btn.setToolTip("Adds the current target-pose X/Y/Z/ψ from the Single Pose tab.")
        add_current_btn.clicked.connect(self._on_wp_add_current)
        del_btn = QtWidgets.QPushButton("Delete row")
        del_btn.clicked.connect(self._on_wp_delete_row)
        clear_btn = QtWidgets.QPushButton("Clear")
        clear_btn.clicked.connect(lambda: self.wp_table.setRowCount(0))
        for b in (add_btn, add_current_btn, del_btn, clear_btn):
            b.setMinimumHeight(28)
            row_btns.addWidget(b)
        table_layout.addLayout(row_btns)
        col.addWidget(table_box)

        gen_box = QtWidgets.QGroupBox("Generate a path")
        gen_layout = QtWidgets.QGridLayout(gen_box)
        gen_layout.setHorizontalSpacing(10)
        gen_layout.setVerticalSpacing(8)

        line_btn = QtWidgets.QPushButton("Line sweep")
        line_btn.setToolTip("Straight line from the first waypoint to the last one in the table.")
        line_btn.setMinimumHeight(28)
        line_btn.clicked.connect(self._on_gen_line)

        circle_btn = QtWidgets.QPushButton("Circle")
        circle_btn.setToolTip("Circle centered on the first waypoint in the table, in the chosen plane.")
        circle_btn.setMinimumHeight(28)
        circle_btn.clicked.connect(self._on_gen_circle)

        self.circle_radius = QtWidgets.QDoubleSpinBox()
        self.circle_radius.setRange(1, 500)
        self.circle_radius.setValue(40)
        self.circle_radius.setSuffix(" mm")
        self.circle_radius.setMinimumHeight(28)

        self.circle_plane = QtWidgets.QComboBox()
        self.circle_plane.addItems(["xy", "xz", "yz"])
        self.circle_plane.setCurrentText("xz")
        self.circle_plane.setMinimumHeight(28)

        gen_layout.addWidget(line_btn, 0, 0)
        gen_layout.addWidget(QtWidgets.QLabel("(uses first + last waypoint)"), 0, 1, 1, 3)
        gen_layout.addWidget(circle_btn, 1, 0)
        gen_layout.addWidget(QtWidgets.QLabel("r"), 1, 1)
        gen_layout.addWidget(self.circle_radius, 1, 2)
        gen_layout.addWidget(self.circle_plane, 1, 3)
        col.addWidget(gen_box)

        run_box = QtWidgets.QGroupBox("Plan & run")
        run_layout = QtWidgets.QGridLayout(run_box)
        run_layout.setHorizontalSpacing(10)
        run_layout.setVerticalSpacing(8)

        self.wp_auto_psi = QtWidgets.QCheckBox("Auto-adjust ψ into joint limits per point")
        self.wp_auto_psi.setChecked(True)

        self.wp_elbow = QtWidgets.QComboBox()
        self.wp_elbow.addItems(["up", "down"])

        self.wp_side = QtWidgets.QComboBox()
        self.wp_side.addItems(["A", "B"])
        self.wp_side.setToolTip(
            "Only matters with a nonzero lateral tool offset. 'A' is the direct base "
            "angle; 'B' reaches around from the opposite side (only valid near the base axis)."
        )

        self.wp_segment = QtWidgets.QDoubleSpinBox()
        self.wp_segment.setRange(0.5, 50)
        self.wp_segment.setValue(5.0)
        self.wp_segment.setSuffix(" mm/seg")
        self.wp_segment.setToolTip(
            "Max segment length. Smaller = smoother motion (grbl blends short "
            "moves) but more commands to stream.")

        self.wp_feed = QtWidgets.QDoubleSpinBox()
        self.wp_feed.setRange(1, 20000)
        self.wp_feed.setValue(SAFE_FEED_DEG_PER_MIN)
        self.wp_feed.setSuffix(" deg/min")

        for w in (self.wp_elbow, self.wp_side, self.wp_segment, self.wp_feed):
            w.setMinimumHeight(28)

        simulate_btn = QtWidgets.QPushButton("Simulate (no hardware)")
        simulate_btn.setMinimumHeight(32)
        simulate_btn.clicked.connect(self._on_wp_simulate)

        self.wp_run_btn = _style_button(QtWidgets.QPushButton("Run on Arm"), "primary")
        self.wp_run_btn.setMinimumHeight(32)
        self.wp_run_btn.clicked.connect(self._on_wp_run)

        self.wp_abort_btn = _style_button(QtWidgets.QPushButton("Stop (feed hold)"), "danger")
        self.wp_abort_btn.setMinimumHeight(32)
        self.wp_abort_btn.setEnabled(False)
        self.wp_abort_btn.clicked.connect(self._on_wp_abort)

        self.wp_progress = QtWidgets.QProgressBar()
        self.wp_status = QtWidgets.QLabel("")
        self.wp_status.setWordWrap(True)
        self.wp_status.setMinimumHeight(40)

        run_layout.addWidget(self.wp_auto_psi, 0, 0, 1, 4)
        run_layout.addWidget(QtWidgets.QLabel("Elbow"), 1, 0)
        run_layout.addWidget(self.wp_elbow, 1, 1)
        run_layout.addWidget(QtWidgets.QLabel("Side"), 1, 2)
        run_layout.addWidget(self.wp_side, 1, 3)
        run_layout.addWidget(self.wp_segment, 2, 0)
        run_layout.addWidget(self.wp_feed, 2, 1)
        run_layout.addWidget(simulate_btn, 3, 0, 1, 2)
        run_layout.addWidget(self.wp_run_btn, 3, 2)
        run_layout.addWidget(self.wp_abort_btn, 3, 3)
        run_layout.addWidget(self.wp_progress, 4, 0, 1, 4)
        run_layout.addWidget(self.wp_status, 5, 0, 1, 4)
        col.addWidget(run_box)

        col.addStretch(1)

        self._wp_plan = None
        self._wp_worker = None
        return tab

    def _read_waypoints(self):
        poses = []
        for r in range(self.wp_table.rowCount()):
            vals = []
            for c in range(4):
                item = self.wp_table.item(r, c)
                if item is None or not item.text().strip():
                    raise ValueError(f"Row {r + 1} has an empty cell.")
                vals.append(float(item.text()))
            poses.append(tuple(vals))
        return poses

    def _set_waypoints(self, poses):
        self.wp_table.setRowCount(len(poses))
        for r, (x, y, z, psi) in enumerate(poses):
            for c, v in enumerate((x, y, z, psi)):
                self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_add_row(self):
        r = self.wp_table.rowCount()
        self.wp_table.insertRow(r)
        for c, v in enumerate((250.0, 0.0, 300.0, 0.0)):
            self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_add_current(self):
        r = self.wp_table.rowCount()
        self.wp_table.insertRow(r)
        vals = (self.x_input.value(), self.y_input.value(),
                self.z_input.value(), self.psi_input.value())
        for c, v in enumerate(vals):
            self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_delete_row(self):
        r = self.wp_table.currentRow()
        if r >= 0:
            self.wp_table.removeRow(r)

    def _on_gen_line(self):
        try:
            poses = self._read_waypoints()
        except ValueError as e:
            self._wp_set_status(str(e), error=True)
            return
        if len(poses) < 2:
            self._wp_set_status("Need at least 2 waypoints (start + end) for a line sweep.", error=True)
            return
        start = poses[0][:3]
        end = poses[-1][:3]
        psi = poses[0][3]
        self._set_waypoints(line_sweep(start, end, psi, num_waypoints=2))
        self._wp_set_status("Generated a line sweep from the first to the last waypoint.")

    def _on_gen_circle(self):
        try:
            poses = self._read_waypoints()
        except ValueError as e:
            self._wp_set_status(str(e), error=True)
            return
        if not poses:
            self._wp_set_status("Add at least one waypoint to use as the circle center.", error=True)
            return
        center = poses[0][:3]
        psi = poses[0][3]
        circle = circle_path(center, self.circle_radius.value(), psi,
                             plane=self.circle_plane.currentText(), num_waypoints=48)
        self._set_waypoints(circle)
        self._wp_set_status(
            f"Generated a {self.circle_plane.currentText()} circle of r="
            f"{self.circle_radius.value():.0f}mm around the first waypoint.")

    def _plan_current_path(self):
        poses = self._read_waypoints()
        if len(poses) < 2:
            raise ValueError("Need at least 2 waypoints to run a path.")
        return plan_waypoint_path(
            poses,
            prefer_elbow=self.wp_elbow.currentText(),
            prefer_side=self.wp_side.currentText(),
            max_segment_mm=self.wp_segment.value(),
            auto_psi=self.wp_auto_psi.isChecked(),
        )

    def _on_wp_simulate(self):
        try:
            plan = self._plan_current_path()
        except (ValueError, PathPlanningError) as e:
            self._wp_set_status(str(e), error=True)
            return

        self._wp_plan = plan
        path_xyz = [p[:3] for p in plan["dense_poses"]]
        self._wp_set_status(
            f"Planned {len(plan['thetas'])} points, all within joint limits. "
            "Animating in the 3D view (no hardware commands sent).")

        self._sim_index = 0
        self._sim_thetas = plan["thetas"]
        self._sim_path = path_xyz
        if not hasattr(self, "_sim_timer"):
            self._sim_timer = QtCore.QTimer(self)
            self._sim_timer.timeout.connect(self._sim_step)
        self._sim_timer.start(40)

    def _sim_step(self):
        if self._sim_index >= len(self._sim_thetas):
            self._sim_timer.stop()
            return
        thetas = self._sim_thetas[self._sim_index]
        self.canvas.plot_pose(thetas, path_xyz=self._sim_path)
        self._sim_index += 1

    def _on_wp_run(self):
        if not self.bridge.is_connected():
            self._wp_set_status("Not connected to the arm. Connect in the Serial Bridge panel first.", error=True)
            return
        try:
            plan = self._plan_current_path()
        except (ValueError, PathPlanningError) as e:
            self._wp_set_status(str(e), error=True)
            return

        feed = self.wp_feed.value()
        # Clear position tracking so the FIRST segment's coordinated feed is
        # computed conservatively rather than against a stale leftover pose.
        self.bridge.last_motor_angles = None
        lines = []
        for thetas in plan["thetas"]:
            motor = apply_home_offset(thetas)
            lines.append(self.bridge.build_move_gcode(
                motor, feed_deg_per_min=feed,
                per_axis_max_deg_per_min=self._active_axis_speed_limits()))

        self._wp_plan = plan
        self.wp_progress.setMaximum(len(lines))
        self.wp_progress.setValue(0)
        self._wp_set_status(f"Streaming {len(lines)} moves to the arm…")

        self.wp_run_btn.setEnabled(False)
        self.wp_abort_btn.setEnabled(True)

        self._wp_worker = PathStreamWorker(self.bridge, lines, feed)
        self._wp_worker.progress.connect(self._on_wp_progress)
        self._wp_worker.finished_streaming.connect(self._on_wp_finished)
        self._wp_worker.error.connect(self._on_wp_error)
        self._wp_worker.start()

    def _on_wp_progress(self, index, total):
        self.wp_progress.setValue(index)

    def _on_wp_finished(self, sent, aborted):
        self.wp_run_btn.setEnabled(True)
        self.wp_abort_btn.setEnabled(False)
        if aborted:
            self._wp_set_status(
                f"Aborted after {sent} moves (feed-hold sent). Send Resume (~) or "
                "Soft Reset from the Serial Bridge panel to clear the hold.", error=True)
        else:
            self._wp_set_status(f"Path complete — {sent} moves sent.")

    def _on_wp_error(self, msg):
        self.wp_run_btn.setEnabled(True)
        self.wp_abort_btn.setEnabled(False)
        self._wp_set_status(f"Streaming error: {msg}", error=True)

    def _on_wp_abort(self):
        if self._wp_worker is not None and self._wp_worker.isRunning():
            self._wp_worker.request_abort()
            self._wp_set_status("Abort requested — sending feed-hold…", error=True)

    def _wp_set_status(self, text, error=False):
        self.wp_status.setText(text)
        self.wp_status.setStyleSheet("color: red;" if error else "color: green;")

    # -- text writing tab --------------------------------------------------

    def _build_writing_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        # --- text + layout ---
        text_box = QtWidgets.QGroupBox("Text")
        tl = QtWidgets.QGridLayout(text_box)
        tl.setHorizontalSpacing(10)
        tl.setVerticalSpacing(8)
        tl.setContentsMargins(12, 16, 12, 12)

        self.write_text = QtWidgets.QLineEdit("HELLO")
        self.write_text.setMinimumHeight(30)
        self.write_text.setToolTip("A-Z, 0-9, space and basic punctuation. Lowercase is drawn as uppercase.")

        self.write_height = QtWidgets.QDoubleSpinBox()
        self.write_height.setRange(5, 200)
        self.write_height.setValue(30)
        self.write_height.setSuffix(" mm tall")

        self.write_letter_spacing = QtWidgets.QDoubleSpinBox()
        self.write_letter_spacing.setRange(0, 50)
        self.write_letter_spacing.setValue(4)
        self.write_letter_spacing.setSuffix(" mm gap")

        for w in (self.write_height, self.write_letter_spacing):
            w.setMinimumHeight(28)

        tl.addWidget(QtWidgets.QLabel("Word/phrase"), 0, 0)
        tl.addWidget(self.write_text, 0, 1, 1, 3)
        tl.addWidget(QtWidgets.QLabel("Height"), 1, 0)
        tl.addWidget(self.write_height, 1, 1)
        tl.addWidget(QtWidgets.QLabel("Letter gap"), 1, 2)
        tl.addWidget(self.write_letter_spacing, 1, 3)
        col.addWidget(text_box)

        # --- plane placement ---
        place_box = QtWidgets.QGroupBox("Placement on the table (horizontal plane)")
        pl = QtWidgets.QGridLayout(place_box)
        pl.setHorizontalSpacing(10)
        pl.setVerticalSpacing(8)
        pl.setContentsMargins(12, 16, 12, 12)

        self.write_base_x = QtWidgets.QDoubleSpinBox()
        self.write_base_x.setRange(50, 600)
        self.write_base_x.setValue(240)
        self.write_base_x.setSuffix(" mm out")
        self.write_base_x.setToolTip("Reach distance from the base to where the text starts (along X).")

        self.write_center = QtWidgets.QCheckBox("Center left-right")
        self.write_center.setChecked(True)
        self.write_center.setToolTip("Center the word on Y=0 rather than starting at Y=0.")

        self.write_pen_down_z = QtWidgets.QDoubleSpinBox()
        self.write_pen_down_z.setRange(0, 500)
        self.write_pen_down_z.setValue(150)
        self.write_pen_down_z.setSuffix(" mm (paper Z)")
        self.write_pen_down_z.setToolTip(
            "Height of the writing surface — the Z where the marker touches paper. "
            "Adjustable so you can raise/lower the writing plane within the arm's reach.")

        self.write_pen_lift = QtWidgets.QDoubleSpinBox()
        self.write_pen_lift.setRange(2, 100)
        self.write_pen_lift.setValue(20)
        self.write_pen_lift.setSuffix(" mm lift")
        self.write_pen_lift.setToolTip("How far above the paper the marker lifts when travelling between strokes.")

        self.write_max_tilt = QtWidgets.QDoubleSpinBox()
        self.write_max_tilt.setRange(0, 45)
        self.write_max_tilt.setValue(15)
        self.write_max_tilt.setSuffix(" deg tilt")
        self.write_max_tilt.setToolTip(
            "Allowed marker tilt from straight-down. 0 = strictly vertical (cleanest, but "
            "hardest to reach). A few degrees greatly enlarges the writable area and is "
            "visually fine.")

        for w in (self.write_base_x, self.write_pen_down_z, self.write_pen_lift, self.write_max_tilt):
            w.setMinimumHeight(28)

        pl.addWidget(QtWidgets.QLabel("Reach (X)"), 0, 0)
        pl.addWidget(self.write_base_x, 0, 1)
        pl.addWidget(self.write_center, 0, 2, 1, 2)
        pl.addWidget(QtWidgets.QLabel("Paper height"), 1, 0)
        pl.addWidget(self.write_pen_down_z, 1, 1)
        pl.addWidget(QtWidgets.QLabel("Pen lift"), 1, 2)
        pl.addWidget(self.write_pen_lift, 1, 3)
        pl.addWidget(QtWidgets.QLabel("Max tilt"), 2, 0)
        pl.addWidget(self.write_max_tilt, 2, 1)
        col.addWidget(place_box)

        # --- run controls ---
        run_box = QtWidgets.QGroupBox("Plan & write")
        rl = QtWidgets.QGridLayout(run_box)
        rl.setHorizontalSpacing(10)
        rl.setVerticalSpacing(8)
        rl.setContentsMargins(12, 16, 12, 12)

        self.write_feed = QtWidgets.QDoubleSpinBox()
        self.write_feed.setRange(1, 20000)
        self.write_feed.setValue(SAFE_FEED_DEG_PER_MIN)
        self.write_feed.setSuffix(" deg/min")
        self.write_feed.setMinimumHeight(28)

        self.write_segment = QtWidgets.QDoubleSpinBox()
        self.write_segment.setRange(0.5, 20)
        self.write_segment.setValue(4.0)
        self.write_segment.setSuffix(" mm/seg")
        self.write_segment.setMinimumHeight(28)
        self.write_segment.setToolTip("Smaller = smoother curves but more commands.")

        preview_btn = QtWidgets.QPushButton("Preview strokes (2D)")
        preview_btn.setMinimumHeight(30)
        preview_btn.clicked.connect(self._on_write_preview)

        simulate_btn = QtWidgets.QPushButton("Simulate (3D, no hardware)")
        simulate_btn.setMinimumHeight(32)
        simulate_btn.clicked.connect(self._on_write_simulate)

        self.write_run_btn = _style_button(QtWidgets.QPushButton("Write on Arm"), "primary")
        self.write_run_btn.setMinimumHeight(32)
        self.write_run_btn.clicked.connect(self._on_write_run)

        self.write_abort_btn = _style_button(QtWidgets.QPushButton("Stop (feed hold)"), "danger")
        self.write_abort_btn.setMinimumHeight(32)
        self.write_abort_btn.setEnabled(False)
        self.write_abort_btn.clicked.connect(self._on_write_abort)

        self.write_progress = QtWidgets.QProgressBar()
        self.write_status = QtWidgets.QLabel("")
        self.write_status.setWordWrap(True)
        self.write_status.setMinimumHeight(48)

        rl.addWidget(QtWidgets.QLabel("Feed"), 0, 0)
        rl.addWidget(self.write_feed, 0, 1)
        rl.addWidget(QtWidgets.QLabel("Segment"), 0, 2)
        rl.addWidget(self.write_segment, 0, 3)
        rl.addWidget(preview_btn, 1, 0, 1, 2)
        rl.addWidget(simulate_btn, 1, 2, 1, 2)
        rl.addWidget(self.write_run_btn, 2, 0, 1, 2)
        rl.addWidget(self.write_abort_btn, 2, 2, 1, 2)
        rl.addWidget(self.write_progress, 3, 0, 1, 4)
        rl.addWidget(self.write_status, 4, 0, 1, 4)

        note = QtWidgets.QLabel(
            "Writes with a single-stroke font, marker pointing ~straight down, on a flat "
            "surface at the 'paper height' Z. The pen lifts between strokes automatically. "
            "The 50.5mm tool offset is accounted for (Layer 2 IK), so the marker tip lands "
            "where planned. Reachability is fully validated before any motion — if the word "
            "doesn't fit, it says which point failed. Writing quality on real hardware "
            "depends on Z-calibration and a compliant marker mount."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        rl.addWidget(note, 5, 0, 1, 4)
        col.addWidget(run_box)

        col.addStretch(1)

        self._write_worker = None
        return tab

    def _build_write_pen_path(self):
        """Build the (x,y,z,psi) pen path from the current writing controls."""
        text = self.write_text.text()
        if not text.strip():
            raise ValueError("Enter a word or phrase to write.")
        height = self.write_height.value()
        strokes, width, _ = text_to_strokes(
            text, height_mm=height, letter_spacing_mm=self.write_letter_spacing.value())
        if not strokes:
            raise ValueError("Nothing to draw (only spaces / unsupported characters).")
        base_y = -width / 2.0 if self.write_center.isChecked() else 0.0
        pen_down_z = self.write_pen_down_z.value()
        pen_up_z = pen_down_z + self.write_pen_lift.value()
        pen_path = strokes_to_pen_path(
            strokes, base_x=self.write_base_x.value(), base_y=base_y,
            pen_down_z=pen_down_z, pen_up_z=pen_up_z, psi_deg=-90.0)
        return pen_path, strokes, width

    def _plan_write(self):
        """Densify + IK-solve the current writing path with clamped tilt. Returns
        (thetas_list, dense_poses, psi_used) or raises."""
        pen_path, _, _ = self._build_write_pen_path()
        return plan_writing_path(
            pen_path,
            solve_fn=lambda x, y, z, psi: solve_ik_constrained(x, y, z, psi),
            interpolate_fn=_interpolate_poses,
            max_tilt_deg=self.write_max_tilt.value(),
            max_segment_mm=self.write_segment.value())

    def _on_write_preview(self):
        try:
            _, strokes, width = self._build_write_pen_path()
        except ValueError as e:
            self._write_set_status(str(e), error=True)
            return
        # Draw the flat 2D strokes into the 3D canvas at the paper plane, as a preview.
        pen_down_z = self.write_pen_down_z.value()
        base_x = self.write_base_x.value()
        base_y = -width / 2.0 if self.write_center.isChecked() else 0.0
        path_xyz = []
        for st in strokes:
            for (u, v) in st:
                path_xyz.append((base_x + u, base_y + v, pen_down_z))
        self.canvas.plot_pose(self.current_thetas, path_xyz=path_xyz)
        self._write_set_status(
            f"Preview: '{self.write_text.text()}' = {len(strokes)} strokes, "
            f"{width:.0f}mm wide. (2D layout on the paper plane; not yet reach-checked — "
            "use Simulate for that.)")

    def _on_write_simulate(self):
        try:
            thetas_list, dense, psi_used = self._plan_write()
        except (ValueError, WritingPlanError) as e:
            self._write_set_status(str(e), error=True)
            return

        path_xyz = [p[:3] for p in dense]
        self._write_set_status(
            f"Planned {len(thetas_list)} points, all reachable within joint limits "
            f"(marker tilt stayed within {self.write_max_tilt.value():.0f} deg of vertical). "
            "Animating — no hardware commands sent.")

        self._write_sim_index = 0
        self._write_sim_thetas = thetas_list
        self._write_sim_path = path_xyz
        if not hasattr(self, "_write_sim_timer"):
            self._write_sim_timer = QtCore.QTimer(self)
            self._write_sim_timer.timeout.connect(self._write_sim_step)
        self._write_sim_timer.start(30)

    def _write_sim_step(self):
        if self._write_sim_index >= len(self._write_sim_thetas):
            self._write_sim_timer.stop()
            return
        thetas = self._write_sim_thetas[self._write_sim_index]
        self.canvas.plot_pose(thetas, path_xyz=self._write_sim_path)
        self._write_sim_index += 1

    def _on_write_run(self):
        if not self.bridge.is_connected():
            self._write_set_status("Not connected. Connect to the arm in the Serial Bridge panel first.", error=True)
            return
        try:
            thetas_list, dense, psi_used = self._plan_write()
        except (ValueError, WritingPlanError) as e:
            self._write_set_status(str(e), error=True)
            return

        feed = self.write_feed.value()
        self.bridge.last_motor_angles = None   # see note in _on_wp_run
        lines = []
        for thetas in thetas_list:
            motor = apply_home_offset(thetas)
            lines.append(self.bridge.build_move_gcode(
                motor, feed_deg_per_min=feed,
                per_axis_max_deg_per_min=self._active_axis_speed_limits()))

        self.write_progress.setMaximum(len(lines))
        self.write_progress.setValue(0)
        self._write_set_status(f"Writing '{self.write_text.text()}' — streaming {len(lines)} moves…")

        self.write_run_btn.setEnabled(False)
        self.write_abort_btn.setEnabled(True)

        self._write_worker = PathStreamWorker(self.bridge, lines, feed)
        self._write_worker.progress.connect(lambda i, t: self.write_progress.setValue(i))
        self._write_worker.finished_streaming.connect(self._on_write_finished)
        self._write_worker.error.connect(self._on_write_error)
        self._write_worker.start()

    def _on_write_finished(self, sent, aborted):
        self.write_run_btn.setEnabled(True)
        self.write_abort_btn.setEnabled(False)
        if aborted:
            self._write_set_status(
                f"Aborted after {sent} moves (feed-hold sent). Send Resume (~) or Soft Reset "
                "from the Serial Bridge panel to clear the hold.", error=True)
        else:
            self._write_set_status(f"Done — wrote '{self.write_text.text()}' ({sent} moves).")

    def _on_write_error(self, msg):
        self.write_run_btn.setEnabled(True)
        self.write_abort_btn.setEnabled(False)
        self._write_set_status(f"Streaming error: {msg}", error=True)

    def _on_write_abort(self):
        if self._write_worker is not None and self._write_worker.isRunning():
            self._write_worker.request_abort()
            self._write_set_status("Abort requested — sending feed-hold…", error=True)

    def _write_set_status(self, text, error=False):
        self.write_status.setText(text)
        self.write_status.setStyleSheet("color: red;" if error else "color: green;")


    # -- motion tuning tab -------------------------------------------------

    def _build_motion_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        profile = load_motion_profile()
        self._motion_profile = profile

        # --- per-axis grid ---
        grid_box = QtWidgets.QGroupBox("Per-joint motion limits")
        gl = QtWidgets.QGridLayout(grid_box)
        gl.setHorizontalSpacing(10)
        gl.setVerticalSpacing(8)
        gl.setContentsMargins(12, 16, 12, 12)

        headers = ["Joint", "Max speed", "Acceleration", "Steps per degree"]
        for c, h in enumerate(headers):
            lbl = QtWidgets.QLabel(h)
            lbl.setStyleSheet("font-weight: 600; color: #3a4658;")
            gl.addWidget(lbl, 0, c)

        self.motion_inputs = {"max_speed_deg_per_min": [],
                              "accel_deg_per_sec2": [],
                              "steps_per_deg": []}

        joint_names = ["Base (36:1)", "Shoulder (36:1)", "Elbow (36:1)", "Wrist (6:1)"]
        for i, name in enumerate(joint_names):
            row = i + 1
            name_lbl = QtWidgets.QLabel(name)
            name_lbl.setMinimumWidth(120)
            gl.addWidget(name_lbl, row, 0)

            speed = QtWidgets.QDoubleSpinBox()
            speed.setRange(1, 60000)
            speed.setDecimals(0)
            speed.setSuffix(" deg/min")
            speed.setValue(profile["max_speed_deg_per_min"][i])
            speed.setMinimumHeight(28)
            speed.setToolTip(
                "Hard speed ceiling for this joint. Pushed to grbl as "
                f"{GRBL_MAX_RATE_SETTINGS[i]}, and used by the app to work out a "
                "coordinated feed that keeps every joint under its own limit.")
            gl.addWidget(speed, row, 1)
            self.motion_inputs["max_speed_deg_per_min"].append(speed)

            accel = QtWidgets.QDoubleSpinBox()
            accel.setRange(0.1, 10000)
            accel.setDecimals(1)
            accel.setSuffix(" deg/s²")
            accel.setValue(profile["accel_deg_per_sec2"][i])
            accel.setMinimumHeight(28)
            accel.setToolTip(
                f"Acceleration for this joint (grbl {GRBL_ACCEL_SETTINGS[i]}). "
                "Higher values ramp through a resonance band quickly instead of "
                "dwelling in it — often the fix for a joint that's rough at low speed.")
            gl.addWidget(accel, row, 2)
            self.motion_inputs["accel_deg_per_sec2"].append(accel)

            steps = QtWidgets.QDoubleSpinBox()
            steps.setRange(0.001, 10000)
            steps.setDecimals(4)
            steps.setValue(profile["steps_per_deg"][i])
            steps.setMinimumHeight(28)
            steps.setToolTip(
                f"Steps per output degree (grbl {GRBL_SETTING_NUMBERS[i]}). "
                "Only change this if you alter that axis's microstepping jumpers — "
                "and if you do, the jumpers and this number must agree or every "
                "move on this joint will be wrong by that factor.")
            gl.addWidget(steps, row, 3)
            self.motion_inputs["steps_per_deg"].append(steps)

        col.addWidget(grid_box)

        # --- microstepping helper ---
        micro_box = QtWidgets.QGroupBox("Microstepping helper")
        ml = QtWidgets.QGridLayout(micro_box)
        ml.setHorizontalSpacing(10)
        ml.setVerticalSpacing(8)
        ml.setContentsMargins(12, 16, 12, 12)

        self.micro_joint = QtWidgets.QComboBox()
        self.micro_joint.addItems(joint_names)
        self.micro_joint.setMinimumHeight(28)

        self.micro_mode = QtWidgets.QComboBox()
        self.micro_mode.addItems(["Full step", "1/2", "1/4", "1/8", "1/16", "1/32"])
        self.micro_mode.setMinimumHeight(28)
        self.micro_mode.setToolTip(
            "Sets that joint's steps/degree to match the chosen microstepping. "
            "You must also set the driver's physical jumpers to match.")

        apply_micro = QtWidgets.QPushButton("Set steps/deg for this microstepping")
        apply_micro.setMinimumHeight(30)
        apply_micro.clicked.connect(self._on_apply_microstepping)

        ml.addWidget(QtWidgets.QLabel("Joint"), 0, 0)
        ml.addWidget(self.micro_joint, 0, 1)
        ml.addWidget(QtWidgets.QLabel("Mode"), 0, 2)
        ml.addWidget(self.micro_mode, 0, 3)
        ml.addWidget(apply_micro, 1, 0, 1, 4)

        micro_note = QtWidgets.QLabel(
            "Microstepping is the most effective fix for a joint that feels like it's "
            "slamming into each step. It subdivides every full step so the rotor eases "
            "between positions instead of being flung there. Remember to install the "
            "matching MODE jumpers under that driver socket — this button only updates "
            "the number, it can't move the jumpers for you."
        )
        micro_note.setWordWrap(True)
        micro_note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        ml.addWidget(micro_note, 2, 0, 1, 4)
        col.addWidget(micro_box)

        # --- actions ---
        act_box = QtWidgets.QGroupBox("Apply")
        al = QtWidgets.QGridLayout(act_box)
        al.setHorizontalSpacing(10)
        al.setVerticalSpacing(8)
        al.setContentsMargins(12, 16, 12, 12)

        save_btn = QtWidgets.QPushButton("Save profile")
        save_btn.setMinimumHeight(30)
        save_btn.setToolTip("Save these values to motion_profile.json so they persist between runs.")
        save_btn.clicked.connect(self._on_save_motion_profile)

        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_motion_profile)

        push_btn = _style_button(QtWidgets.QPushButton("Push to arm (write to EEPROM)"), "primary")
        push_btn.setMinimumHeight(32)
        push_btn.setToolTip(
            "Write $100-$103 (steps/deg), $110-$113 (max rate) and $120-$123 "
            "(acceleration) into the board's EEPROM. Persists across power cycles.")
        push_btn.clicked.connect(self._on_push_motion_profile)

        read_btn = QtWidgets.QPushButton("Read current settings ($$)")
        read_btn.setMinimumHeight(30)
        read_btn.setToolTip("Dump the board's current settings into the log so you can compare.")
        read_btn.clicked.connect(self._on_read_grbl_settings)

        self.motion_status = QtWidgets.QLabel("")
        self.motion_status.setWordWrap(True)
        self.motion_status.setMinimumHeight(40)

        al.addWidget(save_btn, 0, 0)
        al.addWidget(reload_btn, 0, 1)
        al.addWidget(read_btn, 1, 0)
        al.addWidget(push_btn, 1, 1)
        al.addWidget(self.motion_status, 2, 0, 1, 2)

        note = QtWidgets.QLabel(
            "G-code's F is one coordinated feed for the whole move, not a per-axis value — "
            "so per-joint speed is enforced two ways. grbl's $110-$113 are hard ceilings in "
            "firmware (push them here), and the app separately works out the fastest F that "
            "keeps every joint under its own limit for each move. If $110-$113 are left lower "
            "than the feed the app asks for, grbl silently clamps every move to them, so "
            "pushing this profile is what makes these numbers real on the hardware."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        al.addWidget(note, 3, 0, 1, 2)
        col.addWidget(act_box)

        col.addStretch(1)
        return tab

    def _current_motion_profile(self):
        return {key: [w.value() for w in widgets]
                for key, widgets in self.motion_inputs.items()}

    def _on_apply_microstepping(self):
        i = self.micro_joint.currentIndex()
        divisor = [1, 2, 4, 8, 16, 32][self.micro_mode.currentIndex()]
        base_steps = GRBL_STEPS_PER_DEGREE[i]   # full-step value for this joint
        new_val = base_steps * divisor
        self.motion_inputs["steps_per_deg"][i].setValue(new_val)
        self._motion_set_status(
            f"{self.micro_joint.currentText()} steps/degree set to {new_val:.4f} "
            f"for {self.micro_mode.currentText()} microstepping. Set the driver's MODE "
            "jumpers to match, then push to the arm.")

    def _on_save_motion_profile(self):
        profile = self._current_motion_profile()
        save_motion_profile(profile)
        self._motion_profile = profile
        self._motion_set_status("Motion profile saved to motion_profile.json.")
        self._log("Saved per-axis motion profile to disk.")

    def _on_reload_motion_profile(self):
        profile = load_motion_profile()
        for key, widgets in self.motion_inputs.items():
            for w, v in zip(widgets, profile[key]):
                w.blockSignals(True)
                w.setValue(v)
                w.blockSignals(False)
        self._motion_profile = profile
        self._motion_set_status("Reloaded motion profile from disk.")

    def _on_push_motion_profile(self):
        if not self.bridge.is_connected():
            self._motion_set_status("Not connected — connect to the arm first.", error=True)
            return
        profile = self._current_motion_profile()
        try:
            results = self.bridge.push_motion_profile(profile)
        except SerialBridgeError as e:
            self._motion_set_status(f"Push failed: {e}", error=True)
            return
        self._motion_profile = profile
        for setting, value, response in results:
            self._log(f"  -> {setting}={value}  {' '.join(response)}")
        self._motion_set_status(
            f"Pushed {len(results)} settings to the board's EEPROM "
            "($100-$103, $110-$113, $120-$123). These persist across power cycles.")

    def _on_read_grbl_settings(self):
        if not self.bridge.is_connected():
            self._motion_set_status("Not connected — connect to the arm first.", error=True)
            return
        try:
            response = self.bridge.send_raw("$$")
        except SerialBridgeError as e:
            self._motion_set_status(f"Read failed: {e}", error=True)
            return
        for line in response:
            self._log(f"  <- {line}")
        self._motion_set_status(
            "Current board settings dumped to the log below — compare $100-$103, "
            "$110-$113 and $120-$123 against the values above.")

    def _motion_set_status(self, text, error=False):
        self.motion_status.setText(text)
        self.motion_status.setStyleSheet("color: #b42318;" if error else "color: #1a7f37;")

    def _active_axis_speed_limits(self):
        """Per-axis max speeds currently set in the Motion Tuning tab, used for
        the coordinated feed calculation on every move the app sends."""
        if hasattr(self, "motion_inputs"):
            return [w.value() for w in self.motion_inputs["max_speed_deg_per_min"]]
        return load_motion_profile()["max_speed_deg_per_min"]

    def _build_serial_panel(self):
        box = QtWidgets.QGroupBox("Arm Connection && Machine Control")
        outer = QtWidgets.QVBoxLayout(box)
        outer.setSpacing(10)
        outer.setContentsMargins(12, 16, 12, 12)

        # --- Row of three sub-groups: Connection | Machine control | Motion defaults ---
        top_row = QtWidgets.QHBoxLayout()
        top_row.setSpacing(12)

        # Connection sub-group
        conn_box = QtWidgets.QGroupBox("Connection")
        conn = QtWidgets.QGridLayout(conn_box)
        conn.setHorizontalSpacing(8)
        conn.setVerticalSpacing(8)

        self.port_combo = QtWidgets.QComboBox()
        self.port_combo.setMinimumHeight(28)
        refresh_btn = QtWidgets.QPushButton("Refresh")
        refresh_btn.setToolTip("Re-scan for available serial ports.")
        refresh_btn.clicked.connect(self._refresh_ports)

        self.baud_input = QtWidgets.QSpinBox()
        self.baud_input.setRange(1200, 921600)
        self.baud_input.setValue(DEFAULT_BAUD)
        self.baud_input.setMinimumHeight(28)

        self.connect_btn = _style_button(QtWidgets.QPushButton("Connect"), "primary")
        self.connect_btn.setMinimumHeight(30)
        self.connect_btn.clicked.connect(self._on_connect_toggle)

        self.conn_status = QtWidgets.QLabel("● Disconnected")
        self.conn_status.setStyleSheet("color: #b42318; font-weight: 600;")

        conn.addWidget(QtWidgets.QLabel("Port"), 0, 0)
        conn.addWidget(self.port_combo, 0, 1)
        conn.addWidget(refresh_btn, 0, 2)
        conn.addWidget(QtWidgets.QLabel("Baud"), 1, 0)
        conn.addWidget(self.baud_input, 1, 1)
        conn.addWidget(self.connect_btn, 1, 2)
        conn.addWidget(self.conn_status, 2, 0, 1, 3)
        top_row.addWidget(conn_box, 2)

        # Machine control sub-group
        mc_box = QtWidgets.QGroupBox("Machine Control")
        mc = QtWidgets.QGridLayout(mc_box)
        mc.setHorizontalSpacing(8)
        mc.setVerticalSpacing(8)

        self.hold_btn = _style_button(QtWidgets.QPushButton("■  Stop (feed hold)"), "danger")
        self.hold_btn.setToolTip("Immediately pause motion (grbl realtime feed-hold '!'). Use as a panic stop.")
        self.hold_btn.clicked.connect(self._on_feed_hold)

        resume_btn = QtWidgets.QPushButton("▶  Resume")
        resume_btn.setToolTip("Resume after a feed-hold (grbl realtime '~').")
        resume_btn.clicked.connect(self._on_resume)

        reset_btn = _style_button(QtWidgets.QPushButton("⟳  Soft reset"), "danger")
        reset_btn.setToolTip("Soft-reset grbl (Ctrl-X). Clears motion state; needed after some alarms.")
        reset_btn.clicked.connect(self._on_soft_reset)

        unlock_btn = QtWidgets.QPushButton("Unlock alarm")
        unlock_btn.setToolTip("Clear a grbl ALARM state so moves are accepted again (sends $X).")
        unlock_btn.clicked.connect(self._on_unlock)

        status_btn = QtWidgets.QPushButton("Query status")
        status_btn.setToolTip("Ask grbl for its current state and position (sends '?').")
        status_btn.clicked.connect(self._on_status)

        setup_btn = QtWidgets.QPushButton("Push steps/mm setup")
        setup_btn.setToolTip("One-time: write the $100-$103 steps-per-unit settings to the board's EEPROM. "
                             "Only needed on a fresh grbl4axis board.")
        setup_btn.clicked.connect(self._on_push_settings)

        for b in (self.hold_btn, resume_btn, reset_btn, unlock_btn, status_btn, setup_btn):
            b.setMinimumHeight(30)
        mc.addWidget(self.hold_btn, 0, 0)
        mc.addWidget(resume_btn, 0, 1)
        mc.addWidget(reset_btn, 0, 2)
        mc.addWidget(unlock_btn, 1, 0)
        mc.addWidget(status_btn, 1, 1)
        mc.addWidget(setup_btn, 1, 2)
        top_row.addWidget(mc_box, 3)

        # Motion defaults sub-group
        md_box = QtWidgets.QGroupBox("Motion Defaults")
        md = QtWidgets.QGridLayout(md_box)
        md.setHorizontalSpacing(8)
        md.setVerticalSpacing(8)

        self.feed_input = QtWidgets.QDoubleSpinBox()
        self.feed_input.setRange(1, 20000)
        self.feed_input.setValue(DEFAULT_FEED_DEG_PER_MIN)
        self.feed_input.setSuffix(" deg/min")
        self.feed_input.setMinimumHeight(28)

        wrist_feed_btn = QtWidgets.QPushButton("Set wrist-safe feed")
        wrist_feed_btn.setToolTip(
            f"Sets feed rate to {WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min — scaled from the "
            f"{SAFE_FEED_DEG_PER_MIN:.0f} deg/min bench finding to match the wrist's 6:1 "
            "gearing (vs. 36:1 for the other joints). Use before a wrist-only move."
        )
        wrist_feed_btn.setMinimumHeight(30)
        wrist_feed_btn.clicked.connect(self._on_use_wrist_safe_feed)

        self.rapid_checkbox = QtWidgets.QCheckBox("Rapid moves (G0)")
        self.rapid_checkbox.setToolTip("Use rapid G0 moves instead of feed-rate-limited G1 moves.")

        self.send_btn = _style_button(QtWidgets.QPushButton("Send current pose →"), "primary")
        self.send_btn.setToolTip("Send the pose currently shown in the 3D view to the arm as one move.")
        self.send_btn.setMinimumHeight(30)
        self.send_btn.clicked.connect(self._on_send_pose)

        md.addWidget(QtWidgets.QLabel("Feed rate"), 0, 0)
        md.addWidget(self.feed_input, 0, 1)
        md.addWidget(wrist_feed_btn, 1, 0, 1, 2)
        md.addWidget(self.rapid_checkbox, 2, 0, 1, 2)
        md.addWidget(self.send_btn, 3, 0, 1, 2)
        top_row.addWidget(md_box, 2)

        outer.addLayout(top_row)

        # --- Status line + log console ---
        status_row = QtWidgets.QHBoxLayout()
        status_row.addWidget(QtWidgets.QLabel("Last status:"))
        self.status_label = QtWidgets.QLabel("(not connected)")
        self.status_label.setStyleSheet("font-family: Consolas, Menlo, monospace; color: #3a4658;")
        status_row.addWidget(self.status_label, 1)
        outer.addLayout(status_row)

        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(150)
        self.log.setMinimumHeight(110)
        outer.addWidget(self.log)

        # --- Raw command row ---
        raw_row = QtWidgets.QHBoxLayout()
        raw_row.addWidget(QtWidgets.QLabel("Raw command"))
        self.raw_input = QtWidgets.QLineEdit()
        self.raw_input.setPlaceholderText("Advanced: type a grbl command, e.g.  $$   or   $110=3000   then press Enter")
        self.raw_input.setMinimumHeight(28)
        self.raw_input.returnPressed.connect(self._on_send_raw)
        raw_send_btn = QtWidgets.QPushButton("Send")
        raw_send_btn.setMinimumHeight(28)
        raw_send_btn.clicked.connect(self._on_send_raw)
        raw_row.addWidget(self.raw_input, 1)
        raw_row.addWidget(raw_send_btn)
        outer.addLayout(raw_row)

        note = QtWidgets.QLabel(
            f"First time on a fresh board? Click “Push steps/mm setup” once (saved to EEPROM). "
            f"If moves are rejected with an ALARM, click “Unlock alarm”. The raw-command box handles "
            f"anything else — e.g. type $$ + Enter to dump all grbl settings. Default feed "
            f"{SAFE_FEED_DEG_PER_MIN:.0f} deg/min clears full-step resonance on the 36:1 joints; "
            f"use “Set wrist-safe feed” before a wrist-only move."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #8a6d1a; font-size: 11px;")
        outer.addWidget(note)

        return box

    def _log(self, msg):
        self.log.appendPlainText(msg)

    def _refresh_ports(self):
        self.port_combo.clear()
        for device, desc in SerialBridge.list_ports():
            self.port_combo.addItem(f"{device} — {desc}", userData=device)
        if self.port_combo.count() == 0:
            self.port_combo.addItem("(no ports found)", userData=None)

    def _on_connect_toggle(self):
        if self.bridge.is_connected():
            self.bridge.disconnect()
            self.connect_btn.setText("Connect")
            self.conn_status.setText("● Disconnected")
            self.conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
            self.status_label.setText("(not connected)")
            self._log("Disconnected.")
            return

        port = self.port_combo.currentData()
        if not port:
            self._log("No serial port selected.")
            return
        try:
            self.bridge.connect(port, self.baud_input.value())
            self.connect_btn.setText("Disconnect")
            self.conn_status.setText(f"● Connected  ({port})")
            self.conn_status.setStyleSheet("color: #1a7f37; font-weight: 600;")
            self._log(f"Connected to {port} @ {self.baud_input.value()} baud.")
            if self.bridge.startup_banner:
                for line in self.bridge.startup_banner:
                    self._log(f"  <- {line}")
            else:
                self._log("  (no startup banner seen — grbl may already be running, or baud is wrong)")
        except SerialBridgeError as e:
            self.conn_status.setText("● Connection failed")
            self.conn_status.setStyleSheet("color: #b42318; font-weight: 600;")
            self._log(f"Connection failed: {e}")

    def _on_jog_changed(self):
        self.current_thetas = [s.value() for s in self.joint_sliders]
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       self.current_thetas):
            label.setText(f"{name}: {theta:.1f}°")
        self.last_target_xyz = None
        self.canvas.plot_pose(self.current_thetas)

    def _on_solve_ik(self):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        psi = self.psi_input.value()
        prefer_elbow = "up" if self.elbow_up.isChecked() else "down"
        prefer_side = "A" if self.side_a.isChecked() else "B"

        try:
            result = solve_ik_constrained(x, y, z, psi, prefer_elbow=prefer_elbow,
                                           prefer_side=prefer_side)
        except IKUnreachableError as e:
            self.ik_status.setText(str(e))
            self.ik_status.setStyleSheet("color: red;")
            return

        thetas = result["thetas"]
        violations = result["violations"]
        ok, residual = verify_ik(thetas, (x, y, z))

        if result["elbow_used"] == "up":
            self.elbow_up.setChecked(True)
        else:
            self.elbow_down.setChecked(True)
        if result["side_used"] == "A":
            self.side_a.setChecked(True)
        else:
            self.side_b.setChecked(True)

        # Push solved angles onto the sliders (blocking signals to avoid
        # feedback loops, then update once manually).
        for slider, theta in zip(self.joint_sliders, thetas):
            slider.blockSignals(True)
            slider.setValue(int(round(theta)))
            slider.blockSignals(False)

        self.current_thetas = list(thetas)
        self.last_target_xyz = (x, y, z)
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       thetas):
            label.setText(f"{name}: {theta:.1f}°")

        self.canvas.plot_pose(thetas, target_xyz=(x, y, z))

        status_lines = [f"Solved θ = [{', '.join(f'{t:.1f}°' for t in thetas)}]",
                         f"FK residual (true tool tip): {residual:.2f} mm"]
        if result["elbow_switched"]:
            status_lines.append(
                f"Auto-switched to elbow-{result['elbow_used']} "
                f"(elbow-{prefer_elbow} was requested but violated a joint limit)."
            )
        if result["side_switched"]:
            status_lines.append(
                f"Auto-switched to side {result['side_used']} "
                f"(side {prefer_side} was requested but violated a joint limit)."
            )
        if violations:
            status_lines.append(
                "UNREACHABLE WITHIN LIMITS on all elbow/side branches (measured hardware "
                "limits): "
                + "; ".join(f"joint {i} = {t:.1f}° (limit {lo}..{hi})" for i, t, lo, hi in violations)
            )
        self.ik_status.setText("\n".join(status_lines))
        self.ik_status.setStyleSheet("color: red;" if violations else "color: green;")

    def _on_preset_psi(self, preset_name):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        prefer_elbow = "up" if self.elbow_up.isChecked() else "down"
        prefer_side = "A" if self.side_a.isChecked() else "B"
        base_psi = PSI_PRESETS[preset_name]

        result = find_feasible_psi(x, y, z, base_psi, prefer_elbow=prefer_elbow,
                                    prefer_side=prefer_side)
        if result is None:
            self.ik_status.setText(
                f"No feasible tool angle found near '{preset_name}' "
                f"({base_psi:.0f} deg) within +/-178 deg search -- target may be out of reach entirely."
            )
            self.ik_status.setStyleSheet("color: red;")
            return

        self.psi_input.setValue(result["psi_used"])
        self._on_solve_ik()

        offset = result["offset_from_base_deg"]
        if abs(offset) < 0.05:
            note = f"'{preset_name}' preset used exactly ({base_psi:.0f} deg)."
        else:
            note = (
                f"'{preset_name}' exact ({base_psi:.0f} deg) violated a joint limit -- "
                f"used nearest feasible tilt instead: {result['psi_used']:.1f} deg "
                f"({offset:+.1f} deg from preset)."
            )
        self.ik_status.setText(note + "\n" + self.ik_status.text())


    def _on_save_offsets(self):
        offsets = [w.value() for w in self.offset_inputs]
        save_home_offsets(offsets)
        self._log(f"Saved home offsets: {offsets}")

    def _on_reload_offsets(self):
        offsets = load_home_offsets()
        for w, v in zip(self.offset_inputs, offsets):
            w.setValue(v)
        self._log("Reloaded home offsets from disk.")

    def _on_push_settings(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log("Pushing $100-$103 steps/degree settings...")
        try:
            results = self.bridge.push_steps_per_unit_settings()
        except SerialBridgeError as e:
            self._log(f"Settings push failed: {e}")
            return
        for setting, value, response in results:
            self._log(f"  {setting}={value:.4f}  -> {', '.join(response)}")
        self._log("Done. These persist in grbl's EEPROM across power cycles.")

    def _on_unlock(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        try:
            response = self.bridge.unlock()
            self._log(f"$X -> {', '.join(response)}")
        except SerialBridgeError as e:
            self._log(f"Unlock failed: {e}")

    def _on_send_raw(self):
        line = self.raw_input.text().strip()
        if not line:
            return
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log(f"Sending raw: {line}")
        try:
            response = self.bridge.send_raw(line)
            for r in response:
                self._log(f"  <- {r}")
        except SerialBridgeError as e:
            self._log(f"Raw send failed: {e}")
        finally:
            self.raw_input.clear()

    def _on_use_wrist_safe_feed(self):
        self.feed_input.setValue(WRIST_SAFE_FEED_DEG_PER_MIN)
        self._log(
            f"Feed rate set to {WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min "
            "(wrist-safe — scaled from the bench-tested 36:1-joint value for the wrist's 6:1 gearing)."
        )

    def _on_status(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        status = self.bridge.request_status()
        if status:
            self.status_label.setText(status)
            self._log(f"Status: {status}")
        else:
            self._log("No status response received (older grbl builds may not support '?').")

    def _on_feed_hold(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.feed_hold()
        self._log("Sent feed hold (!).")

    def _on_resume(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.cycle_start_resume()
        self._log("Sent cycle start/resume (~).")

    def _on_soft_reset(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.soft_reset()
        self._log("Sent soft reset (Ctrl-X). Grbl will reprint its startup banner.")

    def _on_send_pose(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return

        offsets = [w.value() for w in self.offset_inputs]
        motor_angles = apply_home_offset(self.current_thetas, offsets)
        rapid = self.rapid_checkbox.isChecked()
        feed = self.feed_input.value()

        line = self.bridge.build_move_gcode(
            motor_angles, feed_deg_per_min=feed, rapid=rapid,
            per_axis_max_deg_per_min=self._active_axis_speed_limits())
        est_steps = estimated_steps_for_display(self.current_thetas, offsets)
        self._log(f"Sending: {line}")
        self._log(f"  (thetas {[round(t,1) for t in self.current_thetas]}, "
                   f"est. steps {est_steps} — for reference only, not sent)")
        try:
            response = self.bridge.send_line(line)
        except GrblAlarmError as e:
            self._log(f"ALARM: {e}")
            self._log("  -> Click 'Unlock ($X)' and try again.")
            return
        except SerialBridgeError as e:
            self._log(f"Send failed: {e}")
            return
        for resp_line in response:
            self._log(f"  <- {resp_line}")

    def _update_pose(self, send=False):
        self.canvas.plot_pose(self.current_thetas, self.last_target_xyz)


def main():
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


# ============================================================================
# entry point
# ============================================================================
if __name__ == "__main__":
    main()
