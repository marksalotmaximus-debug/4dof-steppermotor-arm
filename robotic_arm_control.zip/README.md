# 4-DOF Arm Control App

Local PyQt5 desktop app: joint jog, closed-form IK, live 3D DH visualization,
and a serial bridge to the Arduino Uno R3 / grbl4axis stack.

## Setup

```bash
pip install -r requirements.txt
python main.py
```

Tested logic (kinematics only, no PyQt5/hardware needed) against the plan's
numbers:

- Forward kinematics at the zero pose reaches (432.81, 0, 24.25) mm — matches
  21.15 + 194.66 + 152 + 65 = 432.81mm total reach at the 24.25mm base height.
- IK → FK round trips to 0.0000mm residual across several targets and both
  elbow-up/elbow-down branches.
- Step conversion: 1° at a 36:1 joint = 20 steps (7200 steps / 360°); wrist
  (6:1) = 3.33 steps/°. Confirmed via round-trip degrees→steps→degrees.

## What's implemented

- **`kinematics.py`** — generic 4x4 DH forward kinematics (for the 3D view),
  and the closed-form geometric IK. Now targets the TRUE TOOL TIP (Layer 2):
  it accounts for the rigid tool offset, so a requested (x,y,z) places the
  actual marker/gripper tip there, not the wrist. A lateral (sideways) tool
  offset adds a base-angle "Side A/B" branch alongside elbow up/down. Also
  has joint-limit-aware solving (auto-switches branches), tool-angle presets,
  and waypoint path planning (line/circle generators, densify + validate).
- **`config.py`** — DH params, gear ratios, steps-per-rev, measured joint
  limits, home-offset persistence (`home_offsets.json`), tool-offset
  persistence (`tool_offset.json`, measured 50.5mm lateral), ψ presets.
- **`serial_bridge.py`** — pyserial wrapper (real grbl G-code, see below),
  plus `stream_gcode()` for continuous buffered streaming (smooth motion on
  grbl 0.9 without jog mode, by keeping the planner buffer full).
- **`hershey_font.py`** — self-contained single-stroke font + text engine
  for the writing demo (text → strokes → pen path with Z-lifts → IK).
- **`gui.py`** — four tabs: **Single Pose** (jog sliders, IK panel with
  live 3D plot, home-offset + tool-offset calibration), **Waypoint Path**
  (waypoint table, line/circle generators, simulate + stream), and **Write
  Text** (Hershey single-stroke writing on a flat plane with pen up/down),
  **Motion Tuning** (per-joint max speed, acceleration and steps-per-degree,
  with a microstepping helper and a one-click push to the board's EEPROM),
  plus a shared serial connect/send panel with a log console.

  Per-axis speed note: G-code's `F` is a single *coordinated* feed for the
  whole move, not a per-axis value, so per-joint speed is enforced two ways —
  grbl's `$110`-`$113` act as hard per-axis ceilings in firmware, and the app
  separately computes the fastest `F` that keeps every joint under its own
  limit (`serial_bridge.coordinated_feed`). Persisted to `motion_profile.json`.

  Run the multi-file version with `python gui.py` (needs all six .py files
  together). Or run the single-file `python arm_control.py`, which bundles
  everything (including the font) into one file.

## Serial protocol — real grbl G-code, not a custom format

This talks to **real gcobos/grbl4axis** using standard grbl semantics:

- **Motion:** `G90 G1 X<deg> Y<deg> Z<deg> E<deg> F<feed>` (feed-rate move)
  or `G90 G0 X<deg> Y<deg> Z<deg> E<deg>` (rapid move). Absolute
  positioning (`G90`), one axis letter per joint (X=base, Y=shoulder,
  Z=elbow, E=wrist).
- **One-time setup:** grbl converts "units" (we define 1 unit = 1 output
  degree) into steps using its own EEPROM settings, `$100`-`$103`. The
  GUI's **"Push $100-$103 Settings"** button writes these once
  (20 steps/° for the 36:1 joints, 3.333 steps/° for the 6:1 wrist) — they
  persist across power cycles after that.
- **Responses:** grbl replies `ok` per accepted line or `error:<n>` on
  rejection — the app blocks on each send until it gets one back.
- **ALARM handling:** grbl4axis boots into an ALARM lock if homing is
  enabled in settings but hasn't run (this project has no limit switches
  per the plan). The GUI's **"Unlock ($X)"** button clears that.
- **Real-time controls:** Status (`?`), Feed Hold (`!`), Resume (`~`), and
  Soft Reset (Ctrl-X) buttons are in the serial panel — these bypass the
  normal line queue and get no `ok` response, by grbl design.

### The 4th-axis pin gap — resolved

`gcobos/grbl4axis` maps its 4th axis ("E") to Uno pins **D12/D13**,
freed up by disabling grbl's variable-spindle PWM feature. Confirm your
CNC Shield's wrist driver is actually wired there before wrist moves will
do anything.

## Open items this app does NOT yet resolve

Straight from plan §8 / §5.4 — still needs real hardware:

- **Home offset calibration** — `home_offsets.json` defaults to
  `[0,0,0,0]`. Use the GUI's calibration panel to jog each joint to a known
  physical reference pose, compare to the DH-solved angle, and enter the
  difference. Until this is done, solved angles won't line up with the real
  arm's zero position.
- **Joint limits** — `config.JOINT_LIMITS_DEG` are placeholders, not
  measured stops. The GUI will warn (not block) if a solved pose exceeds
  them.
- **PSU voltage confirmation (12V vs 24V)** — outside this app's scope;
  resolve on the bench before sending real moves.
- **Physical D12/D13 wiring for the wrist axis** — the firmware-side pin
  mapping is now confirmed (gcobos/grbl4axis's "E" axis), but you still
  need to verify your CNC Shield/wiring actually routes the wrist driver's
  STEP/DIR there.
- **Homing / limit switches** — this project has none per the plan. If
  grbl's `$21`/`$22` homing-required settings are on, it'll boot into
  ALARM; use the GUI's Unlock button, or turn those settings off via `$$`
  if you don't plan to add limit switches.
- **Tool-angle (ψ) strategy** — currently the GUI just takes ψ as a manual
  numeric input per target. If you want an automatic task-based ψ (e.g.
  "always point straight down for pick moves"), that's a small addition to
  the IK panel — say the word and I'll add a mode toggle for it.

## Suggested next steps

1. Flash `gcobos/grbl4axis`, then in this app: connect → **Push $100-$103
   Settings** (one-time) → **Unlock ($X)** if needed → try a small
   `Send Current Pose to Grbl` move near the arm's current position before
   anything ambitious.
2. Do the home-offset walk (jog panel → note real vs. solved angle → save
   offsets) once the arm is mechanically assembled per Phase 1/2 of the
   roadmap.
3. Measure real joint limits and update `config.JOINT_LIMITS_DEG`.
