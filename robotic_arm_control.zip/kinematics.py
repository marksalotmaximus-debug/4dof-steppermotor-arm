"""
kinematics.py

Ported from the browser JS FK/IK simulator (plan section 5) into Python.

Two independent code paths, deliberately kept separate so one can validate
the other:

  1. forward_kinematics() — a fully general 4x4 DH matrix chain. Used for
     the live 3D view and to sanity-check IK solutions (re-run FK on a
     solved pose and compare against the requested target).

  2. solve_ik() — the closed-form geometric solver as derived in the plan:
       - theta1 = atan2(target_y, target_x), locked first
       - project the remaining target into the shoulder/elbow/wrist plane
         (which is tilted purely in the vertical, base-offset-shifted plane
         established by joint 1's alpha=90 twist)
       - subtract the wrist link (L3) along the desired tool angle psi to
         get a "wrist point", then solve a classic 2-link (L1, L2) planar
         IK via law of cosines
       - theta4 = psi - theta2 - theta3
       - elbow branch ('up' / 'down') selectable — this directly resolves
         the "elbow-up/elbow-down not yet implemented" open item.
"""

import numpy as np

import config


def dh_matrix(theta_deg, d, a, alpha_deg):
    """Standard DH transform: Rot_z(theta) * Trans_z(d) * Trans_x(a) * Rot_x(alpha)."""
    t = np.radians(theta_deg)
    al = np.radians(alpha_deg)
    ct, st = np.cos(t), np.sin(t)
    ca, sa = np.cos(al), np.sin(al)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0.0,      sa,       ca,      d],
        [0.0,     0.0,      0.0,    1.0],
    ])


def forward_kinematics(thetas_deg, dh_params=None):
    """
    Given 4 joint angles (degrees), return:
      - joint_positions: list of 5 numpy 3-vectors (base origin, then each
        joint's resulting frame origin, ending at the tool tip)
      - T_final: the full 4x4 transform of the tool frame in world coords
    """
    if dh_params is None:
        dh_params = config.DH_PARAMS

    T = np.eye(4)
    positions = [T[:3, 3].copy()]
    for theta, params in zip(thetas_deg, dh_params):
        T = T @ dh_matrix(theta, params["d"], params["a"], params["alpha_deg"])
        positions.append(T[:3, 3].copy())
    return positions, T


class IKUnreachableError(ValueError):
    """Raised when the requested target/psi combination has no real solution."""
    pass


def solve_ik(x, y, z, psi_deg, elbow="up", dh_params=None):
    """
    Closed-form IK matching plan section 5.3.

    x, y, z   : target tool-tip position in world mm
    psi_deg   : desired tool angle within the arm's vertical plane (degrees),
                i.e. the resolved value of theta2+theta3+theta4
    elbow     : "up" or "down" — selects the elbow branch

    Returns (theta1, theta2, theta3, theta4) in degrees.
    Raises IKUnreachableError if the target is out of reach for the given psi.
    """
    if dh_params is None:
        dh_params = config.DH_PARAMS

    a1 = dh_params[0]["a"]
    L1 = dh_params[1]["a"]
    L2 = dh_params[2]["a"]
    L3 = dh_params[3]["a"]
    d1 = dh_params[0]["d"]

    # Step 1: base yaw, locked before solving the rest (per plan 5.3.1) so
    # base rotation never drifts unnecessarily when only reach/height change.
    theta1 = np.degrees(np.arctan2(y, x))
    t1 = np.radians(theta1)

    # Step 2: project target into the shoulder/elbow/wrist plane established
    # by joint 1's origin (a1*cos1, a1*sin1, d1) and its horizontal x1-axis
    # (cos1, sin1, 0) / vertical y1-axis (0,0,1) — derived from the joint-1
    # DH matrix with alpha1=90.
    u = (x - a1 * np.cos(t1)) * np.cos(t1) + (y - a1 * np.sin(t1)) * np.sin(t1)
    v = z - d1

    # Step 3: subtract the wrist link along psi to get the 2-link wrist point.
    psi = np.radians(psi_deg)
    uw = u - L3 * np.cos(psi)
    vw = v - L3 * np.sin(psi)

    # Step 4: classic 2-link planar IK, law of cosines.
    r2 = uw ** 2 + vw ** 2
    D = (r2 - L1 ** 2 - L2 ** 2) / (2 * L1 * L2)

    if abs(D) > 1.0 + 1e-9:
        raise IKUnreachableError(
            f"Target (x={x:.1f}, y={y:.1f}, z={z:.1f}) with psi={psi_deg:.1f} deg "
            f"is out of reach (|D|={abs(D):.3f} > 1)."
        )
    D = np.clip(D, -1.0, 1.0)

    sign = 1.0 if elbow == "down" else -1.0
    theta3 = np.degrees(np.arctan2(sign * np.sqrt(max(0.0, 1 - D ** 2)), D))

    t3 = np.radians(theta3)
    theta2 = np.degrees(
        np.arctan2(vw, uw) - np.arctan2(L2 * np.sin(t3), L1 + L2 * np.cos(t3))
    )

    theta4 = psi_deg - theta2 - theta3

    return theta1, theta2, theta3, theta4


def verify_ik(thetas_deg, target_xyz, tol_mm=0.5):
    """
    Re-run FK on a solved pose and check the tool tip lands within tol_mm of
    the requested target. Returns (ok: bool, residual_mm: float).
    """
    positions, _ = forward_kinematics(thetas_deg)
    tip = positions[-1]
    residual = float(np.linalg.norm(tip - np.array(target_xyz)))
    return residual <= tol_mm, residual


def apply_home_offset(thetas_deg, home_offset_deg=None):
    """
    Convert DH-frame solved joint angles into real motor angles by applying
    the home offset calibration (plan section 5.4):

        motor_angle = theta_dh - home_offset

    With grbl doing the degrees->steps conversion itself (via its $100-$103
    steps-per-unit settings, see config.py), this motor_angle in degrees is
    exactly what gets sent as the G-code axis word — no step math needed on
    the host side.
    """
    if home_offset_deg is None:
        home_offset_deg = config.load_home_offsets()
    return [theta - offset for theta, offset in zip(thetas_deg, home_offset_deg)]


def remove_home_offset(motor_angles_deg, home_offset_deg=None):
    """Inverse of apply_home_offset — e.g. to interpret a status report back into DH-frame angles."""
    if home_offset_deg is None:
        home_offset_deg = config.load_home_offsets()
    return [angle + offset for angle, offset in zip(motor_angles_deg, home_offset_deg)]


def estimated_steps_for_display(thetas_deg, home_offset_deg=None):
    """
    Informational only — NOT sent to grbl. Shows the equivalent raw step
    count for a given pose, purely so you can sanity-check against the
    physical gearbox (e.g. confirm a move "looks like" a sensible number of
    steps) without grbl actually receiving step counts directly.
    """
    motor_angles = apply_home_offset(thetas_deg, home_offset_deg)
    return [int(round(angle * spd)) for angle, spd in zip(motor_angles, config.GRBL_STEPS_PER_DEGREE)]


def check_joint_limits(thetas_deg, limits=None):
    """
    Returns a list of (index, theta, lo, hi) for any violations.
    Empty list means all clear. config.JOINT_LIMITS_DEG holds the measured
    hardware limits (plan section 8, closed out) -- see config.py for the
    per-joint travel figures and how they were converted to +/- ranges.
    """
    if limits is None:
        limits = config.JOINT_LIMITS_DEG
    violations = []
    for i, (theta, (lo, hi)) in enumerate(zip(thetas_deg, limits)):
        if not (lo <= theta <= hi):
            violations.append((i, theta, lo, hi))
    return violations


def _violation_severity(violations):
    """Sum of how far out-of-range each violation is, in degrees. Used only
    to pick the "less bad" of two invalid branches — not a measure of safety."""
    total = 0.0
    for _, theta, lo, hi in violations:
        total += max(lo - theta, theta - hi, 0.0)
    return total


def solve_ik_constrained(x, y, z, psi_deg, limits=None, prefer_elbow="up", dh_params=None):
    """
    Joint-limit-aware wrapper around solve_ik(). Tries the preferred elbow
    branch first; if it violates a joint limit, automatically retries the
    other branch. Returns whichever branch is fully valid, or (if neither
    is) the one with the smaller total violation, so the caller always gets
    an actual answer plus an honest account of what's wrong with it.

    Returns a dict:
      {
        "thetas": (t1, t2, t3, t4),
        "elbow_used": "up" | "down",
        "elbow_switched": bool,   # True if prefer_elbow branch was rejected
        "violations": [...],      # empty list if fully within limits
      }

    Raises IKUnreachableError if the target/psi combo has no real geometric
    solution at all (i.e. solve_ik itself fails for both branches) — that's
    a different failure mode than "reachable but outside joint limits".

    IMPORTANT: config.JOINT_LIMITS_DEG holds the measured hardware limits
    (plan section 8, closed out). One caveat, flagged in config.py: J1's
    +/-180 deg range assumes it's a true continuous-rotation joint with no
    hard stop -- if that's not physically true, double-check it before
    trusting base-yaw moves near that boundary.
    """
    if limits is None:
        limits = config.JOINT_LIMITS_DEG

    other_elbow = "down" if prefer_elbow == "up" else "up"

    candidates = []
    for elbow in (prefer_elbow, other_elbow):
        try:
            thetas = solve_ik(x, y, z, psi_deg, elbow=elbow, dh_params=dh_params)
        except IKUnreachableError:
            continue
        violations = check_joint_limits(thetas, limits)
        candidates.append((elbow, thetas, violations))

    if not candidates:
        # Neither branch has a real geometric solution -- re-raise with the
        # preferred branch's error for a clear message.
        solve_ik(x, y, z, psi_deg, elbow=prefer_elbow, dh_params=dh_params)

    # Prefer a fully valid solution; among those, prefer the requested branch.
    valid = [c for c in candidates if not c[2]]
    if valid:
        for elbow, thetas, violations in valid:
            if elbow == prefer_elbow:
                return {"thetas": thetas, "elbow_used": elbow,
                        "elbow_switched": False, "violations": []}
        elbow, thetas, violations = valid[0]
        return {"thetas": thetas, "elbow_used": elbow,
                "elbow_switched": True, "violations": []}

    # Neither branch is fully valid -- return the less-bad one, honestly.
    candidates.sort(key=lambda c: _violation_severity(c[2]))
    elbow, thetas, violations = candidates[0]
    return {"thetas": thetas, "elbow_used": elbow,
            "elbow_switched": elbow != prefer_elbow, "violations": violations}


def find_feasible_psi(x, y, z, base_psi_deg, limits=None, prefer_elbow="up",
                       dh_params=None, search_step_deg=2.0, max_offset_deg=178.0):
    """
    Search for the psi value nearest to base_psi_deg (e.g. a named preset
    like "level" = 0 deg) for which solve_ik_constrained() finds a fully
    joint-limit-valid solution (either elbow branch).

    Search order: base_psi_deg, then +step, -step, +2*step, -2*step, ...
    out to +/-max_offset_deg. Returns the FIRST feasible hit, so a result
    exactly at base_psi_deg is preferred, and if that's not reachable you
    get the closest tilt that is -- not an arbitrary one.

    Returns a dict (adds two keys to solve_ik_constrained()'s normal
    result): {"psi_used": ..., "offset_from_base_deg": ..., ...}
    or None if nothing within +/-max_offset_deg is fully valid.
    """
    if limits is None:
        limits = config.JOINT_LIMITS_DEG

    offsets = [0.0]
    n = 1
    while n * search_step_deg <= max_offset_deg:
        offsets.append(n * search_step_deg)
        offsets.append(-n * search_step_deg)
        n += 1

    for offset in offsets:
        psi = base_psi_deg + offset
        try:
            result = solve_ik_constrained(x, y, z, psi, limits=limits,
                                           prefer_elbow=prefer_elbow, dh_params=dh_params)
        except IKUnreachableError:
            continue
        if not result["violations"]:
            result["psi_used"] = psi
            result["offset_from_base_deg"] = offset
            return result

    return None


def find_feasible_psi_presets(x, y, z, presets=None, limits=None, prefer_elbow="up", dh_params=None):
    """
    Runs find_feasible_psi() for every named preset in `presets` (defaults
    to config.PSI_PRESETS). Returns a dict {name: result_or_None} so a GUI
    can show the user every preset that's actually reachable right now,
    each with its resulting psi (exact match or nearest feasible), rather
    than the user guessing a psi value by hand.
    """
    if presets is None:
        presets = config.PSI_PRESETS
    return {
        name: find_feasible_psi(x, y, z, base_psi, limits=limits,
                                 prefer_elbow=prefer_elbow, dh_params=dh_params)
        for name, base_psi in presets.items()
    }


# ===========================================================================
# Waypoint path planning (plan sections 6 & 7)
#
# A "path" here is a list of Cartesian target poses (x, y, z, psi). To turn
# it into smooth motion we:
#   1. densify it -- interpolate many small segments between the given
#      waypoints, so grbl's planner has short blocks to blend (this is what
#      makes 0.9 motion come out smooth; see serial_bridge.stream_gcode).
#   2. solve IK at every densified point, all limit-checked.
#   3. hand the resulting joint-angle list to the caller, who converts to
#      G-code and streams it.
#
# Everything is validated BEFORE any hardware command is sent, so a path
# with an unreachable/limit-violating point fails in software, not mid-move.
# ===========================================================================


class PathPlanningError(ValueError):
    """Raised when a waypoint path can't be fully solved within joint limits."""
    def __init__(self, message, index=None, point=None):
        super().__init__(message)
        self.index = index
        self.point = point


def _interpolate_poses(poses, max_segment_mm=5.0, max_segment_psi_deg=3.0):
    """
    Given a list of (x, y, z, psi) waypoints, insert intermediate points so
    no linear step exceeds max_segment_mm in position or max_segment_psi_deg
    in tool angle. Straight-line (Cartesian) interpolation between waypoints.
    Returns the densified list (always includes the original waypoints).
    """
    if len(poses) < 2:
        return list(poses)

    dense = [tuple(poses[0])]
    for a, b in zip(poses[:-1], poses[1:]):
        ax, ay, az, apsi = a
        bx, by, bz, bpsi = b
        dist = np.sqrt((bx - ax) ** 2 + (by - ay) ** 2 + (bz - az) ** 2)
        dpsi = abs(bpsi - apsi)
        n_pos = int(np.ceil(dist / max_segment_mm)) if max_segment_mm > 0 else 1
        n_psi = int(np.ceil(dpsi / max_segment_psi_deg)) if max_segment_psi_deg > 0 else 1
        n = max(1, n_pos, n_psi)
        for k in range(1, n + 1):
            t = k / n
            dense.append((
                ax + (bx - ax) * t,
                ay + (by - ay) * t,
                az + (bz - az) * t,
                apsi + (bpsi - apsi) * t,
            ))
    return dense


def plan_waypoint_path(poses, limits=None, prefer_elbow="up", dh_params=None,
                        max_segment_mm=5.0, max_segment_psi_deg=3.0,
                        auto_psi=False, psi_presets=None):
    """
    Turn a list of (x, y, z, psi) Cartesian waypoints into a validated list
    of joint-angle solutions ready to stream.

    If auto_psi is True, the psi value in each pose is treated as a *base*
    preset target and find_feasible_psi() is used to nudge it into limits at
    each densified point (useful when a fixed psi would clip a limit partway
    through the path). If False, the given psi is used exactly and a
    limit violation raises PathPlanningError.

    Returns a dict:
      {
        "dense_poses":  [(x,y,z,psi), ...],   # after interpolation
        "thetas":       [(t1,t2,t3,t4), ...], # DH-frame joint angles
        "elbow_used":   [ "up"|"down", ... ],
        "psi_used":     [ float, ... ],       # actual psi at each point
      }

    Raises PathPlanningError (with .index / .point) at the first point that
    can't be solved within limits.
    """
    if limits is None:
        limits = config.JOINT_LIMITS_DEG

    dense = _interpolate_poses(poses, max_segment_mm, max_segment_psi_deg)

    thetas_list = []
    elbow_list = []
    psi_list = []

    for i, (x, y, z, psi) in enumerate(dense):
        if auto_psi:
            result = find_feasible_psi(x, y, z, psi, limits=limits,
                                        prefer_elbow=prefer_elbow, dh_params=dh_params)
            if result is None:
                raise PathPlanningError(
                    f"Path point {i} ({x:.1f}, {y:.1f}, {z:.1f}) has no feasible "
                    f"tool angle near psi={psi:.1f} within joint limits.",
                    index=i, point=(x, y, z, psi))
        else:
            try:
                result = solve_ik_constrained(x, y, z, psi, limits=limits,
                                               prefer_elbow=prefer_elbow, dh_params=dh_params)
            except IKUnreachableError as e:
                raise PathPlanningError(
                    f"Path point {i} ({x:.1f}, {y:.1f}, {z:.1f}) is geometrically "
                    f"unreachable: {e}", index=i, point=(x, y, z, psi)) from e
            if result["violations"]:
                v = result["violations"]
                raise PathPlanningError(
                    f"Path point {i} ({x:.1f}, {y:.1f}, {z:.1f}, psi={psi:.1f}) "
                    f"violates joint limits: "
                    + "; ".join(f"j{j}={t:.1f} (limit {lo}..{hi})" for j, t, lo, hi in v),
                    index=i, point=(x, y, z, psi))

        thetas_list.append(result["thetas"])
        elbow_list.append(result["elbow_used"])
        psi_list.append(result.get("psi_used", psi))

    return {
        "dense_poses": dense,
        "thetas": thetas_list,
        "elbow_used": elbow_list,
        "psi_used": psi_list,
    }


def line_sweep(start_xyz, end_xyz, psi_deg, num_waypoints=2):
    """
    Generate a straight-line sweep between two Cartesian points at a fixed
    tool angle. Returns a list of (x, y, z, psi) waypoints (the densifier in
    plan_waypoint_path will subdivide further as needed, but you can request
    more anchor points here too).
    """
    sx, sy, sz = start_xyz
    ex, ey, ez = end_xyz
    n = max(2, num_waypoints)
    poses = []
    for k in range(n):
        t = k / (n - 1)
        poses.append((sx + (ex - sx) * t, sy + (ey - sy) * t,
                      sz + (ez - sz) * t, psi_deg))
    return poses


def circle_path(center_xyz, radius_mm, psi_deg, plane="xy", num_waypoints=48,
                 start_angle_deg=0.0, revolutions=1.0):
    """
    Generate waypoints tracing a circle at a fixed tool angle.

    plane: "xy" (flat, constant z), "xz" (vertical, constant y), or
           "yz" (vertical, constant x).
    num_waypoints: points around one full revolution (more = rounder).
    Returns a list of (x, y, z, psi) waypoints.
    """
    cx, cy, cz = center_xyz
    n = max(8, int(num_waypoints * revolutions))
    poses = []
    for k in range(n + 1):
        ang = np.radians(start_angle_deg) + 2 * np.pi * revolutions * (k / n)
        c, s = np.cos(ang), np.sin(ang)
        if plane == "xy":
            poses.append((cx + radius_mm * c, cy + radius_mm * s, cz, psi_deg))
        elif plane == "xz":
            poses.append((cx + radius_mm * c, cy, cz + radius_mm * s, psi_deg))
        elif plane == "yz":
            poses.append((cx, cy + radius_mm * c, cz + radius_mm * s, psi_deg))
        else:
            raise ValueError(f"Unknown plane '{plane}' (use 'xy', 'xz', or 'yz').")
    return poses
