"""
gui.py

PyQt5 desktop app tying together kinematics.py and serial_bridge.py.

Layout:
  Left column:
    - Joint jog sliders (theta1..theta4) with live degree readout
    - Target pose panel (X, Y, Z, psi, elbow up/down) + "Solve IK" button
    - Home offset calibration panel (4 fields, Save/Reload)
  Right column:
    - Live 3D plot of the arm (matplotlib, driven by forward_kinematics())
  Bottom:
    - Serial connection panel: port dropdown, connect/disconnect, one-time
      $100-$103 grbl settings push, unlock/status/feed-hold/resume/soft-reset,
      feed-rate input, and "Send Current Pose to Grbl" (real G-code, not
      raw step counts — see serial_bridge.py)

Run via main.py.
"""

import sys
import math

import numpy as np
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

import config
import kinematics
import serial_bridge


class PathStreamWorker(QtCore.QThread):
    """
    Streams a planned waypoint path to grbl on a background thread so the
    GUI stays responsive. Emits progress per acknowledged move and a final
    'finished_streaming' signal. Abort is cooperative: set self._abort and
    the stream stops (with a feed-hold) before the next move.
    """
    progress = QtCore.pyqtSignal(int, int)          # (index, total)
    finished_streaming = QtCore.pyqtSignal(int, bool)  # (sent_count, aborted)
    error = QtCore.pyqtSignal(str)

    def __init__(self, bridge, gcode_lines, feed_deg_per_min, parent=None):
        super().__init__(parent)
        self.bridge = bridge
        self.gcode_lines = gcode_lines
        self.feed = feed_deg_per_min
        self._abort = False

    def request_abort(self):
        self._abort = True

    def run(self):
        try:
            sent, aborted = self.bridge.stream_gcode(
                self.gcode_lines,
                on_progress=lambda i, total, line, resp: self.progress.emit(i + 1, total),
                should_abort=lambda: self._abort,
            )
            self.finished_streaming.emit(sent, aborted)
        except serial_bridge.SerialBridgeError as e:
            self.error.emit(str(e))


class Arm3DCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(5, 5))
        super().__init__(fig)
        self.setParent(parent)
        self.ax = fig.add_subplot(111, projection="3d")
        self._reach = sum(p["a"] for p in config.DH_PARAMS) + 50
        self.plot_pose([0, 0, 0, 0])

    def plot_pose(self, thetas_deg, target_xyz=None, path_xyz=None):
        positions, _ = kinematics.forward_kinematics(thetas_deg)
        pts = np.array(positions)

        self.ax.clear()
        # Optional path trace (tool-tip positions along a planned waypoint path)
        if path_xyz is not None and len(path_xyz) > 1:
            path = np.array(path_xyz)
            self.ax.plot(path[:, 0], path[:, 1], path[:, 2], "-",
                         color="#9b59b6", linewidth=1.2, alpha=0.7)
        # Arm links
        self.ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], "-o", color="#2a6fdb",
                     linewidth=3, markersize=6, markerfacecolor="#ff6a3d")
        # Base marker
        self.ax.scatter([0], [0], [0], color="black", s=40, marker="s")

        if target_xyz is not None:
            self.ax.scatter([target_xyz[0]], [target_xyz[1]], [target_xyz[2]],
                             color="green", s=60, marker="*", label="target")
            self.ax.legend(loc="upper left", fontsize=8)

        r = self._reach
        self.ax.set_xlim(-r, r)
        self.ax.set_ylim(-r, r)
        self.ax.set_zlim(0, 2 * r)
        self.ax.set_xlabel("X (mm)")
        self.ax.set_ylabel("Y (mm)")
        self.ax.set_zlabel("Z (mm)")
        self.ax.set_title("4-DOF arm — live DH pose")
        self.draw()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4-DOF Arm Control")
        self.resize(1500, 950)
        self.setMinimumSize(1300, 800)

        self.bridge = serial_bridge.SerialBridge()
        self.current_thetas = [0.0, 0.0, 0.0, 0.0]
        self.last_target_xyz = None

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root_layout = QtWidgets.QVBoxLayout(central)

        top_layout = QtWidgets.QHBoxLayout()
        root_layout.addLayout(top_layout, stretch=1)

        # Left side is a tab widget so the single-pose controls and the new
        # waypoint-path player each get full room instead of being stacked
        # into one cramped column.
        self.left_tabs = QtWidgets.QTabWidget()
        self.left_tabs.setMinimumWidth(520)
        top_layout.addWidget(self.left_tabs, stretch=0)

        self.canvas = Arm3DCanvas(self)
        top_layout.addWidget(self.canvas, stretch=1)

        # Tab 1 -- single pose (jog + IK + calibration)
        single_pose_tab = QtWidgets.QWidget()
        single_col = QtWidgets.QVBoxLayout(single_pose_tab)
        single_col.addWidget(self._build_jog_panel())
        single_col.addWidget(self._build_ik_panel())
        single_col.addWidget(self._build_calibration_panel())
        single_col.addStretch(1)
        self.left_tabs.addTab(single_pose_tab, "Single Pose")

        # Tab 2 -- waypoint path player
        self.left_tabs.addTab(self._build_waypoint_tab(), "Waypoint Path")

        root_layout.addWidget(self._build_serial_panel(), stretch=0)

        self._refresh_ports()
        self._update_pose(send=False)

    # -- panels ------------------------------------------------------------

    def _build_jog_panel(self):
        box = QtWidgets.QGroupBox("Joint Jog (degrees)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.joint_sliders = []
        self.joint_labels = []
        names = ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"]
        for i, name in enumerate(names):
            lo, hi = config.JOINT_LIMITS_DEG[i]
            # J1 has no hard stop (true continuous rotation), so its real
            # limit is +/-inf -- Qt sliders need a finite range, so give it
            # a generous jog range (a few full turns either way) purely for
            # the UI. This does NOT feed into check_joint_limits(), which
            # still correctly treats J1 as unbounded.
            if not math.isfinite(lo) or not math.isfinite(hi):
                lo, hi = -720.0, 720.0
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setMinimum(int(lo))
            slider.setMaximum(int(hi))
            slider.setValue(0)
            slider.setMinimumWidth(220)
            slider.valueChanged.connect(self._on_jog_changed)

            label = QtWidgets.QLabel(f"{name}: 0.0°")
            label.setMinimumWidth(140)
            layout.addWidget(label, i, 0)
            layout.addWidget(slider, i, 1)
            self.joint_sliders.append(slider)
            self.joint_labels.append(label)

        return box

    def _build_ik_panel(self):
        box = QtWidgets.QGroupBox("Target Pose (Inverse Kinematics)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(10)
        layout.setContentsMargins(12, 16, 12, 12)

        self.x_input = QtWidgets.QDoubleSpinBox()
        self.y_input = QtWidgets.QDoubleSpinBox()
        self.z_input = QtWidgets.QDoubleSpinBox()
        self.psi_input = QtWidgets.QDoubleSpinBox()
        for w in (self.x_input, self.y_input, self.z_input, self.psi_input):
            w.setMinimumWidth(90)
            w.setMinimumHeight(28)
        for w in (self.x_input, self.y_input, self.z_input):
            w.setRange(-1000, 1000)
            w.setDecimals(1)
            w.setSuffix(" mm")
        self.psi_input.setRange(-360, 360)
        self.psi_input.setSuffix(" deg")
        self.z_input.setValue(200.0)
        self.x_input.setValue(300.0)

        self.elbow_up = QtWidgets.QRadioButton("Elbow up")
        self.elbow_down = QtWidgets.QRadioButton("Elbow down")
        self.elbow_up.setChecked(True)
        elbow_group = QtWidgets.QButtonGroup(self)
        elbow_group.addButton(self.elbow_up)
        elbow_group.addButton(self.elbow_down)

        solve_btn = QtWidgets.QPushButton("Solve IK")
        solve_btn.setMinimumHeight(32)
        solve_btn.clicked.connect(self._on_solve_ik)

        preset_row = QtWidgets.QHBoxLayout()
        preset_row.setSpacing(8)
        for name in config.PSI_PRESETS:
            btn = QtWidgets.QPushButton(f"Auto: {name}")
            btn.setMinimumHeight(30)
            btn.setMinimumWidth(110)
            btn.setToolTip(
                f"Finds the psi nearest to the '{name}' preset "
                f"({config.PSI_PRESETS[name]:.0f} deg) that satisfies joint limits "
                "on either elbow branch, sets it, and solves."
            )
            btn.clicked.connect(lambda checked, n=name: self._on_preset_psi(n))
            preset_row.addWidget(btn)

        self.ik_status = QtWidgets.QLabel("")
        self.ik_status.setWordWrap(True)
        self.ik_status.setMinimumHeight(60)

        layout.addWidget(QtWidgets.QLabel("X"), 0, 0)
        layout.addWidget(self.x_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Y"), 0, 2)
        layout.addWidget(self.y_input, 0, 3)
        layout.addWidget(QtWidgets.QLabel("Z"), 1, 0)
        layout.addWidget(self.z_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("Tool angle ψ"), 1, 2)
        layout.addWidget(self.psi_input, 1, 3)
        layout.addWidget(self.elbow_up, 2, 0, 1, 2)
        layout.addWidget(self.elbow_down, 2, 2, 1, 2)
        layout.addLayout(preset_row, 3, 0, 1, 4)
        layout.addWidget(solve_btn, 4, 0, 1, 4)
        layout.addWidget(self.ik_status, 5, 0, 1, 4)

        return box

    def _build_calibration_panel(self):
        box = QtWidgets.QGroupBox("Home Offset Calibration (plan §5.4)")
        box.setMinimumWidth(480)
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.offset_inputs = []
        offsets = config.load_home_offsets()
        for i, name in enumerate(config.AXIS_LABELS):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-360, 360)
            spin.setDecimals(2)
            spin.setValue(offsets[i])
            spin.setMinimumWidth(90)
            spin.setMinimumHeight(28)
            label = QtWidgets.QLabel(name)
            label.setMinimumWidth(140)
            layout.addWidget(label, i, 0)
            layout.addWidget(spin, i, 1)
            self.offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offsets")
        save_btn.setMinimumHeight(30)
        save_btn.clicked.connect(self._on_save_offsets)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.setMinimumHeight(30)
        reload_btn.clicked.connect(self._on_reload_offsets)
        layout.addWidget(save_btn, len(config.AXIS_LABELS), 0)
        layout.addWidget(reload_btn, len(config.AXIS_LABELS), 1)

        note = QtWidgets.QLabel(
            "Not yet measured on physical hardware (open item). Jog each joint to a\n"
            "known reference pose on the real arm, read the DH-solved angle above,\n"
            "and enter the difference here."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, len(config.AXIS_LABELS) + 1, 0, 1, 2)

        return box

    # -- waypoint path tab -------------------------------------------------

    def _build_waypoint_tab(self):
        tab = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(tab)
        col.setSpacing(10)

        # --- waypoint table ---
        table_box = QtWidgets.QGroupBox("Waypoints (X, Y, Z mm; ψ deg)")
        table_layout = QtWidgets.QVBoxLayout(table_box)
        self.wp_table = QtWidgets.QTableWidget(0, 4)
        self.wp_table.setHorizontalHeaderLabels(["X", "Y", "Z", "ψ"])
        self.wp_table.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.Stretch)
        self.wp_table.setMinimumHeight(160)
        table_layout.addWidget(self.wp_table)

        row_btns = QtWidgets.QHBoxLayout()
        add_btn = QtWidgets.QPushButton("Add row")
        add_btn.clicked.connect(self._on_wp_add_row)
        add_current_btn = QtWidgets.QPushButton("Add current pose")
        add_current_btn.setToolTip("Adds the current target-pose X/Y/Z/ψ from the Single Pose tab.")
        add_current_btn.clicked.connect(self._on_wp_add_current)
        del_btn = QtWidgets.QPushButton("Delete row")
        del_btn.clicked.connect(self._on_wp_delete_row)
        clear_btn = QtWidgets.QPushButton("Clear")
        clear_btn.clicked.connect(lambda: self.wp_table.setRowCount(0))
        for b in (add_btn, add_current_btn, del_btn, clear_btn):
            b.setMinimumHeight(28)
            row_btns.addWidget(b)
        table_layout.addLayout(row_btns)
        col.addWidget(table_box)

        # --- primitive generators ---
        gen_box = QtWidgets.QGroupBox("Generate a path")
        gen_layout = QtWidgets.QGridLayout(gen_box)
        gen_layout.setHorizontalSpacing(10)
        gen_layout.setVerticalSpacing(8)

        line_btn = QtWidgets.QPushButton("Line sweep")
        line_btn.setToolTip("Straight line from the first waypoint to the last one in the table.")
        line_btn.setMinimumHeight(28)
        line_btn.clicked.connect(self._on_gen_line)

        circle_btn = QtWidgets.QPushButton("Circle")
        circle_btn.setToolTip("Circle centered on the first waypoint in the table, in the chosen plane.")
        circle_btn.setMinimumHeight(28)
        circle_btn.clicked.connect(self._on_gen_circle)

        self.circle_radius = QtWidgets.QDoubleSpinBox()
        self.circle_radius.setRange(1, 500)
        self.circle_radius.setValue(40)
        self.circle_radius.setSuffix(" mm")
        self.circle_radius.setMinimumHeight(28)

        self.circle_plane = QtWidgets.QComboBox()
        self.circle_plane.addItems(["xy", "xz", "yz"])
        self.circle_plane.setCurrentText("xz")
        self.circle_plane.setMinimumHeight(28)

        gen_layout.addWidget(line_btn, 0, 0)
        gen_layout.addWidget(QtWidgets.QLabel("(uses first + last waypoint)"), 0, 1, 1, 3)
        gen_layout.addWidget(circle_btn, 1, 0)
        gen_layout.addWidget(QtWidgets.QLabel("r"), 1, 1)
        gen_layout.addWidget(self.circle_radius, 1, 2)
        gen_layout.addWidget(self.circle_plane, 1, 3)
        col.addWidget(gen_box)

        # --- planning + run controls ---
        run_box = QtWidgets.QGroupBox("Plan & run")
        run_layout = QtWidgets.QGridLayout(run_box)
        run_layout.setHorizontalSpacing(10)
        run_layout.setVerticalSpacing(8)

        self.wp_auto_psi = QtWidgets.QCheckBox("Auto-adjust ψ into joint limits per point")
        self.wp_auto_psi.setChecked(True)

        self.wp_elbow = QtWidgets.QComboBox()
        self.wp_elbow.addItems(["up", "down"])

        self.wp_segment = QtWidgets.QDoubleSpinBox()
        self.wp_segment.setRange(0.5, 50)
        self.wp_segment.setValue(5.0)
        self.wp_segment.setSuffix(" mm/seg")
        self.wp_segment.setToolTip(
            "Max segment length. Smaller = smoother motion (grbl blends short "
            "moves) but more commands to stream.")

        self.wp_feed = QtWidgets.QDoubleSpinBox()
        self.wp_feed.setRange(1, 20000)
        self.wp_feed.setValue(config.SAFE_FEED_DEG_PER_MIN)
        self.wp_feed.setSuffix(" deg/min")

        for w in (self.wp_elbow, self.wp_segment, self.wp_feed):
            w.setMinimumHeight(28)

        simulate_btn = QtWidgets.QPushButton("Simulate (no hardware)")
        simulate_btn.setMinimumHeight(32)
        simulate_btn.clicked.connect(self._on_wp_simulate)

        self.wp_run_btn = QtWidgets.QPushButton("Run on Arm")
        self.wp_run_btn.setMinimumHeight(32)
        self.wp_run_btn.setStyleSheet("font-weight: bold;")
        self.wp_run_btn.clicked.connect(self._on_wp_run)

        self.wp_abort_btn = QtWidgets.QPushButton("ABORT (feed hold)")
        self.wp_abort_btn.setMinimumHeight(32)
        self.wp_abort_btn.setStyleSheet("color: darkred; font-weight: bold;")
        self.wp_abort_btn.setEnabled(False)
        self.wp_abort_btn.clicked.connect(self._on_wp_abort)

        self.wp_progress = QtWidgets.QProgressBar()
        self.wp_status = QtWidgets.QLabel("")
        self.wp_status.setWordWrap(True)
        self.wp_status.setMinimumHeight(40)

        run_layout.addWidget(self.wp_auto_psi, 0, 0, 1, 4)
        run_layout.addWidget(QtWidgets.QLabel("Elbow"), 1, 0)
        run_layout.addWidget(self.wp_elbow, 1, 1)
        run_layout.addWidget(self.wp_segment, 1, 2)
        run_layout.addWidget(self.wp_feed, 1, 3)
        run_layout.addWidget(simulate_btn, 2, 0, 1, 2)
        run_layout.addWidget(self.wp_run_btn, 2, 2)
        run_layout.addWidget(self.wp_abort_btn, 2, 3)
        run_layout.addWidget(self.wp_progress, 3, 0, 1, 4)
        run_layout.addWidget(self.wp_status, 4, 0, 1, 4)
        col.addWidget(run_box)

        col.addStretch(1)

        self._wp_plan = None       # cached last successful plan
        self._wp_worker = None
        return tab

    def _read_waypoints(self):
        """Read the table into a list of (x, y, z, psi) tuples. Blank/invalid rows raise."""
        poses = []
        for r in range(self.wp_table.rowCount()):
            vals = []
            for c in range(4):
                item = self.wp_table.item(r, c)
                if item is None or not item.text().strip():
                    raise ValueError(f"Row {r + 1} has an empty cell.")
                vals.append(float(item.text()))
            poses.append(tuple(vals))
        return poses

    def _set_waypoints(self, poses):
        self.wp_table.setRowCount(len(poses))
        for r, (x, y, z, psi) in enumerate(poses):
            for c, v in enumerate((x, y, z, psi)):
                self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_add_row(self):
        r = self.wp_table.rowCount()
        self.wp_table.insertRow(r)
        for c, v in enumerate((250.0, 0.0, 300.0, 0.0)):
            self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_add_current(self):
        r = self.wp_table.rowCount()
        self.wp_table.insertRow(r)
        vals = (self.x_input.value(), self.y_input.value(),
                self.z_input.value(), self.psi_input.value())
        for c, v in enumerate(vals):
            self.wp_table.setItem(r, c, QtWidgets.QTableWidgetItem(f"{v:.1f}"))

    def _on_wp_delete_row(self):
        r = self.wp_table.currentRow()
        if r >= 0:
            self.wp_table.removeRow(r)

    def _on_gen_line(self):
        try:
            poses = self._read_waypoints()
        except ValueError as e:
            self._wp_set_status(str(e), error=True)
            return
        if len(poses) < 2:
            self._wp_set_status("Need at least 2 waypoints (start + end) for a line sweep.", error=True)
            return
        start = poses[0][:3]
        end = poses[-1][:3]
        psi = poses[0][3]
        self._set_waypoints(kinematics.line_sweep(start, end, psi, num_waypoints=2))
        self._wp_set_status("Generated a line sweep from the first to the last waypoint.")

    def _on_gen_circle(self):
        try:
            poses = self._read_waypoints()
        except ValueError as e:
            self._wp_set_status(str(e), error=True)
            return
        if not poses:
            self._wp_set_status("Add at least one waypoint to use as the circle center.", error=True)
            return
        center = poses[0][:3]
        psi = poses[0][3]
        circle = kinematics.circle_path(center, self.circle_radius.value(), psi,
                                         plane=self.circle_plane.currentText(),
                                         num_waypoints=48)
        self._set_waypoints(circle)
        self._wp_set_status(
            f"Generated a {self.circle_plane.currentText()} circle of r="
            f"{self.circle_radius.value():.0f}mm around the first waypoint.")

    def _plan_current_path(self):
        poses = self._read_waypoints()
        if len(poses) < 2:
            raise ValueError("Need at least 2 waypoints to run a path.")
        return kinematics.plan_waypoint_path(
            poses,
            prefer_elbow=self.wp_elbow.currentText(),
            max_segment_mm=self.wp_segment.value(),
            auto_psi=self.wp_auto_psi.isChecked(),
        )

    def _on_wp_simulate(self):
        try:
            plan = self._plan_current_path()
        except (ValueError, kinematics.PathPlanningError) as e:
            self._wp_set_status(str(e), error=True)
            return

        self._wp_plan = plan
        path_xyz = [p[:3] for p in plan["dense_poses"]]
        self._wp_set_status(
            f"Planned {len(plan['thetas'])} points, all within joint limits. "
            "Animating in the 3D view (no hardware commands sent).")

        # Animate through the poses with a QTimer so the GUI stays responsive.
        self._sim_index = 0
        self._sim_thetas = plan["thetas"]
        self._sim_path = path_xyz
        if not hasattr(self, "_sim_timer"):
            self._sim_timer = QtCore.QTimer(self)
            self._sim_timer.timeout.connect(self._sim_step)
        self._sim_timer.start(40)

    def _sim_step(self):
        if self._sim_index >= len(self._sim_thetas):
            self._sim_timer.stop()
            return
        thetas = self._sim_thetas[self._sim_index]
        self.canvas.plot_pose(thetas, path_xyz=self._sim_path)
        self._sim_index += 1

    def _on_wp_run(self):
        if not self.bridge.is_connected():
            self._wp_set_status("Not connected to the arm. Connect in the Serial Bridge panel first.", error=True)
            return
        try:
            plan = self._plan_current_path()
        except (ValueError, kinematics.PathPlanningError) as e:
            self._wp_set_status(str(e), error=True)
            return

        # Build the G-code list: home-offset each solved pose, then a move line.
        feed = self.wp_feed.value()
        lines = []
        for thetas in plan["thetas"]:
            motor = kinematics.apply_home_offset(thetas)
            lines.append(self.bridge.build_move_gcode(motor, feed_deg_per_min=feed))

        self._wp_plan = plan
        self.wp_progress.setMaximum(len(lines))
        self.wp_progress.setValue(0)
        self._wp_set_status(f"Streaming {len(lines)} moves to the arm…")

        self.wp_run_btn.setEnabled(False)
        self.wp_abort_btn.setEnabled(True)

        self._wp_worker = PathStreamWorker(self.bridge, lines, feed)
        self._wp_worker.progress.connect(self._on_wp_progress)
        self._wp_worker.finished_streaming.connect(self._on_wp_finished)
        self._wp_worker.error.connect(self._on_wp_error)
        self._wp_worker.start()

    def _on_wp_progress(self, index, total):
        self.wp_progress.setValue(index)

    def _on_wp_finished(self, sent, aborted):
        self.wp_run_btn.setEnabled(True)
        self.wp_abort_btn.setEnabled(False)
        if aborted:
            self._wp_set_status(
                f"Aborted after {sent} moves (feed-hold sent). Send Resume (~) or "
                "Soft Reset from the Serial Bridge panel to clear the hold.", error=True)
        else:
            self._wp_set_status(f"Path complete — {sent} moves sent.")

    def _on_wp_error(self, msg):
        self.wp_run_btn.setEnabled(True)
        self.wp_abort_btn.setEnabled(False)
        self._wp_set_status(f"Streaming error: {msg}", error=True)

    def _on_wp_abort(self):
        if self._wp_worker is not None and self._wp_worker.isRunning():
            self._wp_worker.request_abort()
            self._wp_set_status("Abort requested — sending feed-hold…", error=True)

    def _wp_set_status(self, text, error=False):
        self.wp_status.setText(text)
        self.wp_status.setStyleSheet("color: red;" if error else "color: green;")

    def _build_serial_panel(self):
        box = QtWidgets.QGroupBox("Serial Bridge (gcobos/grbl4axis)")
        layout = QtWidgets.QGridLayout(box)
        layout.setHorizontalSpacing(10)
        layout.setVerticalSpacing(8)
        layout.setContentsMargins(12, 16, 12, 12)

        self.port_combo = QtWidgets.QComboBox()
        refresh_btn = QtWidgets.QPushButton("Refresh")
        refresh_btn.clicked.connect(self._refresh_ports)

        self.baud_input = QtWidgets.QSpinBox()
        self.baud_input.setRange(1200, 921600)
        self.baud_input.setValue(config.DEFAULT_BAUD)

        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.connect_btn.clicked.connect(self._on_connect_toggle)

        setup_btn = QtWidgets.QPushButton("Push $100-$103 Settings (one-time setup)")
        setup_btn.clicked.connect(self._on_push_settings)

        unlock_btn = QtWidgets.QPushButton("Unlock ($X)")
        unlock_btn.clicked.connect(self._on_unlock)

        status_btn = QtWidgets.QPushButton("Status (?)")
        status_btn.clicked.connect(self._on_status)

        hold_btn = QtWidgets.QPushButton("Feed Hold (!)")
        hold_btn.clicked.connect(self._on_feed_hold)

        resume_btn = QtWidgets.QPushButton("Resume (~)")
        resume_btn.clicked.connect(self._on_resume)

        reset_btn = QtWidgets.QPushButton("Soft Reset")
        reset_btn.setStyleSheet("color: darkred;")
        reset_btn.clicked.connect(self._on_soft_reset)

        self.feed_input = QtWidgets.QDoubleSpinBox()
        self.feed_input.setRange(1, 20000)
        self.feed_input.setValue(config.DEFAULT_FEED_DEG_PER_MIN)
        self.feed_input.setSuffix(" deg/min")

        wrist_feed_btn = QtWidgets.QPushButton("Wrist-safe feed")
        wrist_feed_btn.setToolTip(
            f"Sets feed rate to {config.WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min — scaled from the "
            f"{config.SAFE_FEED_DEG_PER_MIN:.0f} deg/min bench finding to match the wrist's 6:1 "
            "gearing (vs. 36:1 for the other joints), so it lands in roughly the same real step-rate "
            "range. Use this before a wrist-only move."
        )
        wrist_feed_btn.clicked.connect(self._on_use_wrist_safe_feed)

        self.rapid_checkbox = QtWidgets.QCheckBox("Use rapid (G0) instead of feed-rate (G1)")

        send_btn = QtWidgets.QPushButton("Send Current Pose to Grbl")
        send_btn.clicked.connect(self._on_send_pose)

        self.status_label = QtWidgets.QLabel("(no status yet)")
        self.status_label.setStyleSheet("font-family: monospace;")

        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(180)
        self.log.setMinimumHeight(140)

        layout.addWidget(QtWidgets.QLabel("Port"), 0, 0)
        layout.addWidget(self.port_combo, 0, 1)
        layout.addWidget(refresh_btn, 0, 2)
        layout.addWidget(QtWidgets.QLabel("Baud"), 0, 3)
        layout.addWidget(self.baud_input, 0, 4)
        layout.addWidget(self.connect_btn, 0, 5)

        layout.addWidget(setup_btn, 1, 0, 1, 2)
        layout.addWidget(unlock_btn, 1, 2)
        layout.addWidget(status_btn, 1, 3)
        layout.addWidget(hold_btn, 1, 4)
        layout.addWidget(resume_btn, 1, 5)

        layout.addWidget(QtWidgets.QLabel("Feed rate"), 2, 0)
        layout.addWidget(self.feed_input, 2, 1)
        layout.addWidget(wrist_feed_btn, 2, 2)
        layout.addWidget(self.rapid_checkbox, 2, 3, 1, 1)
        layout.addWidget(reset_btn, 2, 4)
        layout.addWidget(send_btn, 2, 5)

        layout.addWidget(QtWidgets.QLabel("Last status:"), 3, 0)
        layout.addWidget(self.status_label, 3, 1, 1, 5)

        layout.addWidget(self.log, 4, 0, 1, 6)

        self.raw_input = QtWidgets.QLineEdit()
        self.raw_input.setPlaceholderText("Raw command, e.g. $$  or  $110=3000  (Enter to send)")
        self.raw_input.returnPressed.connect(self._on_send_raw)
        raw_send_btn = QtWidgets.QPushButton("Send Raw")
        raw_send_btn.clicked.connect(self._on_send_raw)

        layout.addWidget(QtWidgets.QLabel("Raw cmd"), 5, 0)
        layout.addWidget(self.raw_input, 5, 1, 1, 4)
        layout.addWidget(raw_send_btn, 5, 5)

        note = QtWidgets.QLabel(
            f"First time connecting to a fresh grbl4axis board? Click 'Push $100-$103 Settings' once "
            f"(persists in EEPROM). If moves are rejected with an ALARM message, click 'Unlock'. "
            f"Use the 'Raw cmd' box for anything else — e.g. type $$ and press Enter to dump all "
            f"current grbl settings (including $110-$113 max rate and $120-$123 acceleration). "
            f"Default feed rate is {config.SAFE_FEED_DEG_PER_MIN:.0f} deg/min, found on the bench to "
            f"clear up full-step resonance buzz on the 36:1 joints — click 'Wrist-safe feed' before a "
            f"wrist-only move since its gearing needs a different number for the same real speed."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        layout.addWidget(note, 6, 0, 1, 6)

        # Consistent minimum sizing across every control in this panel so
        # buttons/fields don't get crushed when the window is resized.
        for btn in box.findChildren(QtWidgets.QPushButton):
            btn.setMinimumHeight(30)
        for field in box.findChildren(QtWidgets.QComboBox):
            field.setMinimumHeight(28)
        for field in box.findChildren(QtWidgets.QSpinBox):
            field.setMinimumHeight(28)
        for field in box.findChildren(QtWidgets.QDoubleSpinBox):
            field.setMinimumHeight(28)
        for field in box.findChildren(QtWidgets.QLineEdit):
            field.setMinimumHeight(28)
        self.raw_input.setMinimumWidth(200)

        return box

    # -- behavior ------------------------------------------------------------

    def _log(self, msg):
        self.log.appendPlainText(msg)

    def _refresh_ports(self):
        self.port_combo.clear()
        for device, desc in serial_bridge.SerialBridge.list_ports():
            self.port_combo.addItem(f"{device} — {desc}", userData=device)
        if self.port_combo.count() == 0:
            self.port_combo.addItem("(no ports found)", userData=None)

    def _on_connect_toggle(self):
        if self.bridge.is_connected():
            self.bridge.disconnect()
            self.connect_btn.setText("Connect")
            self._log("Disconnected.")
            return

        port = self.port_combo.currentData()
        if not port:
            self._log("No serial port selected.")
            return
        try:
            self.bridge.connect(port, self.baud_input.value())
            self.connect_btn.setText("Disconnect")
            self._log(f"Connected to {port} @ {self.baud_input.value()} baud.")
            if self.bridge.startup_banner:
                for line in self.bridge.startup_banner:
                    self._log(f"  <- {line}")
            else:
                self._log("  (no startup banner seen — grbl may already be running, or baud is wrong)")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Connection failed: {e}")

    def _on_jog_changed(self):
        self.current_thetas = [s.value() for s in self.joint_sliders]
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       self.current_thetas):
            label.setText(f"{name}: {theta:.1f}°")
        self.last_target_xyz = None
        self.canvas.plot_pose(self.current_thetas)

    def _on_solve_ik(self):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        psi = self.psi_input.value()
        prefer_elbow = "up" if self.elbow_up.isChecked() else "down"

        try:
            result = kinematics.solve_ik_constrained(x, y, z, psi, prefer_elbow=prefer_elbow)
        except kinematics.IKUnreachableError as e:
            self.ik_status.setText(str(e))
            self.ik_status.setStyleSheet("color: red;")
            return

        thetas = result["thetas"]
        violations = result["violations"]
        ok, residual = kinematics.verify_ik(thetas, (x, y, z))

        # Reflect whichever branch was actually used, so the radio buttons
        # never silently disagree with what's on the sliders.
        if result["elbow_used"] == "up":
            self.elbow_up.setChecked(True)
        else:
            self.elbow_down.setChecked(True)

        # Push solved angles onto the sliders (blocking signals to avoid
        # feedback loops, then update once manually).
        for slider, theta in zip(self.joint_sliders, thetas):
            slider.blockSignals(True)
            slider.setValue(int(round(theta)))
            slider.blockSignals(False)

        self.current_thetas = list(thetas)
        self.last_target_xyz = (x, y, z)
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       thetas):
            label.setText(f"{name}: {theta:.1f}°")

        self.canvas.plot_pose(thetas, target_xyz=(x, y, z))

        status_lines = [f"Solved θ = [{', '.join(f'{t:.1f}°' for t in thetas)}]",
                         f"FK residual: {residual:.2f} mm"]
        if result["elbow_switched"]:
            status_lines.append(
                f"Auto-switched to elbow-{result['elbow_used']} "
                f"(elbow-{prefer_elbow} was requested but violated a joint limit)."
            )
        if violations:
            status_lines.append(
                "UNREACHABLE WITHIN LIMITS on either elbow branch (measured hardware "
                "limits): "
                + "; ".join(f"joint {i} = {t:.1f}° (limit {lo}..{hi})" for i, t, lo, hi in violations)
            )
        self.ik_status.setText("\n".join(status_lines))
        self.ik_status.setStyleSheet("color: red;" if violations else "color: green;")

    def _on_preset_psi(self, preset_name):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        prefer_elbow = "up" if self.elbow_up.isChecked() else "down"
        base_psi = config.PSI_PRESETS[preset_name]

        result = kinematics.find_feasible_psi(x, y, z, base_psi, prefer_elbow=prefer_elbow)
        if result is None:
            self.ik_status.setText(
                f"No feasible tool angle found near '{preset_name}' "
                f"({base_psi:.0f} deg) within +/-178 deg search -- target may be out of reach entirely."
            )
            self.ik_status.setStyleSheet("color: red;")
            return

        self.psi_input.setValue(result["psi_used"])
        self._on_solve_ik()

        offset = result["offset_from_base_deg"]
        if abs(offset) < 0.05:
            note = f"'{preset_name}' preset used exactly ({base_psi:.0f} deg)."
        else:
            note = (
                f"'{preset_name}' exact ({base_psi:.0f} deg) violated a joint limit -- "
                f"used nearest feasible tilt instead: {result['psi_used']:.1f} deg "
                f"({offset:+.1f} deg from preset)."
            )
        self.ik_status.setText(note + "\n" + self.ik_status.text())

    def _on_save_offsets(self):
        offsets = [w.value() for w in self.offset_inputs]
        config.save_home_offsets(offsets)
        self._log(f"Saved home offsets: {offsets}")

    def _on_reload_offsets(self):
        offsets = config.load_home_offsets()
        for w, v in zip(self.offset_inputs, offsets):
            w.setValue(v)
        self._log("Reloaded home offsets from disk.")

    def _on_push_settings(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log("Pushing $100-$103 steps/degree settings...")
        try:
            results = self.bridge.push_steps_per_unit_settings()
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Settings push failed: {e}")
            return
        for setting, value, response in results:
            self._log(f"  {setting}={value:.4f}  -> {', '.join(response)}")
        self._log("Done. These persist in grbl's EEPROM across power cycles.")

    def _on_unlock(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        try:
            response = self.bridge.unlock()
            self._log(f"$X -> {', '.join(response)}")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Unlock failed: {e}")

    def _on_send_raw(self):
        line = self.raw_input.text().strip()
        if not line:
            return
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log(f"Sending raw: {line}")
        try:
            response = self.bridge.send_raw(line)
            for r in response:
                self._log(f"  <- {r}")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Raw send failed: {e}")
        finally:
            self.raw_input.clear()

    def _on_use_wrist_safe_feed(self):
        self.feed_input.setValue(config.WRIST_SAFE_FEED_DEG_PER_MIN)
        self._log(
            f"Feed rate set to {config.WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min "
            "(wrist-safe — scaled from the bench-tested 36:1-joint value for the wrist's 6:1 gearing)."
        )

    def _on_status(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        status = self.bridge.request_status()
        if status:
            self.status_label.setText(status)
            self._log(f"Status: {status}")
        else:
            self._log("No status response received (older grbl builds may not support '?').")

    def _on_feed_hold(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.feed_hold()
        self._log("Sent feed hold (!).")

    def _on_resume(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.cycle_start_resume()
        self._log("Sent cycle start/resume (~).")

    def _on_soft_reset(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.soft_reset()
        self._log("Sent soft reset (Ctrl-X). Grbl will reprint its startup banner.")

    def _on_send_pose(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return

        offsets = [w.value() for w in self.offset_inputs]
        motor_angles = kinematics.apply_home_offset(self.current_thetas, offsets)
        rapid = self.rapid_checkbox.isChecked()
        feed = self.feed_input.value()

        line = self.bridge.build_move_gcode(motor_angles, feed_deg_per_min=feed, rapid=rapid)
        est_steps = kinematics.estimated_steps_for_display(self.current_thetas, offsets)
        self._log(f"Sending: {line}")
        self._log(f"  (thetas {[round(t,1) for t in self.current_thetas]}, "
                   f"est. steps {est_steps} — for reference only, not sent)")
        try:
            response = self.bridge.send_line(line)
        except serial_bridge.GrblAlarmError as e:
            self._log(f"ALARM: {e}")
            self._log("  -> Click 'Unlock ($X)' and try again.")
            return
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Send failed: {e}")
            return
        for resp_line in response:
            self._log(f"  <- {resp_line}")

    def _update_pose(self, send=False):
        self.canvas.plot_pose(self.current_thetas, self.last_target_xyz)


def main():
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
