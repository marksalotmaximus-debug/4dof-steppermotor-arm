"""
gui.py

PyQt5 desktop app tying together kinematics.py and serial_bridge.py.

Layout:
  Left column:
    - Joint jog sliders (theta1..theta4) with live degree readout
    - Target pose panel (X, Y, Z, psi, elbow up/down) + "Solve IK" button
    - Home offset calibration panel (4 fields, Save/Reload)
  Right column:
    - Live 3D plot of the arm (matplotlib, driven by forward_kinematics())
  Bottom:
    - Serial connection panel: port dropdown, connect/disconnect, one-time
      $100-$103 grbl settings push, unlock/status/feed-hold/resume/soft-reset,
      feed-rate input, and "Send Current Pose to Grbl" (real G-code, not
      raw step counts — see serial_bridge.py)

Run via main.py.
"""

import sys

import numpy as np
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

import config
import kinematics
import serial_bridge


class Arm3DCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(5, 5))
        super().__init__(fig)
        self.setParent(parent)
        self.ax = fig.add_subplot(111, projection="3d")
        self._reach = sum(p["a"] for p in config.DH_PARAMS) + 50
        self.plot_pose([0, 0, 0, 0])

    def plot_pose(self, thetas_deg, target_xyz=None):
        positions, _ = kinematics.forward_kinematics(thetas_deg)
        pts = np.array(positions)

        self.ax.clear()
        # Arm links
        self.ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], "-o", color="#2a6fdb",
                     linewidth=3, markersize=6, markerfacecolor="#ff6a3d")
        # Base marker
        self.ax.scatter([0], [0], [0], color="black", s=40, marker="s")

        if target_xyz is not None:
            self.ax.scatter([target_xyz[0]], [target_xyz[1]], [target_xyz[2]],
                             color="green", s=60, marker="*", label="target")
            self.ax.legend(loc="upper left", fontsize=8)

        r = self._reach
        self.ax.set_xlim(-r, r)
        self.ax.set_ylim(-r, r)
        self.ax.set_zlim(0, 2 * r)
        self.ax.set_xlabel("X (mm)")
        self.ax.set_ylabel("Y (mm)")
        self.ax.set_zlabel("Z (mm)")
        self.ax.set_title("4-DOF arm — live DH pose")
        self.draw()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4-DOF Arm Control")
        self.resize(1200, 750)

        self.bridge = serial_bridge.SerialBridge()
        self.current_thetas = [0.0, 0.0, 0.0, 0.0]
        self.last_target_xyz = None

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root_layout = QtWidgets.QVBoxLayout(central)

        top_layout = QtWidgets.QHBoxLayout()
        root_layout.addLayout(top_layout, stretch=1)

        left_col = QtWidgets.QVBoxLayout()
        top_layout.addLayout(left_col, stretch=0)

        self.canvas = Arm3DCanvas(self)
        top_layout.addWidget(self.canvas, stretch=1)

        left_col.addWidget(self._build_jog_panel())
        left_col.addWidget(self._build_ik_panel())
        left_col.addWidget(self._build_calibration_panel())
        left_col.addStretch(1)

        root_layout.addWidget(self._build_serial_panel(), stretch=0)

        self._refresh_ports()
        self._update_pose(send=False)

    # -- panels ------------------------------------------------------------

    def _build_jog_panel(self):
        box = QtWidgets.QGroupBox("Joint Jog (degrees)")
        layout = QtWidgets.QGridLayout(box)

        self.joint_sliders = []
        self.joint_labels = []
        names = ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"]
        for i, name in enumerate(names):
            lo, hi = config.JOINT_LIMITS_DEG[i]
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setMinimum(int(lo))
            slider.setMaximum(int(hi))
            slider.setValue(0)
            slider.valueChanged.connect(self._on_jog_changed)

            label = QtWidgets.QLabel(f"{name}: 0.0°")
            layout.addWidget(label, i, 0)
            layout.addWidget(slider, i, 1)
            self.joint_sliders.append(slider)
            self.joint_labels.append(label)

        return box

    def _build_ik_panel(self):
        box = QtWidgets.QGroupBox("Target Pose (Inverse Kinematics)")
        layout = QtWidgets.QGridLayout(box)

        self.x_input = QtWidgets.QDoubleSpinBox()
        self.y_input = QtWidgets.QDoubleSpinBox()
        self.z_input = QtWidgets.QDoubleSpinBox()
        self.psi_input = QtWidgets.QDoubleSpinBox()
        for w in (self.x_input, self.y_input, self.z_input):
            w.setRange(-1000, 1000)
            w.setDecimals(1)
            w.setSuffix(" mm")
        self.psi_input.setRange(-360, 360)
        self.psi_input.setSuffix(" deg")
        self.z_input.setValue(200.0)
        self.x_input.setValue(300.0)

        self.elbow_up = QtWidgets.QRadioButton("Elbow up")
        self.elbow_down = QtWidgets.QRadioButton("Elbow down")
        self.elbow_up.setChecked(True)
        elbow_group = QtWidgets.QButtonGroup(self)
        elbow_group.addButton(self.elbow_up)
        elbow_group.addButton(self.elbow_down)

        solve_btn = QtWidgets.QPushButton("Solve IK")
        solve_btn.clicked.connect(self._on_solve_ik)

        self.ik_status = QtWidgets.QLabel("")
        self.ik_status.setWordWrap(True)

        layout.addWidget(QtWidgets.QLabel("X"), 0, 0)
        layout.addWidget(self.x_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Y"), 0, 2)
        layout.addWidget(self.y_input, 0, 3)
        layout.addWidget(QtWidgets.QLabel("Z"), 1, 0)
        layout.addWidget(self.z_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("Tool angle ψ"), 1, 2)
        layout.addWidget(self.psi_input, 1, 3)
        layout.addWidget(self.elbow_up, 2, 0, 1, 2)
        layout.addWidget(self.elbow_down, 2, 2, 1, 2)
        layout.addWidget(solve_btn, 3, 0, 1, 4)
        layout.addWidget(self.ik_status, 4, 0, 1, 4)

        return box

    def _build_calibration_panel(self):
        box = QtWidgets.QGroupBox("Home Offset Calibration (plan §5.4)")
        layout = QtWidgets.QGridLayout(box)

        self.offset_inputs = []
        offsets = config.load_home_offsets()
        for i, name in enumerate(config.AXIS_LABELS):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-360, 360)
            spin.setDecimals(2)
            spin.setValue(offsets[i])
            layout.addWidget(QtWidgets.QLabel(name), i, 0)
            layout.addWidget(spin, i, 1)
            self.offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offsets")
        save_btn.clicked.connect(self._on_save_offsets)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.clicked.connect(self._on_reload_offsets)
        layout.addWidget(save_btn, len(config.AXIS_LABELS), 0)
        layout.addWidget(reload_btn, len(config.AXIS_LABELS), 1)

        note = QtWidgets.QLabel(
            "Not yet measured on physical hardware (open item). Jog each joint to a\n"
            "known reference pose on the real arm, read the DH-solved angle above,\n"
            "and enter the difference here."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, len(config.AXIS_LABELS) + 1, 0, 1, 2)

        return box

    def _build_serial_panel(self):
        box = QtWidgets.QGroupBox("Serial Bridge (gcobos/grbl4axis)")
        layout = QtWidgets.QGridLayout(box)

        self.port_combo = QtWidgets.QComboBox()
        refresh_btn = QtWidgets.QPushButton("Refresh")
        refresh_btn.clicked.connect(self._refresh_ports)

        self.baud_input = QtWidgets.QSpinBox()
        self.baud_input.setRange(1200, 921600)
        self.baud_input.setValue(config.DEFAULT_BAUD)

        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.connect_btn.clicked.connect(self._on_connect_toggle)

        setup_btn = QtWidgets.QPushButton("Push $100-$103 Settings (one-time setup)")
        setup_btn.clicked.connect(self._on_push_settings)

        unlock_btn = QtWidgets.QPushButton("Unlock ($X)")
        unlock_btn.clicked.connect(self._on_unlock)

        status_btn = QtWidgets.QPushButton("Status (?)")
        status_btn.clicked.connect(self._on_status)

        hold_btn = QtWidgets.QPushButton("Feed Hold (!)")
        hold_btn.clicked.connect(self._on_feed_hold)

        resume_btn = QtWidgets.QPushButton("Resume (~)")
        resume_btn.clicked.connect(self._on_resume)

        reset_btn = QtWidgets.QPushButton("Soft Reset")
        reset_btn.setStyleSheet("color: darkred;")
        reset_btn.clicked.connect(self._on_soft_reset)

        self.feed_input = QtWidgets.QDoubleSpinBox()
        self.feed_input.setRange(1, 20000)
        self.feed_input.setValue(config.DEFAULT_FEED_DEG_PER_MIN)
        self.feed_input.setSuffix(" deg/min")

        wrist_feed_btn = QtWidgets.QPushButton("Wrist-safe feed")
        wrist_feed_btn.setToolTip(
            f"Sets feed rate to {config.WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min — scaled from the "
            f"{config.SAFE_FEED_DEG_PER_MIN:.0f} deg/min bench finding to match the wrist's 6:1 "
            "gearing (vs. 36:1 for the other joints), so it lands in roughly the same real step-rate "
            "range. Use this before a wrist-only move."
        )
        wrist_feed_btn.clicked.connect(self._on_use_wrist_safe_feed)

        self.rapid_checkbox = QtWidgets.QCheckBox("Use rapid (G0) instead of feed-rate (G1)")

        send_btn = QtWidgets.QPushButton("Send Current Pose to Grbl")
        send_btn.clicked.connect(self._on_send_pose)

        self.status_label = QtWidgets.QLabel("(no status yet)")
        self.status_label.setStyleSheet("font-family: monospace;")

        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(140)

        layout.addWidget(QtWidgets.QLabel("Port"), 0, 0)
        layout.addWidget(self.port_combo, 0, 1)
        layout.addWidget(refresh_btn, 0, 2)
        layout.addWidget(QtWidgets.QLabel("Baud"), 0, 3)
        layout.addWidget(self.baud_input, 0, 4)
        layout.addWidget(self.connect_btn, 0, 5)

        layout.addWidget(setup_btn, 1, 0, 1, 2)
        layout.addWidget(unlock_btn, 1, 2)
        layout.addWidget(status_btn, 1, 3)
        layout.addWidget(hold_btn, 1, 4)
        layout.addWidget(resume_btn, 1, 5)

        layout.addWidget(QtWidgets.QLabel("Feed rate"), 2, 0)
        layout.addWidget(self.feed_input, 2, 1)
        layout.addWidget(wrist_feed_btn, 2, 2)
        layout.addWidget(self.rapid_checkbox, 2, 3, 1, 1)
        layout.addWidget(reset_btn, 2, 4)
        layout.addWidget(send_btn, 2, 5)

        layout.addWidget(QtWidgets.QLabel("Last status:"), 3, 0)
        layout.addWidget(self.status_label, 3, 1, 1, 5)

        layout.addWidget(self.log, 4, 0, 1, 6)

        self.raw_input = QtWidgets.QLineEdit()
        self.raw_input.setPlaceholderText("Raw command, e.g. $$  or  $110=3000  (Enter to send)")
        self.raw_input.returnPressed.connect(self._on_send_raw)
        raw_send_btn = QtWidgets.QPushButton("Send Raw")
        raw_send_btn.clicked.connect(self._on_send_raw)

        layout.addWidget(QtWidgets.QLabel("Raw cmd"), 5, 0)
        layout.addWidget(self.raw_input, 5, 1, 1, 4)
        layout.addWidget(raw_send_btn, 5, 5)

        note = QtWidgets.QLabel(
            f"First time connecting to a fresh grbl4axis board? Click 'Push $100-$103 Settings' once "
            f"(persists in EEPROM). If moves are rejected with an ALARM message, click 'Unlock'. "
            f"Use the 'Raw cmd' box for anything else — e.g. type $$ and press Enter to dump all "
            f"current grbl settings (including $110-$113 max rate and $120-$123 acceleration). "
            f"Default feed rate is {config.SAFE_FEED_DEG_PER_MIN:.0f} deg/min, found on the bench to "
            f"clear up full-step resonance buzz on the 36:1 joints — click 'Wrist-safe feed' before a "
            f"wrist-only move since its gearing needs a different number for the same real speed."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        layout.addWidget(note, 6, 0, 1, 6)

        return box

    # -- behavior ------------------------------------------------------------

    def _log(self, msg):
        self.log.appendPlainText(msg)

    def _refresh_ports(self):
        self.port_combo.clear()
        for device, desc in serial_bridge.SerialBridge.list_ports():
            self.port_combo.addItem(f"{device} — {desc}", userData=device)
        if self.port_combo.count() == 0:
            self.port_combo.addItem("(no ports found)", userData=None)

    def _on_connect_toggle(self):
        if self.bridge.is_connected():
            self.bridge.disconnect()
            self.connect_btn.setText("Connect")
            self._log("Disconnected.")
            return

        port = self.port_combo.currentData()
        if not port:
            self._log("No serial port selected.")
            return
        try:
            self.bridge.connect(port, self.baud_input.value())
            self.connect_btn.setText("Disconnect")
            self._log(f"Connected to {port} @ {self.baud_input.value()} baud.")
            if self.bridge.startup_banner:
                for line in self.bridge.startup_banner:
                    self._log(f"  <- {line}")
            else:
                self._log("  (no startup banner seen — grbl may already be running, or baud is wrong)")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Connection failed: {e}")

    def _on_jog_changed(self):
        self.current_thetas = [s.value() for s in self.joint_sliders]
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       self.current_thetas):
            label.setText(f"{name}: {theta:.1f}°")
        self.last_target_xyz = None
        self.canvas.plot_pose(self.current_thetas)

    def _on_solve_ik(self):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        psi = self.psi_input.value()
        elbow = "up" if self.elbow_up.isChecked() else "down"

        try:
            thetas = kinematics.solve_ik(x, y, z, psi, elbow=elbow)
        except kinematics.IKUnreachableError as e:
            self.ik_status.setText(str(e))
            self.ik_status.setStyleSheet("color: red;")
            return

        ok, residual = kinematics.verify_ik(thetas, (x, y, z))
        violations = kinematics.check_joint_limits(thetas)

        # Push solved angles onto the sliders (blocking signals to avoid
        # feedback loops, then update once manually).
        for slider, theta in zip(self.joint_sliders, thetas):
            slider.blockSignals(True)
            slider.setValue(int(round(theta)))
            slider.blockSignals(False)

        self.current_thetas = list(thetas)
        self.last_target_xyz = (x, y, z)
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       thetas):
            label.setText(f"{name}: {theta:.1f}°")

        self.canvas.plot_pose(thetas, target_xyz=(x, y, z))

        status_lines = [f"Solved θ = [{', '.join(f'{t:.1f}°' for t in thetas)}]",
                         f"FK residual: {residual:.2f} mm"]
        if violations:
            status_lines.append(
                "JOINT LIMIT WARNING (placeholder limits, not yet measured): "
                + "; ".join(f"joint {i} = {t:.1f}° (limit {lo}..{hi})" for i, t, lo, hi in violations)
            )
        self.ik_status.setText("\n".join(status_lines))
        self.ik_status.setStyleSheet("color: #a05a00;" if violations else "color: green;")

    def _on_save_offsets(self):
        offsets = [w.value() for w in self.offset_inputs]
        config.save_home_offsets(offsets)
        self._log(f"Saved home offsets: {offsets}")

    def _on_reload_offsets(self):
        offsets = config.load_home_offsets()
        for w, v in zip(self.offset_inputs, offsets):
            w.setValue(v)
        self._log("Reloaded home offsets from disk.")

    def _on_push_settings(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log("Pushing $100-$103 steps/degree settings...")
        try:
            results = self.bridge.push_steps_per_unit_settings()
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Settings push failed: {e}")
            return
        for setting, value, response in results:
            self._log(f"  {setting}={value:.4f}  -> {', '.join(response)}")
        self._log("Done. These persist in grbl's EEPROM across power cycles.")

    def _on_unlock(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        try:
            response = self.bridge.unlock()
            self._log(f"$X -> {', '.join(response)}")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Unlock failed: {e}")

    def _on_send_raw(self):
        line = self.raw_input.text().strip()
        if not line:
            return
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log(f"Sending raw: {line}")
        try:
            response = self.bridge.send_raw(line)
            for r in response:
                self._log(f"  <- {r}")
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Raw send failed: {e}")
        finally:
            self.raw_input.clear()

    def _on_use_wrist_safe_feed(self):
        self.feed_input.setValue(config.WRIST_SAFE_FEED_DEG_PER_MIN)
        self._log(
            f"Feed rate set to {config.WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min "
            "(wrist-safe — scaled from the bench-tested 36:1-joint value for the wrist's 6:1 gearing)."
        )

    def _on_status(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        status = self.bridge.request_status()
        if status:
            self.status_label.setText(status)
            self._log(f"Status: {status}")
        else:
            self._log("No status response received (older grbl builds may not support '?').")

    def _on_feed_hold(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.feed_hold()
        self._log("Sent feed hold (!).")

    def _on_resume(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.cycle_start_resume()
        self._log("Sent cycle start/resume (~).")

    def _on_soft_reset(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.soft_reset()
        self._log("Sent soft reset (Ctrl-X). Grbl will reprint its startup banner.")

    def _on_send_pose(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return

        offsets = [w.value() for w in self.offset_inputs]
        motor_angles = kinematics.apply_home_offset(self.current_thetas, offsets)
        rapid = self.rapid_checkbox.isChecked()
        feed = self.feed_input.value()

        line = self.bridge.build_move_gcode(motor_angles, feed_deg_per_min=feed, rapid=rapid)
        est_steps = kinematics.estimated_steps_for_display(self.current_thetas, offsets)
        self._log(f"Sending: {line}")
        self._log(f"  (thetas {[round(t,1) for t in self.current_thetas]}, "
                   f"est. steps {est_steps} — for reference only, not sent)")
        try:
            response = self.bridge.send_line(line)
        except serial_bridge.GrblAlarmError as e:
            self._log(f"ALARM: {e}")
            self._log("  -> Click 'Unlock ($X)' and try again.")
            return
        except serial_bridge.SerialBridgeError as e:
            self._log(f"Send failed: {e}")
            return
        for resp_line in response:
            self._log(f"  <- {resp_line}")

    def _update_pose(self, send=False):
        self.canvas.plot_pose(self.current_thetas, self.last_target_xyz)


def main():
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
