"""
kinematics.py

Ported from the browser JS FK/IK simulator (plan section 5) into Python.

Two independent code paths, deliberately kept separate so one can validate
the other:

  1. forward_kinematics() — a fully general 4x4 DH matrix chain. Used for
     the live 3D view and to sanity-check IK solutions (re-run FK on a
     solved pose and compare against the requested target).

  2. solve_ik() — the closed-form geometric solver as derived in the plan:
       - theta1 = atan2(target_y, target_x), locked first
       - project the remaining target into the shoulder/elbow/wrist plane
         (which is tilted purely in the vertical, base-offset-shifted plane
         established by joint 1's alpha=90 twist)
       - subtract the wrist link (L3) along the desired tool angle psi to
         get a "wrist point", then solve a classic 2-link (L1, L2) planar
         IK via law of cosines
       - theta4 = psi - theta2 - theta3
       - elbow branch ('up' / 'down') selectable — this directly resolves
         the "elbow-up/elbow-down not yet implemented" open item.
"""

import numpy as np

import config


def dh_matrix(theta_deg, d, a, alpha_deg):
    """Standard DH transform: Rot_z(theta) * Trans_z(d) * Trans_x(a) * Rot_x(alpha)."""
    t = np.radians(theta_deg)
    al = np.radians(alpha_deg)
    ct, st = np.cos(t), np.sin(t)
    ca, sa = np.cos(al), np.sin(al)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0.0,      sa,       ca,      d],
        [0.0,     0.0,      0.0,    1.0],
    ])


def forward_kinematics(thetas_deg, dh_params=None):
    """
    Given 4 joint angles (degrees), return:
      - joint_positions: list of 5 numpy 3-vectors (base origin, then each
        joint's resulting frame origin, ending at the tool tip)
      - T_final: the full 4x4 transform of the tool frame in world coords
    """
    if dh_params is None:
        dh_params = config.DH_PARAMS

    T = np.eye(4)
    positions = [T[:3, 3].copy()]
    for theta, params in zip(thetas_deg, dh_params):
        T = T @ dh_matrix(theta, params["d"], params["a"], params["alpha_deg"])
        positions.append(T[:3, 3].copy())
    return positions, T


class IKUnreachableError(ValueError):
    """Raised when the requested target/psi combination has no real solution."""
    pass


def solve_ik(x, y, z, psi_deg, elbow="up", dh_params=None):
    """
    Closed-form IK matching plan section 5.3.

    x, y, z   : target tool-tip position in world mm
    psi_deg   : desired tool angle within the arm's vertical plane (degrees),
                i.e. the resolved value of theta2+theta3+theta4
    elbow     : "up" or "down" — selects the elbow branch

    Returns (theta1, theta2, theta3, theta4) in degrees.
    Raises IKUnreachableError if the target is out of reach for the given psi.
    """
    if dh_params is None:
        dh_params = config.DH_PARAMS

    a1 = dh_params[0]["a"]
    L1 = dh_params[1]["a"]
    L2 = dh_params[2]["a"]
    L3 = dh_params[3]["a"]
    d1 = dh_params[0]["d"]

    # Step 1: base yaw, locked before solving the rest (per plan 5.3.1) so
    # base rotation never drifts unnecessarily when only reach/height change.
    theta1 = np.degrees(np.arctan2(y, x))
    t1 = np.radians(theta1)

    # Step 2: project target into the shoulder/elbow/wrist plane established
    # by joint 1's origin (a1*cos1, a1*sin1, d1) and its horizontal x1-axis
    # (cos1, sin1, 0) / vertical y1-axis (0,0,1) — derived from the joint-1
    # DH matrix with alpha1=90.
    u = (x - a1 * np.cos(t1)) * np.cos(t1) + (y - a1 * np.sin(t1)) * np.sin(t1)
    v = z - d1

    # Step 3: subtract the wrist link along psi to get the 2-link wrist point.
    psi = np.radians(psi_deg)
    uw = u - L3 * np.cos(psi)
    vw = v - L3 * np.sin(psi)

    # Step 4: classic 2-link planar IK, law of cosines.
    r2 = uw ** 2 + vw ** 2
    D = (r2 - L1 ** 2 - L2 ** 2) / (2 * L1 * L2)

    if abs(D) > 1.0 + 1e-9:
        raise IKUnreachableError(
            f"Target (x={x:.1f}, y={y:.1f}, z={z:.1f}) with psi={psi_deg:.1f} deg "
            f"is out of reach (|D|={abs(D):.3f} > 1)."
        )
    D = np.clip(D, -1.0, 1.0)

    sign = 1.0 if elbow == "down" else -1.0
    theta3 = np.degrees(np.arctan2(sign * np.sqrt(max(0.0, 1 - D ** 2)), D))

    t3 = np.radians(theta3)
    theta2 = np.degrees(
        np.arctan2(vw, uw) - np.arctan2(L2 * np.sin(t3), L1 + L2 * np.cos(t3))
    )

    theta4 = psi_deg - theta2 - theta3

    return theta1, theta2, theta3, theta4


def verify_ik(thetas_deg, target_xyz, tol_mm=0.5):
    """
    Re-run FK on a solved pose and check the tool tip lands within tol_mm of
    the requested target. Returns (ok: bool, residual_mm: float).
    """
    positions, _ = forward_kinematics(thetas_deg)
    tip = positions[-1]
    residual = float(np.linalg.norm(tip - np.array(target_xyz)))
    return residual <= tol_mm, residual


def apply_home_offset(thetas_deg, home_offset_deg=None):
    """
    Convert DH-frame solved joint angles into real motor angles by applying
    the home offset calibration (plan section 5.4):

        motor_angle = theta_dh - home_offset

    With grbl doing the degrees->steps conversion itself (via its $100-$103
    steps-per-unit settings, see config.py), this motor_angle in degrees is
    exactly what gets sent as the G-code axis word — no step math needed on
    the host side.
    """
    if home_offset_deg is None:
        home_offset_deg = config.load_home_offsets()
    return [theta - offset for theta, offset in zip(thetas_deg, home_offset_deg)]


def remove_home_offset(motor_angles_deg, home_offset_deg=None):
    """Inverse of apply_home_offset — e.g. to interpret a status report back into DH-frame angles."""
    if home_offset_deg is None:
        home_offset_deg = config.load_home_offsets()
    return [angle + offset for angle, offset in zip(motor_angles_deg, home_offset_deg)]


def estimated_steps_for_display(thetas_deg, home_offset_deg=None):
    """
    Informational only — NOT sent to grbl. Shows the equivalent raw step
    count for a given pose, purely so you can sanity-check against the
    physical gearbox (e.g. confirm a move "looks like" a sensible number of
    steps) without grbl actually receiving step counts directly.
    """
    motor_angles = apply_home_offset(thetas_deg, home_offset_deg)
    return [int(round(angle * spd)) for angle, spd in zip(motor_angles, config.GRBL_STEPS_PER_DEGREE)]


def check_joint_limits(thetas_deg, limits=None):
    """
    Returns a list of (index, theta, lo, hi) for any violations.
    Empty list means all clear. Remember: config.JOINT_LIMITS_DEG are
    placeholders until measured on the physical arm (plan section 8).
    """
    if limits is None:
        limits = config.JOINT_LIMITS_DEG
    violations = []
    for i, (theta, (lo, hi)) in enumerate(zip(thetas_deg, limits)):
        if not (lo <= theta <= hi):
            violations.append((i, theta, lo, hi))
    return violations
