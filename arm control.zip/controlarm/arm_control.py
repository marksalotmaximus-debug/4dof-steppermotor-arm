#!/usr/bin/env python3
"""
arm_control.py — single-file build of the 4-DOF robotic arm control app.

Talks to a real gcobos/grbl4axis controller over standard grbl G-code
(not a custom line protocol) — see the py section below.

Package into a standalone executable with:

    pyinstaller --onefile --windowed --name ArmControl arm_control.py

Run directly with:

    python arm_control.py
"""

import sys
import os
import json
import time

import numpy as np
import serial
import serial.tools.list_ports
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


# ============================================================================
# py
# ============================================================================
"""
py

Central place for every number pulled from the project plan:
  - DH parameters (section 5.1)
  - Gear ratios / steps-per-rev (section 2.2 / 4)
  - Home offset calibration (section 5.4) — persisted to home_offsets.json
  - Joint limit placeholders (section 8 — NOT yet measured on real hardware)
  - Serial defaults

Nothing here should need to change as you calibrate the physical arm —
only the *values*, via the GUI's calibration panel or by hand-editing
home_offsets.json.
"""

import json
import os

# ---------------------------------------------------------------------------
# DH parameters: (a [mm], alpha [deg], d [mm])  — theta is the joint variable
# From plan section 5.1. a4 (65mm) is the wrist's own link length, per the
# plan's explicit decision to fold the tool offset into joint 4 rather than
# treat it as a separate fixed 5th link.
# ---------------------------------------------------------------------------
DH_PARAMS = [
    {"a": 21.15,  "alpha_deg": 90.0, "d": 24.25},  # joint 1 - base (yaw)
    {"a": 194.66, "alpha_deg": 0.0,  "d": 0.0},     # joint 2 - shoulder (pitch)
    {"a": 152.0,  "alpha_deg": 0.0,  "d": 0.0},     # joint 3 - elbow (pitch)
    {"a": 65.0,   "alpha_deg": 0.0,  "d": 0.0},     # joint 4 - wrist (pitch)
]

# ---------------------------------------------------------------------------
# Drivetrain (section 2.2 / 4)
# ---------------------------------------------------------------------------
MOTOR_FULL_STEPS_PER_REV = 200          # NEMA17, full-step only (DRV8825, no microstepping)
GEAR_RATIOS = [36, 36, 36, 6]            # base, shoulder, elbow, wrist
STEPS_PER_OUTPUT_REV = [MOTOR_FULL_STEPS_PER_REV * r for r in GEAR_RATIOS]
# -> [7200, 7200, 7200, 1200]

# ---------------------------------------------------------------------------
# Grbl (gcobos/grbl4axis) steps-per-unit settings.
#
# Standard grbl does NOT accept raw step counts from the host — it parses
# G-code axis words in machine "units" (mm by convention, but really just
# whatever $100-$103 says a step is worth) and does the degrees<->steps
# conversion itself, in firmware, using its own EEPROM-stored settings.
#
# We exploit that directly: define 1 G-code "unit" == 1 degree of output
# rotation for every joint, and program grbl's steps/unit settings to match
# our gear reduction. Then the app can just send G-code axis words in plain
# degrees and grbl handles the rest — no step math needed on the host side.
#
#   $100 (X, base)      = steps per degree = 7200/360 = 20.0
#   $101 (Y, shoulder)  = steps per degree = 7200/360 = 20.0
#   $102 (Z, elbow)     = steps per degree = 7200/360 = 20.0
#   $103 (E, wrist)     = steps per degree = 1200/360 = 3.3333
#
# These need to be pushed to grbl's EEPROM once (they persist across power
# cycles after that) — the GUI's "Grbl Setup" panel does this with one
# button click. gcobos/grbl4axis maps its 4th axis to the "E" word on
# Uno pins D12/D13 (variable spindle disabled to free those pins) — NOT "A".
# Confirmed against the actual gcobos/grbl4axis source: E_STEP_BIT /
# E_DIRECTION_BIT on pins 12/13, axis word "E". Sending "A" gets the whole
# line rejected as an unsupported/invalid g-code block.
# ---------------------------------------------------------------------------
GRBL_AXIS_LETTERS = ["X", "Y", "Z", "E"]   # base, shoulder, elbow, wrist
GRBL_STEPS_PER_DEGREE = [s / 360.0 for s in STEPS_PER_OUTPUT_REV]
# -> [20.0, 20.0, 20.0, 3.3333...]

GRBL_SETTING_NUMBERS = ["$100", "$101", "$102", "$103"]

# Default feed rate for G1 moves, in grbl's units/min — since our "unit" is
# 1 degree, this is degrees/minute. G0 (rapid) ignores this and just seeks
# at $110-$113 max rate settings instead.
#
# Bench-testing finding (bare motors, no arm assembled yet — see build log):
# F300 (the old default) sat right inside a resonance band — motors were
# badly rattly/buzzy, confirmed both by ear and by an audio spectrogram
# (~220Hz fundamental + harmonics that shifted character with feed rate).
# F1600 deg/min cleared it up dramatically for the 36:1 joints
# (base/shoulder/elbow). Very likely classic full-step resonance
# (electromagnetic + detent-torque interaction, worse when unloaded) rather
# than a wiring/driver/gearbox fault — it responded to speed, not to any
# hardware change.
#
# IMPORTANT: this was found with bare, unloaded motors. Steppers lose
# available torque as step rate climbs, so once the arm carries real
# mass/gearing load, re-check whether 1600 is still smooth *and* whether it
# still has enough torque to hold/move the payload — don't assume higher is
# always better once it's loaded.
SAFE_FEED_DEG_PER_MIN = 1600.0   # tuned on base/shoulder/elbow (36:1 joints)

DEFAULT_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN

# The wrist is geared 6:1, not 36:1 — GRBL_STEPS_PER_DEGREE[3] is 6x smaller
# than the other joints', so the same F (deg/min) value drives it at a much
# lower *actual* step rate. Scale the safe feed above so the wrist lands in
# roughly the same physical step-rate sweet spot found on the bench:
WRIST_SAFE_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN * (
    GRBL_STEPS_PER_DEGREE[0] / GRBL_STEPS_PER_DEGREE[3]
)
# -> 1600 * (20 / 3.3333) = 9600.0 deg/min — test this specifically once the
# wrist motor/gearbox is wired up; don't assume 1600 is also its sweet spot.

# ---------------------------------------------------------------------------
# Joint limits — PLACEHOLDERS ONLY. Section 8 explicitly lists these as
# not-yet-measured. Do not trust these for real hardware moves until you've
# walked each joint to its physical stops and updated this list (or better,
# fed real values through the GUI calibration panel).
# ---------------------------------------------------------------------------
JOINT_LIMITS_DEG = [
    (-150.0, 150.0),   # base
    (-90.0, 90.0),      # shoulder
    (-120.0, 120.0),    # elbow
    (-100.0, 100.0),    # wrist
]

# ---------------------------------------------------------------------------
# Home offset calibration (section 5.4)
#   THETA_HOME_OFFSET[i]: degrees to SUBTRACT from a DH-frame solved angle
#   to get the real motor command angle, i.e.:
#       motor_angle = theta_dh - home_offset
#   Persisted so you don't have to re-measure every session.
# ---------------------------------------------------------------------------
_HOME_OFFSET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "home_offsets.json")
_DEFAULT_HOME_OFFSETS = [0.0, 0.0, 0.0, 0.0]


def load_home_offsets():
    """Load home offsets from disk, falling back to zeros if not yet calibrated."""
    if os.path.exists(_HOME_OFFSET_FILE):
        try:
            with open(_HOME_OFFSET_FILE, "r") as f:
                data = json.load(f)
            offsets = data.get("home_offset_deg", _DEFAULT_HOME_OFFSETS)
            if len(offsets) == 4:
                return [float(v) for v in offsets]
        except (json.JSONDecodeError, OSError):
            pass
    return list(_DEFAULT_HOME_OFFSETS)


def save_home_offsets(offsets):
    """Persist a 4-element list of degree offsets to disk."""
    if len(offsets) != 4:
        raise ValueError("home offsets must have exactly 4 values (base, shoulder, elbow, wrist)")
    with open(_HOME_OFFSET_FILE, "w") as f:
        json.dump({"home_offset_deg": [float(v) for v in offsets]}, f, indent=2)


# ---------------------------------------------------------------------------
# Serial / firmware protocol defaults — real gcobos/grbl4axis over G-code
# ---------------------------------------------------------------------------
DEFAULT_BAUD = 115200   # grbl v0.9+ default; this fork inherits it

AXIS_LABELS = ["base", "shoulder", "elbow", "wrist"]

# NOTE ON THE 4-AXIS PIN MAPPING:
# gcobos/grbl4axis frees Uno pins D12/D13 for a 4th ("E") axis by disabling
# grbl's variable-spindle PWM feature. Confirm your CNC Shield / wiring
# actually routes the wrist driver's STEP/DIR to D12/D13 accordingly —
# this is a firmware-level pin choice made by that fork, not something this
# app controls.
#
# Protocol is now standard grbl G-code, not a custom line format:
#   - Motion:  "G90 G1 X<deg> Y<deg> Z<deg> E<deg> F<feed>\n" (absolute, feed-rate move)
#              or "G90 G0 X<deg> Y<deg> Z<deg> E<deg>\n" (absolute, rapid move)
#   - Grbl responds "ok\n" per accepted line, or "error:<n>\n" on rejection.
#   - Real-time commands (single character, no newline, no "ok" reply):
#       "?"  status report request
#       "!"  feed hold
#       "~"  cycle start / resume
#       0x18 (Ctrl-X) soft reset
#   - "$X\n" clears an ALARM lock (grbl starts in alarm state if homing is
#     enabled in settings but hasn't been run — common with no limit
#     switches wired up, which this project doesn't have per the plan).
#
# See py for the implementation and gui.py's "Grbl Setup"
# panel for pushing the $100-$103 steps/unit settings shown above.


# ============================================================================
# py
# ============================================================================
"""
py

Ported from the browser JS FK/IK simulator (plan section 5) into Python.

Two independent code paths, deliberately kept separate so one can validate
the other:

  1. forward_kinematics() — a fully general 4x4 DH matrix chain. Used for
     the live 3D view and to sanity-check IK solutions (re-run FK on a
     solved pose and compare against the requested target).

  2. solve_ik() — the closed-form geometric solver as derived in the plan:
       - theta1 = atan2(target_y, target_x), locked first
       - project the remaining target into the shoulder/elbow/wrist plane
         (which is tilted purely in the vertical, base-offset-shifted plane
         established by joint 1's alpha=90 twist)
       - subtract the wrist link (L3) along the desired tool angle psi to
         get a "wrist point", then solve a classic 2-link (L1, L2) planar
         IK via law of cosines
       - theta4 = psi - theta2 - theta3
       - elbow branch ('up' / 'down') selectable — this directly resolves
         the "elbow-up/elbow-down not yet implemented" open item.
"""

import numpy as np



def dh_matrix(theta_deg, d, a, alpha_deg):
    """Standard DH transform: Rot_z(theta) * Trans_z(d) * Trans_x(a) * Rot_x(alpha)."""
    t = np.radians(theta_deg)
    al = np.radians(alpha_deg)
    ct, st = np.cos(t), np.sin(t)
    ca, sa = np.cos(al), np.sin(al)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0.0,      sa,       ca,      d],
        [0.0,     0.0,      0.0,    1.0],
    ])


def forward_kinematics(thetas_deg, dh_params=None):
    """
    Given 4 joint angles (degrees), return:
      - joint_positions: list of 5 numpy 3-vectors (base origin, then each
        joint's resulting frame origin, ending at the tool tip)
      - T_final: the full 4x4 transform of the tool frame in world coords
    """
    if dh_params is None:
        dh_params = DH_PARAMS

    T = np.eye(4)
    positions = [T[:3, 3].copy()]
    for theta, params in zip(thetas_deg, dh_params):
        T = T @ dh_matrix(theta, params["d"], params["a"], params["alpha_deg"])
        positions.append(T[:3, 3].copy())
    return positions, T


class IKUnreachableError(ValueError):
    """Raised when the requested target/psi combination has no real solution."""
    pass


def solve_ik(x, y, z, psi_deg, elbow="up", dh_params=None):
    """
    Closed-form IK matching plan section 5.3.

    x, y, z   : target tool-tip position in world mm
    psi_deg   : desired tool angle within the arm's vertical plane (degrees),
                i.e. the resolved value of theta2+theta3+theta4
    elbow     : "up" or "down" — selects the elbow branch

    Returns (theta1, theta2, theta3, theta4) in degrees.
    Raises IKUnreachableError if the target is out of reach for the given psi.
    """
    if dh_params is None:
        dh_params = DH_PARAMS

    a1 = dh_params[0]["a"]
    L1 = dh_params[1]["a"]
    L2 = dh_params[2]["a"]
    L3 = dh_params[3]["a"]
    d1 = dh_params[0]["d"]

    # Step 1: base yaw, locked before solving the rest (per plan 5.3.1) so
    # base rotation never drifts unnecessarily when only reach/height change.
    theta1 = np.degrees(np.arctan2(y, x))
    t1 = np.radians(theta1)

    # Step 2: project target into the shoulder/elbow/wrist plane established
    # by joint 1's origin (a1*cos1, a1*sin1, d1) and its horizontal x1-axis
    # (cos1, sin1, 0) / vertical y1-axis (0,0,1) — derived from the joint-1
    # DH matrix with alpha1=90.
    u = (x - a1 * np.cos(t1)) * np.cos(t1) + (y - a1 * np.sin(t1)) * np.sin(t1)
    v = z - d1

    # Step 3: subtract the wrist link along psi to get the 2-link wrist point.
    psi = np.radians(psi_deg)
    uw = u - L3 * np.cos(psi)
    vw = v - L3 * np.sin(psi)

    # Step 4: classic 2-link planar IK, law of cosines.
    r2 = uw ** 2 + vw ** 2
    D = (r2 - L1 ** 2 - L2 ** 2) / (2 * L1 * L2)

    if abs(D) > 1.0 + 1e-9:
        raise IKUnreachableError(
            f"Target (x={x:.1f}, y={y:.1f}, z={z:.1f}) with psi={psi_deg:.1f} deg "
            f"is out of reach (|D|={abs(D):.3f} > 1)."
        )
    D = np.clip(D, -1.0, 1.0)

    sign = 1.0 if elbow == "down" else -1.0
    theta3 = np.degrees(np.arctan2(sign * np.sqrt(max(0.0, 1 - D ** 2)), D))

    t3 = np.radians(theta3)
    theta2 = np.degrees(
        np.arctan2(vw, uw) - np.arctan2(L2 * np.sin(t3), L1 + L2 * np.cos(t3))
    )

    theta4 = psi_deg - theta2 - theta3

    return theta1, theta2, theta3, theta4


def verify_ik(thetas_deg, target_xyz, tol_mm=0.5):
    """
    Re-run FK on a solved pose and check the tool tip lands within tol_mm of
    the requested target. Returns (ok: bool, residual_mm: float).
    """
    positions, _ = forward_kinematics(thetas_deg)
    tip = positions[-1]
    residual = float(np.linalg.norm(tip - np.array(target_xyz)))
    return residual <= tol_mm, residual


def apply_home_offset(thetas_deg, home_offset_deg=None):
    """
    Convert DH-frame solved joint angles into real motor angles by applying
    the home offset calibration (plan section 5.4):

        motor_angle = theta_dh - home_offset

    With grbl doing the degrees->steps conversion itself (via its $100-$103
    steps-per-unit settings, see py), this motor_angle in degrees is
    exactly what gets sent as the G-code axis word — no step math needed on
    the host side.
    """
    if home_offset_deg is None:
        home_offset_deg = load_home_offsets()
    return [theta - offset for theta, offset in zip(thetas_deg, home_offset_deg)]


def remove_home_offset(motor_angles_deg, home_offset_deg=None):
    """Inverse of apply_home_offset — e.g. to interpret a status report back into DH-frame angles."""
    if home_offset_deg is None:
        home_offset_deg = load_home_offsets()
    return [angle + offset for angle, offset in zip(motor_angles_deg, home_offset_deg)]


def estimated_steps_for_display(thetas_deg, home_offset_deg=None):
    """
    Informational only — NOT sent to grbl. Shows the equivalent raw step
    count for a given pose, purely so you can sanity-check against the
    physical gearbox (e.g. confirm a move "looks like" a sensible number of
    steps) without grbl actually receiving step counts directly.
    """
    motor_angles = apply_home_offset(thetas_deg, home_offset_deg)
    return [int(round(angle * spd)) for angle, spd in zip(motor_angles, GRBL_STEPS_PER_DEGREE)]


def check_joint_limits(thetas_deg, limits=None):
    """
    Returns a list of (index, theta, lo, hi) for any violations.
    Empty list means all clear. Remember: JOINT_LIMITS_DEG are
    placeholders until measured on the physical arm (plan section 8).
    """
    if limits is None:
        limits = JOINT_LIMITS_DEG
    violations = []
    for i, (theta, (lo, hi)) in enumerate(zip(thetas_deg, limits)):
        if not (lo <= theta <= hi):
            violations.append((i, theta, lo, hi))
    return violations


# ============================================================================
# py
# ============================================================================
"""
py

Talks to a real grbl / gcobos/grbl4axis controller over serial using
standard grbl semantics — NOT a custom line protocol.

Key facts about how grbl actually behaves, baked into this module:

  - On opening the serial port, grbl resets and prints a startup banner
    like "Grbl 0.9j ['$' for help]" after ~1-2 seconds. We wait for and
    capture that.
  - Every G-code line you send gets exactly one response line back:
    "ok" on success, or "error:<n>" on rejection. We send one line at a
    time and block until that response arrives (grbl's RX buffer is small
    — 127 bytes — so this simple one-at-a-time flow is the safe way to
    drive it from a GUI that sends one pose at a time, as opposed to
    streaming a whole G-code file, which would need character-counting).
  - Real-time commands are single bytes, sent with NO trailing newline,
    and do NOT get an "ok" response: "?" (status query), "!" (feed hold),
    "~" (cycle start/resume), and 0x18 / Ctrl-X (soft reset).
  - Grbl settings ($100, $101, ...) are pushed the same way as a G-code
    line: "$100=20.000\n" gets an "ok" back and is stored in EEPROM
    immediately (persists across power cycles).
  - If grbl's homing-required setting is on but no homing cycle has been
    run (this project has no limit switches per the plan), grbl boots
    into ALARM state and rejects all motion until you send "$X\n" to
    clear the lock, or run a homing cycle it doesn't have hardware for.
    This bridge exposes unlock() for that.
"""

import time

import serial
import serial.tools.list_ports



class SerialBridgeError(RuntimeError):
    pass


class GrblAlarmError(SerialBridgeError):
    """Raised when grbl rejects a move because it's in ALARM state."""
    pass


class SerialBridge:
    def __init__(self):
        self._ser = None
        self.startup_banner = []
        self.last_status = ""

    # -- connection management ------------------------------------------------

    @staticmethod
    def list_ports():
        return [(p.device, p.description) for p in serial.tools.list_ports.comports()]

    def connect(self, port, baud=None, timeout=2.0):
        if baud is None:
            baud = DEFAULT_BAUD
        if self.is_connected():
            self.disconnect()
        try:
            self._ser = serial.Serial(port, baud, timeout=timeout)
        except serial.SerialException as e:
            self._ser = None
            raise SerialBridgeError(f"Failed to open {port}: {e}") from e

        # Grbl resets on serial open (Arduino auto-reset via DTR) and prints
        # a startup banner a moment later. Capture it rather than discarding
        # it, since it also confirms which grbl version/build is on there.
        self.startup_banner = []
        deadline = time.time() + 3.0
        time.sleep(1.5)  # let the bootloader/grbl init finish before reading
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line:
                    self.startup_banner.append(line)
            else:
                time.sleep(0.05)

    def disconnect(self):
        if self._ser is not None:
            try:
                self._ser.close()
            finally:
                self._ser = None

    def is_connected(self):
        return self._ser is not None and self._ser.is_open

    # -- core line protocol ------------------------------------------------

    def send_line(self, line, timeout=10.0):
        """
        Send one G-code / '$' line, block until grbl responds with 'ok' or
        'error:<n>'. Returns the full list of lines received (there may be
        extra informational lines before the ok/error, e.g. for '$$').
        Raises GrblAlarmError on ALARM responses, SerialBridgeError on
        error:<n> responses or a timeout.
        """
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")

        if not line.endswith("\n"):
            line += "\n"
        self._ser.write(line.encode("utf-8"))

        lines = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._ser.in_waiting:
                raw = self._ser.readline().decode("utf-8", errors="replace").strip()
                if not raw:
                    continue
                lines.append(raw)
                lower = raw.lower()
                if lower == "ok":
                    return lines
                if lower.startswith("error:"):
                    raise SerialBridgeError(f"Grbl rejected '{line.strip()}': {raw}")
                if lower.startswith("alarm:"):
                    raise GrblAlarmError(
                        f"Grbl is in ALARM state ({raw}). Send $X to unlock before moving."
                    )
            else:
                time.sleep(0.02)

        raise SerialBridgeError(f"Timed out waiting for response to '{line.strip()}'.")

    # -- real-time single-byte commands (no newline, no 'ok') ---------------

    def request_status(self):
        """Send '?' and capture the '<...>' status report line grbl sends back."""
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"?")
        deadline = time.time() + 2.0
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line.startswith("<") and line.endswith(">"):
                    self.last_status = line
                    return line
            else:
                time.sleep(0.02)
        return ""

    def feed_hold(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"!")

    def cycle_start_resume(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"~")

    def soft_reset(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(bytes([0x18]))
        time.sleep(0.5)

    def unlock(self):
        """Clear an ALARM lock (grbl boots into alarm if homing-required but not yet homed)."""
        return self.send_line("$X")

    # -- G-code construction & sending --------------------------------------

    def build_move_gcode(self, motor_angles_deg, feed_deg_per_min=None, rapid=False):
        """
        motor_angles_deg: 4 values already home-offset-adjusted (see
        apply_home_offset) — these get sent directly as axis
        words, in absolute positioning mode (G90).

        feed_deg_per_min: ignored if rapid=True (uses G0). Required
        (falls back to DEFAULT_FEED_DEG_PER_MIN) for G1 moves.
        """
        axis_words = " ".join(
            f"{letter}{angle:.3f}"
            for letter, angle in zip(GRBL_AXIS_LETTERS, motor_angles_deg)
        )
        if rapid:
            return f"G90 G0 {axis_words}"
        feed = feed_deg_per_min if feed_deg_per_min is not None else DEFAULT_FEED_DEG_PER_MIN
        return f"G90 G1 {axis_words} F{feed:.1f}"

    def send_move(self, motor_angles_deg, feed_deg_per_min=None, rapid=False, timeout=15.0):
        """Build and send an absolute-position move. Returns grbl's response lines."""
        line = self.build_move_gcode(motor_angles_deg, feed_deg_per_min, rapid)
        return self.send_line(line, timeout=timeout)

    def push_steps_per_unit_settings(self):
        """
        One-time setup helper: push GRBL_STEPS_PER_DEGREE into grbl's
        $100-$103 EEPROM settings so 1 G-code unit == 1 output degree for
        every joint. Returns a list of (setting, value, response_lines).
        """
        results = []
        for setting, value in zip(GRBL_SETTING_NUMBERS, GRBL_STEPS_PER_DEGREE):
            line = f"{setting}={value:.4f}"
            response = self.send_line(line)
            results.append((setting, value, response))
        return results

    def send_raw(self, line):
        """Send an arbitrary raw line and wait for ok/error — for manual debugging."""
        return self.send_line(line)

    def read_available(self):
        """Non-blocking read of whatever's currently buffered (e.g. unsolicited grbl messages)."""
        if not self.is_connected():
            return []
        lines = []
        while self._ser.in_waiting:
            line = self._ser.readline().decode("utf-8", errors="replace").strip()
            if line:
                lines.append(line)
        return lines


# ============================================================================
# gui.py
# ============================================================================
"""
gui.py

PyQt5 desktop app tying together py and py.

Layout:
  Left column:
    - Joint jog sliders (theta1..theta4) with live degree readout
    - Target pose panel (X, Y, Z, psi, elbow up/down) + "Solve IK" button
    - Home offset calibration panel (4 fields, Save/Reload)
  Right column:
    - Live 3D plot of the arm (matplotlib, driven by forward_kinematics())
  Bottom:
    - Serial connection panel: port dropdown, connect/disconnect, one-time
      $100-$103 grbl settings push, unlock/status/feed-hold/resume/soft-reset,
      feed-rate input, and "Send Current Pose to Grbl" (real G-code, not
      raw step counts — see py)

Run via main.py.
"""

import sys

import numpy as np
from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure



class Arm3DCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(5, 5))
        super().__init__(fig)
        self.setParent(parent)
        self.ax = fig.add_subplot(111, projection="3d")
        self._reach = sum(p["a"] for p in DH_PARAMS) + 50
        self.plot_pose([0, 0, 0, 0])

    def plot_pose(self, thetas_deg, target_xyz=None):
        positions, _ = forward_kinematics(thetas_deg)
        pts = np.array(positions)

        self.ax.clear()
        # Arm links
        self.ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], "-o", color="#2a6fdb",
                     linewidth=3, markersize=6, markerfacecolor="#ff6a3d")
        # Base marker
        self.ax.scatter([0], [0], [0], color="black", s=40, marker="s")

        if target_xyz is not None:
            self.ax.scatter([target_xyz[0]], [target_xyz[1]], [target_xyz[2]],
                             color="green", s=60, marker="*", label="target")
            self.ax.legend(loc="upper left", fontsize=8)

        r = self._reach
        self.ax.set_xlim(-r, r)
        self.ax.set_ylim(-r, r)
        self.ax.set_zlim(0, 2 * r)
        self.ax.set_xlabel("X (mm)")
        self.ax.set_ylabel("Y (mm)")
        self.ax.set_zlabel("Z (mm)")
        self.ax.set_title("4-DOF arm — live DH pose")
        self.draw()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4-DOF Arm Control")
        self.resize(1200, 750)

        self.bridge = SerialBridge()
        self.current_thetas = [0.0, 0.0, 0.0, 0.0]
        self.last_target_xyz = None

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root_layout = QtWidgets.QVBoxLayout(central)

        top_layout = QtWidgets.QHBoxLayout()
        root_layout.addLayout(top_layout, stretch=1)

        left_col = QtWidgets.QVBoxLayout()
        top_layout.addLayout(left_col, stretch=0)

        self.canvas = Arm3DCanvas(self)
        top_layout.addWidget(self.canvas, stretch=1)

        left_col.addWidget(self._build_jog_panel())
        left_col.addWidget(self._build_ik_panel())
        left_col.addWidget(self._build_calibration_panel())
        left_col.addStretch(1)

        root_layout.addWidget(self._build_serial_panel(), stretch=0)

        self._refresh_ports()
        self._update_pose(send=False)

    # -- panels ------------------------------------------------------------

    def _build_jog_panel(self):
        box = QtWidgets.QGroupBox("Joint Jog (degrees)")
        layout = QtWidgets.QGridLayout(box)

        self.joint_sliders = []
        self.joint_labels = []
        names = ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"]
        for i, name in enumerate(names):
            lo, hi = JOINT_LIMITS_DEG[i]
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setMinimum(int(lo))
            slider.setMaximum(int(hi))
            slider.setValue(0)
            slider.valueChanged.connect(self._on_jog_changed)

            label = QtWidgets.QLabel(f"{name}: 0.0°")
            layout.addWidget(label, i, 0)
            layout.addWidget(slider, i, 1)
            self.joint_sliders.append(slider)
            self.joint_labels.append(label)

        return box

    def _build_ik_panel(self):
        box = QtWidgets.QGroupBox("Target Pose (Inverse Kinematics)")
        layout = QtWidgets.QGridLayout(box)

        self.x_input = QtWidgets.QDoubleSpinBox()
        self.y_input = QtWidgets.QDoubleSpinBox()
        self.z_input = QtWidgets.QDoubleSpinBox()
        self.psi_input = QtWidgets.QDoubleSpinBox()
        for w in (self.x_input, self.y_input, self.z_input):
            w.setRange(-1000, 1000)
            w.setDecimals(1)
            w.setSuffix(" mm")
        self.psi_input.setRange(-360, 360)
        self.psi_input.setSuffix(" deg")
        self.z_input.setValue(200.0)
        self.x_input.setValue(300.0)

        self.elbow_up = QtWidgets.QRadioButton("Elbow up")
        self.elbow_down = QtWidgets.QRadioButton("Elbow down")
        self.elbow_up.setChecked(True)
        elbow_group = QtWidgets.QButtonGroup(self)
        elbow_group.addButton(self.elbow_up)
        elbow_group.addButton(self.elbow_down)

        solve_btn = QtWidgets.QPushButton("Solve IK")
        solve_btn.clicked.connect(self._on_solve_ik)

        self.ik_status = QtWidgets.QLabel("")
        self.ik_status.setWordWrap(True)

        layout.addWidget(QtWidgets.QLabel("X"), 0, 0)
        layout.addWidget(self.x_input, 0, 1)
        layout.addWidget(QtWidgets.QLabel("Y"), 0, 2)
        layout.addWidget(self.y_input, 0, 3)
        layout.addWidget(QtWidgets.QLabel("Z"), 1, 0)
        layout.addWidget(self.z_input, 1, 1)
        layout.addWidget(QtWidgets.QLabel("Tool angle ψ"), 1, 2)
        layout.addWidget(self.psi_input, 1, 3)
        layout.addWidget(self.elbow_up, 2, 0, 1, 2)
        layout.addWidget(self.elbow_down, 2, 2, 1, 2)
        layout.addWidget(solve_btn, 3, 0, 1, 4)
        layout.addWidget(self.ik_status, 4, 0, 1, 4)

        return box

    def _build_calibration_panel(self):
        box = QtWidgets.QGroupBox("Home Offset Calibration (plan §5.4)")
        layout = QtWidgets.QGridLayout(box)

        self.offset_inputs = []
        offsets = load_home_offsets()
        for i, name in enumerate(AXIS_LABELS):
            spin = QtWidgets.QDoubleSpinBox()
            spin.setRange(-360, 360)
            spin.setDecimals(2)
            spin.setValue(offsets[i])
            layout.addWidget(QtWidgets.QLabel(name), i, 0)
            layout.addWidget(spin, i, 1)
            self.offset_inputs.append(spin)

        save_btn = QtWidgets.QPushButton("Save offsets")
        save_btn.clicked.connect(self._on_save_offsets)
        reload_btn = QtWidgets.QPushButton("Reload from disk")
        reload_btn.clicked.connect(self._on_reload_offsets)
        layout.addWidget(save_btn, len(AXIS_LABELS), 0)
        layout.addWidget(reload_btn, len(AXIS_LABELS), 1)

        note = QtWidgets.QLabel(
            "Not yet measured on physical hardware (open item). Jog each joint to a\n"
            "known reference pose on the real arm, read the DH-solved angle above,\n"
            "and enter the difference here."
        )
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        note.setWordWrap(True)
        layout.addWidget(note, len(AXIS_LABELS) + 1, 0, 1, 2)

        return box

    def _build_serial_panel(self):
        box = QtWidgets.QGroupBox("Serial Bridge (gcobos/grbl4axis)")
        layout = QtWidgets.QGridLayout(box)

        self.port_combo = QtWidgets.QComboBox()
        refresh_btn = QtWidgets.QPushButton("Refresh")
        refresh_btn.clicked.connect(self._refresh_ports)

        self.baud_input = QtWidgets.QSpinBox()
        self.baud_input.setRange(1200, 921600)
        self.baud_input.setValue(DEFAULT_BAUD)

        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.connect_btn.clicked.connect(self._on_connect_toggle)

        setup_btn = QtWidgets.QPushButton("Push $100-$103 Settings (one-time setup)")
        setup_btn.clicked.connect(self._on_push_settings)

        unlock_btn = QtWidgets.QPushButton("Unlock ($X)")
        unlock_btn.clicked.connect(self._on_unlock)

        status_btn = QtWidgets.QPushButton("Status (?)")
        status_btn.clicked.connect(self._on_status)

        hold_btn = QtWidgets.QPushButton("Feed Hold (!)")
        hold_btn.clicked.connect(self._on_feed_hold)

        resume_btn = QtWidgets.QPushButton("Resume (~)")
        resume_btn.clicked.connect(self._on_resume)

        reset_btn = QtWidgets.QPushButton("Soft Reset")
        reset_btn.setStyleSheet("color: darkred;")
        reset_btn.clicked.connect(self._on_soft_reset)

        self.feed_input = QtWidgets.QDoubleSpinBox()
        self.feed_input.setRange(1, 20000)
        self.feed_input.setValue(DEFAULT_FEED_DEG_PER_MIN)
        self.feed_input.setSuffix(" deg/min")

        wrist_feed_btn = QtWidgets.QPushButton("Wrist-safe feed")
        wrist_feed_btn.setToolTip(
            f"Sets feed rate to {WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min — scaled from the "
            f"{SAFE_FEED_DEG_PER_MIN:.0f} deg/min bench finding to match the wrist's 6:1 "
            "gearing (vs. 36:1 for the other joints), so it lands in roughly the same real step-rate "
            "range. Use this before a wrist-only move."
        )
        wrist_feed_btn.clicked.connect(self._on_use_wrist_safe_feed)

        self.rapid_checkbox = QtWidgets.QCheckBox("Use rapid (G0) instead of feed-rate (G1)")

        send_btn = QtWidgets.QPushButton("Send Current Pose to Grbl")
        send_btn.clicked.connect(self._on_send_pose)

        self.status_label = QtWidgets.QLabel("(no status yet)")
        self.status_label.setStyleSheet("font-family: monospace;")

        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(140)

        layout.addWidget(QtWidgets.QLabel("Port"), 0, 0)
        layout.addWidget(self.port_combo, 0, 1)
        layout.addWidget(refresh_btn, 0, 2)
        layout.addWidget(QtWidgets.QLabel("Baud"), 0, 3)
        layout.addWidget(self.baud_input, 0, 4)
        layout.addWidget(self.connect_btn, 0, 5)

        layout.addWidget(setup_btn, 1, 0, 1, 2)
        layout.addWidget(unlock_btn, 1, 2)
        layout.addWidget(status_btn, 1, 3)
        layout.addWidget(hold_btn, 1, 4)
        layout.addWidget(resume_btn, 1, 5)

        layout.addWidget(QtWidgets.QLabel("Feed rate"), 2, 0)
        layout.addWidget(self.feed_input, 2, 1)
        layout.addWidget(wrist_feed_btn, 2, 2)
        layout.addWidget(self.rapid_checkbox, 2, 3, 1, 1)
        layout.addWidget(reset_btn, 2, 4)
        layout.addWidget(send_btn, 2, 5)

        layout.addWidget(QtWidgets.QLabel("Last status:"), 3, 0)
        layout.addWidget(self.status_label, 3, 1, 1, 5)

        layout.addWidget(self.log, 4, 0, 1, 6)

        self.raw_input = QtWidgets.QLineEdit()
        self.raw_input.setPlaceholderText("Raw command, e.g. $$  or  $110=3000  (Enter to send)")
        self.raw_input.returnPressed.connect(self._on_send_raw)
        raw_send_btn = QtWidgets.QPushButton("Send Raw")
        raw_send_btn.clicked.connect(self._on_send_raw)

        layout.addWidget(QtWidgets.QLabel("Raw cmd"), 5, 0)
        layout.addWidget(self.raw_input, 5, 1, 1, 4)
        layout.addWidget(raw_send_btn, 5, 5)

        note = QtWidgets.QLabel(
            f"First time connecting to a fresh grbl4axis board? Click 'Push $100-$103 Settings' once "
            f"(persists in EEPROM). If moves are rejected with an ALARM message, click 'Unlock'. "
            f"Use the 'Raw cmd' box for anything else — e.g. type $$ and press Enter to dump all "
            f"current grbl settings (including $110-$113 max rate and $120-$123 acceleration). "
            f"Default feed rate is {SAFE_FEED_DEG_PER_MIN:.0f} deg/min, found on the bench to "
            f"clear up full-step resonance buzz on the 36:1 joints — click 'Wrist-safe feed' before a "
            f"wrist-only move since its gearing needs a different number for the same real speed."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #a05a00; font-size: 10px;")
        layout.addWidget(note, 6, 0, 1, 6)

        return box

    # -- behavior ------------------------------------------------------------

    def _log(self, msg):
        self.log.appendPlainText(msg)

    def _refresh_ports(self):
        self.port_combo.clear()
        for device, desc in SerialBridge.list_ports():
            self.port_combo.addItem(f"{device} — {desc}", userData=device)
        if self.port_combo.count() == 0:
            self.port_combo.addItem("(no ports found)", userData=None)

    def _on_connect_toggle(self):
        if self.bridge.is_connected():
            self.bridge.disconnect()
            self.connect_btn.setText("Connect")
            self._log("Disconnected.")
            return

        port = self.port_combo.currentData()
        if not port:
            self._log("No serial port selected.")
            return
        try:
            self.bridge.connect(port, self.baud_input.value())
            self.connect_btn.setText("Disconnect")
            self._log(f"Connected to {port} @ {self.baud_input.value()} baud.")
            if self.bridge.startup_banner:
                for line in self.bridge.startup_banner:
                    self._log(f"  <- {line}")
            else:
                self._log("  (no startup banner seen — grbl may already be running, or baud is wrong)")
        except SerialBridgeError as e:
            self._log(f"Connection failed: {e}")

    def _on_jog_changed(self):
        self.current_thetas = [s.value() for s in self.joint_sliders]
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       self.current_thetas):
            label.setText(f"{name}: {theta:.1f}°")
        self.last_target_xyz = None
        self.canvas.plot_pose(self.current_thetas)

    def _on_solve_ik(self):
        x, y, z = self.x_input.value(), self.y_input.value(), self.z_input.value()
        psi = self.psi_input.value()
        elbow = "up" if self.elbow_up.isChecked() else "down"

        try:
            thetas = solve_ik(x, y, z, psi, elbow=elbow)
        except IKUnreachableError as e:
            self.ik_status.setText(str(e))
            self.ik_status.setStyleSheet("color: red;")
            return

        ok, residual = verify_ik(thetas, (x, y, z))
        violations = check_joint_limits(thetas)

        # Push solved angles onto the sliders (blocking signals to avoid
        # feedback loops, then update once manually).
        for slider, theta in zip(self.joint_sliders, thetas):
            slider.blockSignals(True)
            slider.setValue(int(round(theta)))
            slider.blockSignals(False)

        self.current_thetas = list(thetas)
        self.last_target_xyz = (x, y, z)
        for label, name, theta in zip(self.joint_labels,
                                       ["Base (yaw)", "Shoulder (pitch)", "Elbow (pitch)", "Wrist (pitch)"],
                                       thetas):
            label.setText(f"{name}: {theta:.1f}°")

        self.canvas.plot_pose(thetas, target_xyz=(x, y, z))

        status_lines = [f"Solved θ = [{', '.join(f'{t:.1f}°' for t in thetas)}]",
                         f"FK residual: {residual:.2f} mm"]
        if violations:
            status_lines.append(
                "JOINT LIMIT WARNING (placeholder limits, not yet measured): "
                + "; ".join(f"joint {i} = {t:.1f}° (limit {lo}..{hi})" for i, t, lo, hi in violations)
            )
        self.ik_status.setText("\n".join(status_lines))
        self.ik_status.setStyleSheet("color: #a05a00;" if violations else "color: green;")

    def _on_save_offsets(self):
        offsets = [w.value() for w in self.offset_inputs]
        save_home_offsets(offsets)
        self._log(f"Saved home offsets: {offsets}")

    def _on_reload_offsets(self):
        offsets = load_home_offsets()
        for w, v in zip(self.offset_inputs, offsets):
            w.setValue(v)
        self._log("Reloaded home offsets from disk.")

    def _on_push_settings(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log("Pushing $100-$103 steps/degree settings...")
        try:
            results = self.bridge.push_steps_per_unit_settings()
        except SerialBridgeError as e:
            self._log(f"Settings push failed: {e}")
            return
        for setting, value, response in results:
            self._log(f"  {setting}={value:.4f}  -> {', '.join(response)}")
        self._log("Done. These persist in grbl's EEPROM across power cycles.")

    def _on_unlock(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        try:
            response = self.bridge.unlock()
            self._log(f"$X -> {', '.join(response)}")
        except SerialBridgeError as e:
            self._log(f"Unlock failed: {e}")

    def _on_send_raw(self):
        line = self.raw_input.text().strip()
        if not line:
            return
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self._log(f"Sending raw: {line}")
        try:
            response = self.bridge.send_raw(line)
            for r in response:
                self._log(f"  <- {r}")
        except SerialBridgeError as e:
            self._log(f"Raw send failed: {e}")
        finally:
            self.raw_input.clear()

    def _on_use_wrist_safe_feed(self):
        self.feed_input.setValue(WRIST_SAFE_FEED_DEG_PER_MIN)
        self._log(
            f"Feed rate set to {WRIST_SAFE_FEED_DEG_PER_MIN:.0f} deg/min "
            "(wrist-safe — scaled from the bench-tested 36:1-joint value for the wrist's 6:1 gearing)."
        )

    def _on_status(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        status = self.bridge.request_status()
        if status:
            self.status_label.setText(status)
            self._log(f"Status: {status}")
        else:
            self._log("No status response received (older grbl builds may not support '?').")

    def _on_feed_hold(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.feed_hold()
        self._log("Sent feed hold (!).")

    def _on_resume(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.cycle_start_resume()
        self._log("Sent cycle start/resume (~).")

    def _on_soft_reset(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return
        self.bridge.soft_reset()
        self._log("Sent soft reset (Ctrl-X). Grbl will reprint its startup banner.")

    def _on_send_pose(self):
        if not self.bridge.is_connected():
            self._log("Not connected — connect to a serial port first.")
            return

        offsets = [w.value() for w in self.offset_inputs]
        motor_angles = apply_home_offset(self.current_thetas, offsets)
        rapid = self.rapid_checkbox.isChecked()
        feed = self.feed_input.value()

        line = self.bridge.build_move_gcode(motor_angles, feed_deg_per_min=feed, rapid=rapid)
        est_steps = estimated_steps_for_display(self.current_thetas, offsets)
        self._log(f"Sending: {line}")
        self._log(f"  (thetas {[round(t,1) for t in self.current_thetas]}, "
                   f"est. steps {est_steps} — for reference only, not sent)")
        try:
            response = self.bridge.send_line(line)
        except GrblAlarmError as e:
            self._log(f"ALARM: {e}")
            self._log("  -> Click 'Unlock ($X)' and try again.")
            return
        except SerialBridgeError as e:
            self._log(f"Send failed: {e}")
            return
        for resp_line in response:
            self._log(f"  <- {resp_line}")

    def _update_pose(self, send=False):
        self.canvas.plot_pose(self.current_thetas, self.last_target_xyz)


def main():
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


# ============================================================================
# entry point
# ============================================================================
if __name__ == "__main__":
    main()
