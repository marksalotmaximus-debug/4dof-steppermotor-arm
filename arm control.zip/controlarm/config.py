"""
config.py

Central place for every number pulled from the project plan:
  - DH parameters (section 5.1)
  - Gear ratios / steps-per-rev (section 2.2 / 4)
  - Home offset calibration (section 5.4) — persisted to home_offsets.json
  - Joint limit placeholders (section 8 — NOT yet measured on real hardware)
  - Serial defaults

Nothing here should need to change as you calibrate the physical arm —
only the *values*, via the GUI's calibration panel or by hand-editing
home_offsets.json.
"""

import json
import os

# ---------------------------------------------------------------------------
# DH parameters: (a [mm], alpha [deg], d [mm])  — theta is the joint variable
# From plan section 5.1. a4 (65mm) is the wrist's own link length, per the
# plan's explicit decision to fold the tool offset into joint 4 rather than
# treat it as a separate fixed 5th link.
# ---------------------------------------------------------------------------
DH_PARAMS = [
    {"a": 21.15,  "alpha_deg": 90.0, "d": 24.25},  # joint 1 - base (yaw)
    {"a": 194.66, "alpha_deg": 0.0,  "d": 0.0},     # joint 2 - shoulder (pitch)
    {"a": 152.0,  "alpha_deg": 0.0,  "d": 0.0},     # joint 3 - elbow (pitch)
    {"a": 65.0,   "alpha_deg": 0.0,  "d": 0.0},     # joint 4 - wrist (pitch)
]

# ---------------------------------------------------------------------------
# Drivetrain (section 2.2 / 4)
# ---------------------------------------------------------------------------
MOTOR_FULL_STEPS_PER_REV = 200          # NEMA17, full-step only (DRV8825, no microstepping)
GEAR_RATIOS = [36, 36, 36, 6]            # base, shoulder, elbow, wrist
STEPS_PER_OUTPUT_REV = [MOTOR_FULL_STEPS_PER_REV * r for r in GEAR_RATIOS]
# -> [7200, 7200, 7200, 1200]

# ---------------------------------------------------------------------------
# Grbl (gcobos/grbl4axis) steps-per-unit settings.
#
# Standard grbl does NOT accept raw step counts from the host — it parses
# G-code axis words in machine "units" (mm by convention, but really just
# whatever $100-$103 says a step is worth) and does the degrees<->steps
# conversion itself, in firmware, using its own EEPROM-stored settings.
#
# We exploit that directly: define 1 G-code "unit" == 1 degree of output
# rotation for every joint, and program grbl's steps/unit settings to match
# our gear reduction. Then the app can just send G-code axis words in plain
# degrees and grbl handles the rest — no step math needed on the host side.
#
#   $100 (X, base)      = steps per degree = 7200/360 = 20.0
#   $101 (Y, shoulder)  = steps per degree = 7200/360 = 20.0
#   $102 (Z, elbow)     = steps per degree = 7200/360 = 20.0
#   $103 (A, wrist)     = steps per degree = 1200/360 = 3.3333
#
# These need to be pushed to grbl's EEPROM once (they persist across power
# cycles after that) — the GUI's "Grbl Setup" panel does this with one
# button click. gcobos/grbl4axis maps its 4th axis to the "E" word on
# Uno pins D12/D13 (variable spindle disabled to free those pins) — NOT "A".
# Confirmed against the actual gcobos/grbl4axis source: it defines
# E_STEP_BIT / E_DIRECTION_BIT on pins 12/13, and the axis word grbl's
# g-code parser accepts for it is "E". Sending "A" gets the whole line
# rejected as an unsupported/invalid g-code block.
# ---------------------------------------------------------------------------
GRBL_AXIS_LETTERS = ["X", "Y", "Z", "E"]   # base, shoulder, elbow, wrist
GRBL_STEPS_PER_DEGREE = [s / 360.0 for s in STEPS_PER_OUTPUT_REV]
# -> [20.0, 20.0, 20.0, 3.3333...]

GRBL_SETTING_NUMBERS = ["$100", "$101", "$102", "$103"]

# Default feed rate for G1 moves, in grbl's units/min — since our "unit" is
# 1 degree, this is degrees/minute. G0 (rapid) ignores this and just seeks
# at $110-$113 max rate settings instead.
#
# Bench-testing finding (bare motors, no arm assembled yet — see build log):
# F300 (the old default) sat right inside a resonance band — motors were
# badly rattly/buzzy, confirmed both by ear and by an audio spectrogram
# (~220Hz fundamental + harmonics that shifted character with feed rate).
# F1600 deg/min cleared it up dramatically for the 36:1 joints
# (base/shoulder/elbow). Very likely classic full-step resonance
# (electromagnetic + detent-torque interaction, worse when unloaded) rather
# than a wiring/driver/gearbox fault — it responded to speed, not to any
# hardware change.
#
# IMPORTANT: this was found with bare, unloaded motors. Steppers lose
# available torque as step rate climbs, so once the arm carries real
# mass/gearing load, re-check whether 1600 is still smooth *and* whether it
# still has enough torque to hold/move the payload — don't assume higher is
# always better once it's loaded.
SAFE_FEED_DEG_PER_MIN = 1600.0   # tuned on base/shoulder/elbow (36:1 joints)

DEFAULT_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN

# The wrist is geared 6:1, not 36:1 — GRBL_STEPS_PER_DEGREE[3] is 6x smaller
# than the other joints', so the same F (deg/min) value drives it at a much
# lower *actual* step rate. Scale the safe feed above so the wrist lands in
# roughly the same physical step-rate sweet spot found on the bench:
WRIST_SAFE_FEED_DEG_PER_MIN = SAFE_FEED_DEG_PER_MIN * (
    GRBL_STEPS_PER_DEGREE[0] / GRBL_STEPS_PER_DEGREE[3]
)
# -> 1600 * (20 / 3.3333) = 9600.0 deg/min — test this specifically once the
# wrist motor/gearbox is wired up; don't assume 1600 is also its sweet spot.

# ---------------------------------------------------------------------------
# Joint limits — PLACEHOLDERS ONLY. Section 8 explicitly lists these as
# not-yet-measured. Do not trust these for real hardware moves until you've
# walked each joint to its physical stops and updated this list (or better,
# fed real values through the GUI calibration panel).
# ---------------------------------------------------------------------------
JOINT_LIMITS_DEG = [
    (-150.0, 150.0),   # base
    (-90.0, 90.0),      # shoulder
    (-120.0, 120.0),    # elbow
    (-100.0, 100.0),    # wrist
]

# ---------------------------------------------------------------------------
# Home offset calibration (section 5.4)
#   THETA_HOME_OFFSET[i]: degrees to SUBTRACT from a DH-frame solved angle
#   to get the real motor command angle, i.e.:
#       motor_angle = theta_dh - home_offset
#   Persisted so you don't have to re-measure every session.
# ---------------------------------------------------------------------------
_HOME_OFFSET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "home_offsets.json")
_DEFAULT_HOME_OFFSETS = [0.0, 0.0, 0.0, 0.0]


def load_home_offsets():
    """Load home offsets from disk, falling back to zeros if not yet calibrated."""
    if os.path.exists(_HOME_OFFSET_FILE):
        try:
            with open(_HOME_OFFSET_FILE, "r") as f:
                data = json.load(f)
            offsets = data.get("home_offset_deg", _DEFAULT_HOME_OFFSETS)
            if len(offsets) == 4:
                return [float(v) for v in offsets]
        except (json.JSONDecodeError, OSError):
            pass
    return list(_DEFAULT_HOME_OFFSETS)


def save_home_offsets(offsets):
    """Persist a 4-element list of degree offsets to disk."""
    if len(offsets) != 4:
        raise ValueError("home offsets must have exactly 4 values (base, shoulder, elbow, wrist)")
    with open(_HOME_OFFSET_FILE, "w") as f:
        json.dump({"home_offset_deg": [float(v) for v in offsets]}, f, indent=2)


# ---------------------------------------------------------------------------
# Serial / firmware protocol defaults — real gcobos/grbl4axis over G-code
# ---------------------------------------------------------------------------
DEFAULT_BAUD = 115200   # grbl v0.9+ default; this fork inherits it

AXIS_LABELS = ["base", "shoulder", "elbow", "wrist"]

# NOTE ON THE 4-AXIS PIN MAPPING:
# gcobos/grbl4axis frees Uno pins D12/D13 for a 4th ("E") axis by disabling
# grbl's variable-spindle PWM feature. Confirm your CNC Shield / wiring
# actually routes the wrist driver's STEP/DIR to D12/D13 accordingly —
# this is a firmware-level pin choice made by that fork, not something this
# app controls.
#
# Protocol is now standard grbl G-code, not a custom line format:
#   - Motion:  "G90 G1 X<deg> Y<deg> Z<deg> E<deg> F<feed>\n" (absolute, feed-rate move)
#              or "G90 G0 X<deg> Y<deg> Z<deg> E<deg>\n" (absolute, rapid move)
#   - Grbl responds "ok\n" per accepted line, or "error:<n>\n" on rejection.
#   - Real-time commands (single character, no newline, no "ok" reply):
#       "?"  status report request
#       "!"  feed hold
#       "~"  cycle start / resume
#       0x18 (Ctrl-X) soft reset
#   - "$X\n" clears an ALARM lock (grbl starts in alarm state if homing is
#     enabled in settings but hasn't been run — common with no limit
#     switches wired up, which this project doesn't have per the plan).
#
# See serial_bridge.py for the implementation and gui.py's "Grbl Setup"
# panel for pushing the $100-$103 steps/unit settings shown above.
