"""
serial_bridge.py

Talks to a real grbl / gcobos/grbl4axis controller over serial using
standard grbl semantics — NOT a custom line protocol.

Key facts about how grbl actually behaves, baked into this module:

  - On opening the serial port, grbl resets and prints a startup banner
    like "Grbl 0.9j ['$' for help]" after ~1-2 seconds. We wait for and
    capture that.
  - Every G-code line you send gets exactly one response line back:
    "ok" on success, or "error:<n>" on rejection. We send one line at a
    time and block until that response arrives (grbl's RX buffer is small
    — 127 bytes — so this simple one-at-a-time flow is the safe way to
    drive it from a GUI that sends one pose at a time, as opposed to
    streaming a whole G-code file, which would need character-counting).
  - Real-time commands are single bytes, sent with NO trailing newline,
    and do NOT get an "ok" response: "?" (status query), "!" (feed hold),
    "~" (cycle start/resume), and 0x18 / Ctrl-X (soft reset).
  - Grbl settings ($100, $101, ...) are pushed the same way as a G-code
    line: "$100=20.000\n" gets an "ok" back and is stored in EEPROM
    immediately (persists across power cycles).
  - If grbl's homing-required setting is on but no homing cycle has been
    run (this project has no limit switches per the plan), grbl boots
    into ALARM state and rejects all motion until you send "$X\n" to
    clear the lock, or run a homing cycle it doesn't have hardware for.
    This bridge exposes unlock() for that.
"""

import time

import serial
import serial.tools.list_ports

import config


class SerialBridgeError(RuntimeError):
    pass


class GrblAlarmError(SerialBridgeError):
    """Raised when grbl rejects a move because it's in ALARM state."""
    pass


class SerialBridge:
    def __init__(self):
        self._ser = None
        self.startup_banner = []
        self.last_status = ""

    # -- connection management ------------------------------------------------

    @staticmethod
    def list_ports():
        return [(p.device, p.description) for p in serial.tools.list_ports.comports()]

    def connect(self, port, baud=None, timeout=2.0):
        if baud is None:
            baud = config.DEFAULT_BAUD
        if self.is_connected():
            self.disconnect()
        try:
            self._ser = serial.Serial(port, baud, timeout=timeout)
        except serial.SerialException as e:
            self._ser = None
            raise SerialBridgeError(f"Failed to open {port}: {e}") from e

        # Grbl resets on serial open (Arduino auto-reset via DTR) and prints
        # a startup banner a moment later. Capture it rather than discarding
        # it, since it also confirms which grbl version/build is on there.
        self.startup_banner = []
        deadline = time.time() + 3.0
        time.sleep(1.5)  # let the bootloader/grbl init finish before reading
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line:
                    self.startup_banner.append(line)
            else:
                time.sleep(0.05)

    def disconnect(self):
        if self._ser is not None:
            try:
                self._ser.close()
            finally:
                self._ser = None

    def is_connected(self):
        return self._ser is not None and self._ser.is_open

    # -- core line protocol ------------------------------------------------

    def send_line(self, line, timeout=10.0):
        """
        Send one G-code / '$' line, block until grbl responds with 'ok' or
        'error:<n>'. Returns the full list of lines received (there may be
        extra informational lines before the ok/error, e.g. for '$$').
        Raises GrblAlarmError on ALARM responses, SerialBridgeError on
        error:<n> responses or a timeout.
        """
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")

        if not line.endswith("\n"):
            line += "\n"
        self._ser.write(line.encode("utf-8"))

        lines = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._ser.in_waiting:
                raw = self._ser.readline().decode("utf-8", errors="replace").strip()
                if not raw:
                    continue
                lines.append(raw)
                lower = raw.lower()
                if lower == "ok":
                    return lines
                if lower.startswith("error:"):
                    raise SerialBridgeError(f"Grbl rejected '{line.strip()}': {raw}")
                if lower.startswith("alarm:"):
                    raise GrblAlarmError(
                        f"Grbl is in ALARM state ({raw}). Send $X to unlock before moving."
                    )
            else:
                time.sleep(0.02)

        raise SerialBridgeError(f"Timed out waiting for response to '{line.strip()}'.")

    # -- real-time single-byte commands (no newline, no 'ok') ---------------

    def request_status(self):
        """Send '?' and capture the '<...>' status report line grbl sends back."""
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"?")
        deadline = time.time() + 2.0
        while time.time() < deadline:
            if self._ser.in_waiting:
                line = self._ser.readline().decode("utf-8", errors="replace").strip()
                if line.startswith("<") and line.endswith(">"):
                    self.last_status = line
                    return line
            else:
                time.sleep(0.02)
        return ""

    def feed_hold(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"!")

    def cycle_start_resume(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(b"~")

    def soft_reset(self):
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")
        self._ser.write(bytes([0x18]))
        time.sleep(0.5)

    def unlock(self):
        """Clear an ALARM lock (grbl boots into alarm if homing-required but not yet homed)."""
        return self.send_line("$X")

    # -- G-code construction & sending --------------------------------------

    def build_move_gcode(self, motor_angles_deg, feed_deg_per_min=None, rapid=False):
        """
        motor_angles_deg: 4 values already home-offset-adjusted (see
        kinematics.apply_home_offset) — these get sent directly as axis
        words, in absolute positioning mode (G90).

        feed_deg_per_min: ignored if rapid=True (uses G0). Required
        (falls back to config.DEFAULT_FEED_DEG_PER_MIN) for G1 moves.
        """
        axis_words = " ".join(
            f"{letter}{angle:.3f}"
            for letter, angle in zip(config.GRBL_AXIS_LETTERS, motor_angles_deg)
        )
        if rapid:
            return f"G90 G0 {axis_words}"
        feed = feed_deg_per_min if feed_deg_per_min is not None else config.DEFAULT_FEED_DEG_PER_MIN
        return f"G90 G1 {axis_words} F{feed:.1f}"

    def send_move(self, motor_angles_deg, feed_deg_per_min=None, rapid=False, timeout=15.0):
        """Build and send an absolute-position move. Returns grbl's response lines."""
        line = self.build_move_gcode(motor_angles_deg, feed_deg_per_min, rapid)
        return self.send_line(line, timeout=timeout)

    def push_steps_per_unit_settings(self):
        """
        One-time setup helper: push config.GRBL_STEPS_PER_DEGREE into grbl's
        $100-$103 EEPROM settings so 1 G-code unit == 1 output degree for
        every joint. Returns a list of (setting, value, response_lines).
        """
        results = []
        for setting, value in zip(config.GRBL_SETTING_NUMBERS, config.GRBL_STEPS_PER_DEGREE):
            line = f"{setting}={value:.4f}"
            response = self.send_line(line)
            results.append((setting, value, response))
        return results

    def send_raw(self, line):
        """Send an arbitrary raw line and wait for ok/error — for manual debugging."""
        return self.send_line(line)

    def stream_gcode(self, lines, on_progress=None, should_abort=None, timeout=15.0):
        """
        Stream a whole list of G-code lines continuously, one after another,
        WITHOUT pausing between them. Each line is sent, we block for its
        'ok', then the next is sent immediately.

        This is what produces SMOOTH motion on grbl 0.9 (which has no jog
        mode): by keeping lines flowing with no artificial gap, grbl's
        planner keeps its look-ahead buffer full and blends cornering
        velocity between consecutive short moves instead of stopping at each
        waypoint. (This is exactly how a CNC toolpath of many tiny segments
        comes out smooth.)

        Because send_line blocks, callers should run this on a background
        thread so the GUI stays responsive.

        Args:
          lines:        list of G-code strings (no trailing newline needed)
          on_progress:  optional callback(index, total, line, response_lines)
                        called after each line is acknowledged
          should_abort: optional callable() -> bool, checked BEFORE each
                        line; if it returns True, we send a feed-hold (!)
                        and stop. Returns early with the count sent so far.
          timeout:      per-line ok timeout

        Returns (sent_count, aborted: bool).
        """
        if not self.is_connected():
            raise SerialBridgeError("Not connected to any serial port.")

        total = len(lines)
        for i, line in enumerate(lines):
            if should_abort is not None and should_abort():
                # Slam a feed-hold so the machine stops promptly rather than
                # finishing whatever's already buffered ahead.
                try:
                    self.feed_hold()
                except SerialBridgeError:
                    pass
                return i, True

            response = self.send_line(line, timeout=timeout)
            if on_progress is not None:
                on_progress(i, total, line, response)

        return total, False

    def read_available(self):
        """Non-blocking read of whatever's currently buffered (e.g. unsolicited grbl messages)."""
        if not self.is_connected():
            return []
        lines = []
        while self._ser.in_waiting:
            line = self._ser.readline().decode("utf-8", errors="replace").strip()
            if line:
                lines.append(line)
        return lines
