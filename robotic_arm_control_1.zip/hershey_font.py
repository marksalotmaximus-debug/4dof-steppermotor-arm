"""
hershey_font.py — a compact, self-contained single-stroke ("Hershey style")
vector font, plus a text -> strokes engine for the arm's writing demo.

WHY SINGLE-STROKE: normal fonts are *outline* fonts (each glyph is a filled
shape), so tracing them draws the outline of fat letters. For writing with a
marker you want the *centerline* of each stroke — the path a pen actually
follows. Each glyph here is defined as a list of strokes; each stroke is a
polyline of (x, y) points. The pen is DOWN while drawing a stroke and LIFTS
between strokes. This is exactly the classic plotter/engraver representation.

Coordinate system per glyph: x runs left->right, y runs bottom->top, both
roughly in [0, 1] for the em-square (baseline at y=0, cap height ~1.0). The
engine scales/positions these into real mm on the arm's work plane.

The glyph set covers A-Z, 0-9, space, and a few common punctuation marks —
enough for the "write a word" demo. Lowercase falls back to uppercase.
"""

# Each glyph: list of strokes; each stroke: list of (x, y) vertices.
# Empty list = no ink (e.g. space). Designed on a ~0..1 em square,
# baseline y=0, cap height y=1, nominal advance width ~0.8.
_GLYPHS = {
    " ": [],
    "A": [[(0.0, 0.0), (0.4, 1.0), (0.8, 0.0)], [(0.15, 0.4), (0.65, 0.4)]],
    "B": [[(0.0, 0.0), (0.0, 1.0), (0.55, 1.0), (0.7, 0.85), (0.7, 0.6),
           (0.55, 0.5), (0.0, 0.5)],
          [(0.55, 0.5), (0.72, 0.38), (0.72, 0.12), (0.55, 0.0), (0.0, 0.0)]],
    "C": [[(0.75, 0.8), (0.5, 1.0), (0.25, 1.0), (0.05, 0.8), (0.0, 0.5),
           (0.05, 0.2), (0.25, 0.0), (0.5, 0.0), (0.75, 0.2)]],
    "D": [[(0.0, 0.0), (0.0, 1.0), (0.45, 1.0), (0.7, 0.8), (0.75, 0.5),
           (0.7, 0.2), (0.45, 0.0), (0.0, 0.0)]],
    "E": [[(0.7, 1.0), (0.0, 1.0), (0.0, 0.0), (0.7, 0.0)],
          [(0.0, 0.5), (0.5, 0.5)]],
    "F": [[(0.7, 1.0), (0.0, 1.0), (0.0, 0.0)], [(0.0, 0.5), (0.5, 0.5)]],
    "G": [[(0.75, 0.8), (0.5, 1.0), (0.25, 1.0), (0.05, 0.8), (0.0, 0.5),
           (0.05, 0.2), (0.25, 0.0), (0.5, 0.0), (0.75, 0.2), (0.75, 0.45),
           (0.45, 0.45)]],
    "H": [[(0.0, 1.0), (0.0, 0.0)], [(0.7, 1.0), (0.7, 0.0)],
          [(0.0, 0.5), (0.7, 0.5)]],
    "I": [[(0.1, 1.0), (0.5, 1.0)], [(0.3, 1.0), (0.3, 0.0)],
          [(0.1, 0.0), (0.5, 0.0)]],
    "J": [[(0.6, 1.0), (0.6, 0.2), (0.45, 0.0), (0.2, 0.0), (0.05, 0.2)]],
    "K": [[(0.0, 1.0), (0.0, 0.0)], [(0.7, 1.0), (0.0, 0.45)],
          [(0.2, 0.6), (0.7, 0.0)]],
    "L": [[(0.0, 1.0), (0.0, 0.0), (0.7, 0.0)]],
    "M": [[(0.0, 0.0), (0.0, 1.0), (0.4, 0.4), (0.8, 1.0), (0.8, 0.0)]],
    "N": [[(0.0, 0.0), (0.0, 1.0), (0.7, 0.0), (0.7, 1.0)]],
    "O": [[(0.25, 1.0), (0.05, 0.8), (0.0, 0.5), (0.05, 0.2), (0.25, 0.0),
           (0.5, 0.0), (0.7, 0.2), (0.75, 0.5), (0.7, 0.8), (0.5, 1.0),
           (0.25, 1.0)]],
    "P": [[(0.0, 0.0), (0.0, 1.0), (0.55, 1.0), (0.72, 0.85), (0.72, 0.62),
           (0.55, 0.5), (0.0, 0.5)]],
    "Q": [[(0.25, 1.0), (0.05, 0.8), (0.0, 0.5), (0.05, 0.2), (0.25, 0.0),
           (0.5, 0.0), (0.7, 0.2), (0.75, 0.5), (0.7, 0.8), (0.5, 1.0),
           (0.25, 1.0)],
          [(0.45, 0.25), (0.75, -0.05)]],
    "R": [[(0.0, 0.0), (0.0, 1.0), (0.55, 1.0), (0.72, 0.85), (0.72, 0.62),
           (0.55, 0.5), (0.0, 0.5)],
          [(0.35, 0.5), (0.72, 0.0)]],
    "S": [[(0.72, 0.8), (0.5, 1.0), (0.22, 1.0), (0.05, 0.85), (0.05, 0.62),
           (0.22, 0.5), (0.5, 0.5), (0.67, 0.38), (0.67, 0.15), (0.5, 0.0),
           (0.22, 0.0), (0.0, 0.2)]],
    "T": [[(0.0, 1.0), (0.7, 1.0)], [(0.35, 1.0), (0.35, 0.0)]],
    "U": [[(0.0, 1.0), (0.0, 0.2), (0.2, 0.0), (0.5, 0.0), (0.7, 0.2),
           (0.7, 1.0)]],
    "V": [[(0.0, 1.0), (0.35, 0.0), (0.7, 1.0)]],
    "W": [[(0.0, 1.0), (0.2, 0.0), (0.4, 0.6), (0.6, 0.0), (0.8, 1.0)]],
    "X": [[(0.0, 1.0), (0.7, 0.0)], [(0.0, 0.0), (0.7, 1.0)]],
    "Y": [[(0.0, 1.0), (0.35, 0.5), (0.7, 1.0)], [(0.35, 0.5), (0.35, 0.0)]],
    "Z": [[(0.0, 1.0), (0.7, 1.0), (0.0, 0.0), (0.7, 0.0)]],
    "0": [[(0.25, 1.0), (0.05, 0.8), (0.0, 0.5), (0.05, 0.2), (0.25, 0.0),
           (0.5, 0.0), (0.7, 0.2), (0.75, 0.5), (0.7, 0.8), (0.5, 1.0),
           (0.25, 1.0)], [(0.1, 0.15), (0.65, 0.85)]],
    "1": [[(0.15, 0.8), (0.35, 1.0), (0.35, 0.0)], [(0.1, 0.0), (0.6, 0.0)]],
    "2": [[(0.05, 0.8), (0.25, 1.0), (0.5, 1.0), (0.7, 0.8), (0.7, 0.6),
           (0.0, 0.0), (0.72, 0.0)]],
    "3": [[(0.05, 0.85), (0.3, 1.0), (0.55, 1.0), (0.7, 0.85), (0.55, 0.55),
           (0.3, 0.55)], [(0.55, 0.55), (0.72, 0.35), (0.55, 0.05),
           (0.3, 0.0), (0.05, 0.15)]],
    "4": [[(0.5, 0.0), (0.5, 1.0), (0.0, 0.35), (0.72, 0.35)]],
    "5": [[(0.65, 1.0), (0.1, 1.0), (0.05, 0.55), (0.35, 0.62), (0.6, 0.5),
           (0.7, 0.3), (0.6, 0.08), (0.35, 0.0), (0.1, 0.05)]],
    "6": [[(0.6, 0.9), (0.4, 1.0), (0.2, 0.9), (0.05, 0.55), (0.05, 0.2),
           (0.2, 0.0), (0.45, 0.0), (0.65, 0.15), (0.68, 0.4), (0.5, 0.55),
           (0.2, 0.55), (0.05, 0.4)]],
    "7": [[(0.0, 1.0), (0.72, 1.0), (0.3, 0.0)]],
    "8": [[(0.3, 0.55), (0.1, 0.68), (0.1, 0.85), (0.3, 1.0), (0.5, 1.0),
           (0.68, 0.85), (0.68, 0.68), (0.5, 0.55), (0.3, 0.55),
           (0.08, 0.4), (0.08, 0.15), (0.3, 0.0), (0.5, 0.0), (0.72, 0.15),
           (0.72, 0.4), (0.5, 0.55)]],
    "9": [[(0.65, 0.6), (0.5, 0.45), (0.25, 0.45), (0.08, 0.6), (0.1, 0.85),
           (0.3, 1.0), (0.5, 1.0), (0.67, 0.85), (0.7, 0.45), (0.55, 0.1),
           (0.35, 0.0), (0.15, 0.08)]],
    "-": [[(0.1, 0.5), (0.6, 0.5)]],
    ".": [[(0.3, 0.0), (0.35, 0.05), (0.3, 0.1), (0.25, 0.05), (0.3, 0.0)]],
    ",": [[(0.32, 0.1), (0.28, 0.0), (0.22, -0.1)]],
    "!": [[(0.3, 1.0), (0.3, 0.25)], [(0.3, 0.05), (0.32, 0.07),
           (0.3, 0.09), (0.28, 0.07), (0.3, 0.05)]],
    "?": [[(0.05, 0.8), (0.25, 1.0), (0.5, 1.0), (0.68, 0.82), (0.68, 0.62),
           (0.35, 0.45), (0.35, 0.3)], [(0.35, 0.05), (0.37, 0.07),
           (0.35, 0.09), (0.33, 0.07), (0.35, 0.05)]],
    "'": [[(0.35, 1.0), (0.32, 0.8)]],
    ":": [[(0.3, 0.65), (0.33, 0.68), (0.3, 0.71), (0.27, 0.68), (0.3, 0.65)],
          [(0.3, 0.2), (0.33, 0.23), (0.3, 0.26), (0.27, 0.23), (0.3, 0.2)]],
}

# Per-glyph advance width (where the next glyph starts, in em units).
# Defaults to 0.8 for anything unlisted; space and narrow glyphs differ.
_ADVANCE = {
    " ": 0.5, "I": 0.6, "!": 0.5, ".": 0.5, ",": 0.5, "'": 0.4, ":": 0.5,
    "-": 0.7, "M": 0.95, "W": 0.95, "1": 0.65,
}
_DEFAULT_ADVANCE = 0.82


def available_chars():
    """Return the set of directly-supported characters (uppercase + digits + punct)."""
    return set(_GLYPHS.keys())


def text_to_strokes(text, height_mm=40.0, letter_spacing_mm=4.0,
                    word_spacing_mm=None, origin=(0.0, 0.0)):
    """
    Convert a text string into a list of strokes in millimetres, laid out
    left-to-right along +x, baseline at origin[1], starting at origin[0].

    Each returned stroke is a list of (x_mm, y_mm) points; the pen is DOWN
    while tracing a stroke and lifts between strokes. Lowercase is folded to
    uppercase. Unsupported characters are skipped (they still advance as a
    space so spacing stays sensible).

    Returns (strokes, width_mm, height_mm):
      strokes    : list of [(x, y), ...] polylines, in mm, on the plane
      width_mm   : total advance width of the rendered text
      height_mm  : cap height used (== height_mm arg)
    """
    if word_spacing_mm is None:
        word_spacing_mm = height_mm * 0.4

    ox, oy = origin
    cursor = ox
    strokes = []

    for ch in text:
        up = ch.upper()
        if ch == " ":
            cursor += word_spacing_mm
            continue
        glyph = _GLYPHS.get(up)
        if glyph is None:
            # Unsupported: advance like a space so layout stays readable.
            cursor += _DEFAULT_ADVANCE * height_mm + letter_spacing_mm
            continue
        for stroke in glyph:
            pts = [(cursor + px * height_mm, oy + py * height_mm) for (px, py) in stroke]
            strokes.append(pts)
        adv = _ADVANCE.get(up, _DEFAULT_ADVANCE)
        cursor += adv * height_mm + letter_spacing_mm

    width_mm = cursor - ox
    return strokes, width_mm, height_mm


def strokes_to_pen_path(strokes, plane="xy_table", pen_down_z=0.0,
                        pen_up_z=15.0, base_x=250.0, base_y=0.0, psi_deg=-90.0,
                        travel_first=True):
    """
    Turn 2D strokes (in the plane's own u,v mm coords) into a full 4D pen
    path of (x, y, z, psi) waypoints in the arm's world frame, inserting
    pen-up / pen-down Z transitions between strokes.

    plane:
      "xy_table" — writing flat on a horizontal surface. The glyph's local
        u -> world X (reach direction offset by base_x), v -> world Y
        (offset by base_y). Pen height is world Z, controlled by pen_down_z
        (marker touching paper) and pen_up_z (lifted clear). psi_deg is the
        fixed tool tilt (default -90 = pointing straight down).

    The sequence for each stroke is:
      (move to stroke start at pen_up_z) -> (lower to pen_down_z) ->
      (trace the stroke at pen_down_z) -> (raise to pen_up_z)
    so the marker only touches paper during the stroke itself.

    Returns a flat list of (x, y, z, psi) waypoints ready for
    kinematics.plan_waypoint_path (which will densify + IK + validate).
    """
    path = []

    def world(u, v, z):
        # xy_table: u along +X (reach), v along +Y, z world height.
        return (base_x + u, base_y + v, z, psi_deg)

    for si, stroke in enumerate(strokes):
        if not stroke:
            continue
        u0, v0 = stroke[0]
        # Travel to the start of this stroke with the pen up.
        path.append(world(u0, v0, pen_up_z))
        # Lower the pen.
        path.append(world(u0, v0, pen_down_z))
        # Trace the stroke on the paper.
        for (u, v) in stroke:
            path.append(world(u, v, pen_down_z))
        # Lift the pen at the end.
        uL, vL = stroke[-1]
        path.append(world(uL, vL, pen_up_z))

    return path


def plan_writing_path(pen_path, solve_fn, interpolate_fn, max_tilt_deg=15.0,
                      max_segment_mm=6.0, tilt_step_deg=1.0):
    """
    Densify a pen path and solve IK at every point, keeping the marker within
    +/- max_tilt_deg of straight-down (psi = -90) rather than a single fixed
    angle. At each densified point we try psi = -90 first, then small tilts
    outward (+/-1, +/-2, ...) up to max_tilt_deg, taking the first that's
    fully within joint limits.

    Why clamped tilt instead of a hard fixed psi: a perfectly vertical marker
    is the most reach-constrained pose, and small tilts (a few degrees) are
    visually fine for writing while dramatically enlarging the reachable
    writing area. max_tilt_deg=0 forces strictly vertical.

    This is passed the solver/interpolator as callables so the font module
    stays free of a hard dependency on the kinematics module:
      solve_fn(x, y, z, psi_deg) -> result dict with "thetas" and "violations",
                                     or raises the unreachable exception
      interpolate_fn(poses, max_seg_mm, max_seg_psi_deg) -> densified poses

    Returns (thetas_list, dense_poses, psi_used_list) on success, or raises
    WritingPlanError(index, point) at the first point that can't be solved
    within the tilt band and joint limits.
    """
    dense = interpolate_fn(pen_path, max_segment_mm, 3.0)

    # Build the tilt search order: 0, +step, -step, +2*step, -2*step, ...
    tilts = [0.0]
    d = tilt_step_deg
    while d <= max_tilt_deg + 1e-9:
        tilts.append(d)
        tilts.append(-d)
        d += tilt_step_deg

    thetas_list = []
    psi_used = []
    for i, (x, y, z, psi_base) in enumerate(dense):
        solved = None
        for dp in tilts:
            psi = psi_base + dp
            try:
                r = solve_fn(x, y, z, psi)
            except Exception:
                continue
            if not r["violations"]:
                solved = (r["thetas"], psi)
                break
        if solved is None:
            raise WritingPlanError(
                f"Writing point {i} ({x:.1f}, {y:.1f}, {z:.1f}) can't be reached "
                f"with the marker within {max_tilt_deg:.0f} deg of vertical and "
                f"inside joint limits. Try moving the text (position/height), "
                f"shrinking it, or allowing more tilt.",
                index=i, point=(x, y, z))
        thetas_list.append(solved[0])
        psi_used.append(solved[1])

    return thetas_list, dense, psi_used


class WritingPlanError(ValueError):
    """Raised when a writing path can't be solved within the tilt band + limits."""
    def __init__(self, message, index=None, point=None):
        super().__init__(message)
        self.index = index
        self.point = point

