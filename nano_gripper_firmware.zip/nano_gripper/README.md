# nano_gripper — ARMGRIP servo controller firmware

Firmware for a **second, independent Arduino (Nano)** that drives the
gripper's servo(s) through a PCA9685 over I2C. It's separate from the Uno
running `grbl4axis` because grbl owns Timer1 for step generation (so the
`Servo` library can't coexist with it), and the Uno's flash is already
nearly full with the 4-axis fork.

## Files

- **`nano_gripper.ino`** — the sketch: PCA9685 driver (hand-rolled, no
  library dependency), serial line reader, and the `setup()`/`loop()` entry
  points.
- **`gripper_logic.h`** — all hardware-free logic (PCA9685 math, angle/pulse
  conversion, smoothstep move interpolation, and the ASCII command parser).
  Kept separate so it can be unit-tested on a desktop with g++ before ever
  being flashed.

## Wiring

- PCA9685 **VCC** → Nano 5V, **GND** → Nano GND, **SDA/SCL** → Nano A4/A5.
- PCA9685 **V+** → servo power rail from a buck converter (do **not** power
  servos from the Nano's 5V pin) — set the buck to the servo's rated voltage
  (6.0V for MG90S) before connecting anything, and tie all grounds together
  (PSU, buck converter, PCA9685, Nano).
- **OE** (output enable, active-LOW) → Nano pin **D7**. Held high (disabled)
  until the PCA9685 init succeeds, so nothing twitches at power-up.
- Servo signal wires → PCA9685 channels 0–3 (`MAX_SERVOS = 4`).

## Protocol

Line-based ASCII over serial at **115200 baud**, `ok` / `err:<reason>`
replies mirroring grbl's convention. Optional `@<n> ` prefix targets a
servo channel (default channel 0).

```
V?                 identify        -> "ARMGRIP v1 servos=4 pca=ok"
?                  status          -> "<idle ch=0 pos=90.0 target=90.0 attached=1 killed=0>"
A[angle]           attach, optionally declaring the assumed current angle
D                  detach (limp)
O / C              open / close preset
S<a> [T<ms>]       move to angle, optional explicit duration in ms
R<deg/s>           set default sweep rate
L<min> <max>       set travel limits (degrees)
E<open> <close>    set the open / close presets
U<minUs> <maxUs>   set the servo's pulse-width range
X / Z              emergency output kill / restore
H                  help
```

Human-readable on purpose — you can bring the hardware up and drive it from
a serial monitor before any app code exists.

## Design decisions

- **Out-of-range angles are refused, not clamped.** A servo driven into a
  mechanical stop stalls and cooks itself, so `S` returns
  `err:out_of_range <min>..<max>` instead of silently clamping.
- **Moves use smoothstep easing**, not a snap to target. Gentler on the
  gripper fingers, avoids the current spike of a full-speed step change, and
  looks better on video.
- **Channels start silent** (`pcaSetPWM(ch, 0, 0)`) — nothing moves at
  power-up until the app explicitly attaches a channel.
- **A missing PCA9685 is explicit.** If the init sequence can't read/write
  `MODE1`, the boot banner reports `pca=missing` and prints
  `err:no_pca9685 check_wiring_addr_0x40` instead of a mysterious dead servo.
  Note this only confirms the chip's **logic side** (I2C) is alive — it says
  nothing about the V+ servo power rail from the buck converter, which needs
  its own check.
- **Settings are not stored in EEPROM.** The desktop app owns the
  configuration (`gripper_config.json`) and pushes it on connect each time —
  the same "one source of truth" pattern used for home offsets, tool offset,
  and the motion profile elsewhere in this project.

## Bring-up order

1. Flash with the servo power rail (V+) disconnected.
2. Open a serial monitor at 115200 baud and confirm you see
   `ARMGRIP v1 servos=4 pca=ok`.
3. Power the servo rail, then test with a bare servo (not yet fitted to the
   gripper) using `A90`, `S120`, `S60` from the serial monitor.
4. Only once that's confirmed working, fit the gripper mechanism.

## Testing

`gripper_logic.h` has no Arduino dependencies (no `Serial`, no `Wire`, no
pin access), so it can be compiled and unit-tested standalone with g++:

```bash
g++ -std=c++11 -Wall -I. your_test_harness.cpp -o test && ./test
```

This repo's development history included two such test suites (PCA9685
math + parser, and a sketch-level integration harness using stubbed
`Serial`/`Wire`) totaling 101 passing assertions. Those test harness files
weren't preserved verbatim in this drop — only the sketch and header are
included here — but the header's pure-function design means re-creating a
harness is straightforward: every function takes plain values in and
returns a plain value out.

## Arduino IDE note

`#include "gripper_logic.h"` (quotes, not angle brackets) tells the IDE to
look in the sketch folder first, so it's found automatically with zero
configuration — it'll show up as a second tab when you open `nano_gripper.ino`.
If you add test `.cpp` files back in, put them in a subfolder (e.g. `tests/`)
since the Arduino IDE compiles every `.cpp` in the sketch root and would
otherwise try (and fail) to build them into the firmware.
