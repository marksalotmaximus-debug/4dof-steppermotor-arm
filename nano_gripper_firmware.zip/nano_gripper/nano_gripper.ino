/*
 * nano_gripper.ino — ARMGRIP servo controller for the 4-DOF arm's gripper.
 *
 * Runs on a SECOND, independent Arduino (a Nano) driving up to 4 servos
 * through a PCA9685 over I2C. It is deliberately separate from the Uno
 * running grbl4axis: grbl owns Timer1 for step generation, so the Arduino
 * Servo library can't coexist with it, and the Uno's flash is already
 * nearly full with the 4-axis fork. A hand-rolled PCA9685 driver is used
 * here instead of a library dependency, to keep the build reproducible.
 *
 * Talks a line-based ASCII protocol over serial ("ok" / "err:<reason>"
 * replies, mirroring grbl's convention). See gripper_logic.h for the full
 * command reference and the pure/testable math + parser. The protocol is
 * deliberately human-readable: you can bring the hardware up from a serial
 * monitor before any app code exists.
 *
 * SETTINGS ARE NOT STORED IN EEPROM. The desktop app owns the configuration
 * (gripper_config.json) and pushes it on connect, matching how home offsets,
 * tool offset and the motion profile already work in this project — one
 * source of truth rather than two that can silently disagree.
 */

#include <Wire.h>
#include "gripper_logic.h"

// --------------------------------------------------------------------------
// Configuration
// --------------------------------------------------------------------------

static const uint8_t  PCA9685_ADDR   = 0x40;   // default address, all jumpers open
static const uint8_t  OE_PIN         = 7;      // active-LOW output enable
static const uint8_t  MAX_SERVOS     = 4;      // PCA9685 supports 16; 4 keeps RAM small
static const uint32_t SERIAL_BAUD    = 115200;
static const uint8_t  LINE_BUF_LEN   = 48;

// PCA9685 registers
static const uint8_t REG_MODE1       = 0x00;
static const uint8_t REG_MODE2       = 0x01;
static const uint8_t REG_LED0_ON_L   = 0x06;
static const uint8_t REG_PRESCALE    = 0xFE;

static const uint8_t MODE1_RESTART   = 0x80;
static const uint8_t MODE1_AI        = 0x20;   // auto-increment
static const uint8_t MODE1_SLEEP     = 0x10;
static const uint8_t MODE1_ALLCALL   = 0x01;
static const uint8_t MODE2_OUTDRV    = 0x04;   // totem-pole outputs

// --------------------------------------------------------------------------
// Per-servo state
// --------------------------------------------------------------------------

struct ServoState {
    bool     attached;
    float    currentAngle;
    float    targetAngle;
    float    startAngle;
    uint32_t moveStartMs;
    uint32_t moveDurationMs;
    float    minAngle;
    float    maxAngle;
    float    openAngle;
    float    closeAngle;
    float    rateDegPerSec;
    float    minPulseUs;
    float    maxPulseUs;
};

static ServoState servos[MAX_SERVOS];
static bool  pcaPresent   = false;
static bool  outputsKilled = false;
static char  lineBuf[LINE_BUF_LEN];
static uint8_t lineLen = 0;

// --------------------------------------------------------------------------
// PCA9685 driver (hand-rolled — only a handful of registers, and avoiding a
// library dependency keeps the build reproducible)
// --------------------------------------------------------------------------

static bool pcaWrite8(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(PCA9685_ADDR);
    Wire.write(reg);
    Wire.write(value);
    return Wire.endTransmission() == 0;
}

static bool pcaRead8(uint8_t reg, uint8_t &out) {
    Wire.beginTransmission(PCA9685_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) return false;
    if (Wire.requestFrom((uint8_t)PCA9685_ADDR, (uint8_t)1) != 1) return false;
    out = Wire.read();
    return true;
}

/*
 * Set a channel's on/off ticks. Servos always turn on at tick 0, so `off` is
 * simply the pulse width in PCA9685 counts. off == 0 means "no pulses at
 * all", which leaves the servo unpowered and limp.
 */
static bool pcaSetPWM(uint8_t channel, uint16_t on, uint16_t off) {
    Wire.beginTransmission(PCA9685_ADDR);
    Wire.write(REG_LED0_ON_L + 4 * channel);
    Wire.write(on & 0xFF);
    Wire.write(on >> 8);
    Wire.write(off & 0xFF);
    Wire.write(off >> 8);
    return Wire.endTransmission() == 0;
}

/*
 * Init sequence. The prescale register can only be written while the chip is
 * asleep, hence the sleep/wake dance.
 */
static bool pcaInit(float freqHz) {
    uint8_t mode1;
    if (!pcaRead8(REG_MODE1, mode1)) return false;   // nothing on the bus

    if (!pcaWrite8(REG_MODE1, MODE1_ALLCALL)) return false;
    delay(5);

    // Sleep, set prescale, wake.
    if (!pcaWrite8(REG_MODE1, MODE1_ALLCALL | MODE1_SLEEP)) return false;
    if (!pcaWrite8(REG_PRESCALE, pca9685Prescale(freqHz))) return false;
    if (!pcaWrite8(REG_MODE1, MODE1_ALLCALL)) return false;
    delay(5);

    // Restart + auto-increment for multi-byte channel writes.
    if (!pcaWrite8(REG_MODE1, MODE1_RESTART | MODE1_AI | MODE1_ALLCALL)) return false;
    if (!pcaWrite8(REG_MODE2, MODE2_OUTDRV)) return false;
    return true;
}

// --------------------------------------------------------------------------
// Servo helpers
// --------------------------------------------------------------------------

static void servoDefaults(ServoState &s) {
    s.attached       = false;
    s.currentAngle   = 90.0f;
    s.targetAngle    = 90.0f;
    s.startAngle     = 90.0f;
    s.moveStartMs    = 0;
    s.moveDurationMs = 0;
    s.minAngle       = 0.0f;
    s.maxAngle       = 180.0f;
    s.openAngle      = 120.0f;
    s.closeAngle     = 60.0f;
    s.rateDegPerSec  = 120.0f;
    s.minPulseUs     = 500.0f;    // MG90S typical
    s.maxPulseUs     = 2400.0f;
}

static void writeServo(uint8_t ch, ServoState &s) {
    if (!pcaPresent || outputsKilled) return;
    if (!s.attached) {
        pcaSetPWM(ch, 0, 0);      // no pulses -> limp
        return;
    }
    uint16_t count = angleToCount(s.currentAngle, s.minAngle, s.maxAngle,
                                  s.minPulseUs, s.maxPulseUs);
    pcaSetPWM(ch, 0, count);
}

static void startMove(uint8_t ch, ServoState &s, float target, uint32_t durationMs) {
    target = clampf(target, s.minAngle, s.maxAngle);
    s.startAngle     = s.currentAngle;
    s.targetAngle    = target;
    s.moveStartMs    = millis();
    s.moveDurationMs = durationMs;
    if (!s.attached) {
        // Attaching implicitly: we don't know where the horn physically is,
        // so jump rather than interpolate from a fictional start.
        s.attached     = true;
        s.currentAngle = target;
        s.startAngle   = target;
        s.moveDurationMs = 0;
    }
    writeServo(ch, s);
}

static void updateMotion() {
    uint32_t now = millis();
    for (uint8_t ch = 0; ch < MAX_SERVOS; ch++) {
        ServoState &s = servos[ch];
        if (!s.attached) continue;
        if (s.currentAngle == s.targetAngle) continue;

        uint32_t elapsed = now - s.moveStartMs;
        float a = interpolateAngle(s.startAngle, s.targetAngle,
                                   elapsed, s.moveDurationMs);
        // Only push a new value when it actually changed enough to matter —
        // the PCA9685 has ~0.9deg of resolution at 50Hz, so finer updates are
        // wasted I2C traffic.
        if (fabsf(a - s.currentAngle) >= 0.2f || a == s.targetAngle) {
            s.currentAngle = a;
            writeServo(ch, s);
        }
    }
}

static bool anyMoving() {
    for (uint8_t ch = 0; ch < MAX_SERVOS; ch++) {
        if (servos[ch].attached && servos[ch].currentAngle != servos[ch].targetAngle)
            return true;
    }
    return false;
}

// --------------------------------------------------------------------------
// Command handling
// --------------------------------------------------------------------------

static void printHelp() {
    Serial.println(F("ARMGRIP commands (optional '@n ' channel prefix):"));
    Serial.println(F("  V?           identify"));
    Serial.println(F("  ?            status"));
    Serial.println(F("  A[angle]     attach (optionally assume current angle)"));
    Serial.println(F("  D            detach (limp)"));
    Serial.println(F("  O / C        open / close preset"));
    Serial.println(F("  S<a> [T<ms>] move to angle, optional duration"));
    Serial.println(F("  R<deg/s>     default sweep rate"));
    Serial.println(F("  L<min> <max> travel limits"));
    Serial.println(F("  E<op> <cl>   open/close presets"));
    Serial.println(F("  U<min> <max> pulse width range (us)"));
    Serial.println(F("  X / Z        output kill / restore"));
}

static void handleLine(const char *line) {
    ParsedCommand c = parseCommand(line);

    if (!c.valid) {
        Serial.println(F("err:parse"));
        return;
    }

    uint8_t ch = (c.channel < 0) ? 0 : (uint8_t)c.channel;
    if (ch >= MAX_SERVOS) {
        Serial.println(F("err:channel"));
        return;
    }
    ServoState &s = servos[ch];

    switch (c.cmd) {

    case 'V':
        Serial.print(F("ARMGRIP v1 servos="));
        Serial.print(MAX_SERVOS);
        Serial.print(F(" pca="));
        Serial.println(pcaPresent ? F("ok") : F("missing"));
        Serial.println(F("ok"));
        break;

    case '?': {
        Serial.print(anyMoving() ? F("<moving") : F("<idle"));
        Serial.print(F(" ch=")); Serial.print(ch);
        Serial.print(F(" pos=")); Serial.print(s.currentAngle, 1);
        Serial.print(F(" target=")); Serial.print(s.targetAngle, 1);
        Serial.print(F(" attached=")); Serial.print(s.attached ? 1 : 0);
        Serial.print(F(" killed=")); Serial.print(outputsKilled ? 1 : 0);
        Serial.println(F(">"));
        Serial.println(F("ok"));
        break;
    }

    case 'A':
        if (c.hasArg1) {
            s.currentAngle = clampf(c.arg1, s.minAngle, s.maxAngle);
            s.targetAngle  = s.currentAngle;
        }
        s.attached = true;
        writeServo(ch, s);
        Serial.println(F("ok"));
        break;

    case 'D':
        s.attached = false;
        writeServo(ch, s);
        Serial.println(F("ok"));
        break;

    case 'O':
        startMove(ch, s, s.openAngle,
                  moveDurationMs(s.currentAngle, s.openAngle, s.rateDegPerSec));
        Serial.println(F("ok"));
        break;

    case 'C':
        startMove(ch, s, s.closeAngle,
                  moveDurationMs(s.currentAngle, s.closeAngle, s.rateDegPerSec));
        Serial.println(F("ok"));
        break;

    case 'S': {
        if (!c.hasArg1) { Serial.println(F("err:need_angle")); break; }
        float target = c.arg1;
        if (target < s.minAngle - 0.001f || target > s.maxAngle + 0.001f) {
            // Refuse rather than silently clamp: a host asking for an angle
            // outside the mechanism's travel is a bug worth surfacing, and
            // driving a servo into a stop stalls and overheats it.
            Serial.print(F("err:out_of_range "));
            Serial.print(s.minAngle, 1); Serial.print(F(".."));
            Serial.println(s.maxAngle, 1);
            break;
        }
        uint32_t dur = c.hasArg2 ? (uint32_t)c.arg2
                                 : moveDurationMs(s.currentAngle, target, s.rateDegPerSec);
        startMove(ch, s, target, dur);
        Serial.println(F("ok"));
        break;
    }

    case 'R':
        if (!c.hasArg1 || c.arg1 <= 0) { Serial.println(F("err:need_rate")); break; }
        s.rateDegPerSec = c.arg1;
        Serial.println(F("ok"));
        break;

    case 'L':
        if (!c.hasArg1 || !c.hasArg2) { Serial.println(F("err:need_two")); break; }
        s.minAngle = clampf(min(c.arg1, c.arg2), 0.0f, 180.0f);
        s.maxAngle = clampf(max(c.arg1, c.arg2), 0.0f, 180.0f);
        s.openAngle  = clampf(s.openAngle,  s.minAngle, s.maxAngle);
        s.closeAngle = clampf(s.closeAngle, s.minAngle, s.maxAngle);
        Serial.println(F("ok"));
        break;

    case 'E':
        if (!c.hasArg1 || !c.hasArg2) { Serial.println(F("err:need_two")); break; }
        s.openAngle  = clampf(c.arg1, s.minAngle, s.maxAngle);
        s.closeAngle = clampf(c.arg2, s.minAngle, s.maxAngle);
        Serial.println(F("ok"));
        break;

    case 'U':
        if (!c.hasArg1 || !c.hasArg2) { Serial.println(F("err:need_two")); break; }
        s.minPulseUs = clampf(c.arg1, 200.0f, 3000.0f);
        s.maxPulseUs = clampf(c.arg2, 200.0f, 3000.0f);
        Serial.println(F("ok"));
        break;

    case 'X':
        outputsKilled = true;
        if (OE_PIN != 255) digitalWrite(OE_PIN, HIGH);   // active-LOW enable
        for (uint8_t i = 0; i < MAX_SERVOS; i++) pcaSetPWM(i, 0, 0);
        Serial.println(F("ok"));
        break;

    case 'Z':
        outputsKilled = false;
        if (OE_PIN != 255) digitalWrite(OE_PIN, LOW);
        for (uint8_t i = 0; i < MAX_SERVOS; i++) writeServo(i, servos[i]);
        Serial.println(F("ok"));
        break;

    case 'H':
        printHelp();
        Serial.println(F("ok"));
        break;

    default:
        Serial.println(F("err:unknown"));
        break;
    }
}

// --------------------------------------------------------------------------
// Arduino entry points
// --------------------------------------------------------------------------

void setup() {
    Serial.begin(SERIAL_BAUD);

    pinMode(OE_PIN, OUTPUT);
    digitalWrite(OE_PIN, HIGH);        // outputs disabled until the chip is up

    for (uint8_t i = 0; i < MAX_SERVOS; i++) servoDefaults(servos[i]);

    Wire.begin();
    Wire.setClock(400000);             // PCA9685 handles fast-mode I2C

    pcaPresent = pcaInit(SERVO_FREQ_HZ);

    if (pcaPresent) {
        // Start with every channel silent so nothing twitches at power-up.
        for (uint8_t i = 0; i < MAX_SERVOS; i++) pcaSetPWM(i, 0, 0);
        digitalWrite(OE_PIN, LOW);     // enable outputs (channels still idle)
    }

    Serial.print(F("ARMGRIP v1 servos="));
    Serial.print(MAX_SERVOS);
    Serial.print(F(" pca="));
    Serial.println(pcaPresent ? F("ok") : F("missing"));
    if (!pcaPresent) {
        // Explicit rather than a silent no-op: "servo doesn't move" is much
        // harder to debug than a named I2C failure.
        Serial.println(F("err:no_pca9685 check_wiring_addr_0x40"));
    }
}

void loop() {
    updateMotion();

    while (Serial.available()) {
        char ch = (char)Serial.read();
        if (ch == '\n' || ch == '\r') {
            if (lineLen > 0) {
                lineBuf[lineLen] = '\0';
                handleLine(lineBuf);
                lineLen = 0;
            }
        } else if (lineLen < LINE_BUF_LEN - 1) {
            lineBuf[lineLen++] = ch;
        } else {
            // Overlong line — drop it and report, rather than silently
            // truncating into a command that means something else.
            lineLen = 0;
            Serial.println(F("err:too_long"));
        }
    }
}
