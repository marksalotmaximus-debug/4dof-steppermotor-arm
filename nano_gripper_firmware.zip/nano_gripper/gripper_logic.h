/*
 * gripper_logic.h — hardware-free logic for the Nano gripper controller.
 *
 * Everything in here is pure computation: no Serial, no Wire, no pin access.
 * That's deliberate — the sketch (nano_gripper.ino) includes this for the
 * real firmware, and a desktop g++ harness includes the exact same file to
 * unit-test the maths and the command parser. Same source of truth, so a
 * passing test actually says something about the code you flash.
 *
 * Covers:
 *   - PCA9685 prescale + angle -> PWM count conversion
 *   - servo travel limiting
 *   - non-blocking move interpolation (smoothstep easing)
 *   - the ASCII serial command parser
 */

#ifndef GRIPPER_LOGIC_H
#define GRIPPER_LOGIC_H

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

// --------------------------------------------------------------------------
// Fixed characteristics
// --------------------------------------------------------------------------

// PCA9685 runs from a 25MHz internal oscillator and divides its 12-bit
// (4096-step) PWM counter by (prescale + 1).
#define PCA9685_OSC_HZ      25000000.0f
#define PCA9685_STEPS       4096.0f

// Servos want a ~50Hz frame (20ms period).
#define SERVO_FREQ_HZ       50.0f
#define SERVO_PERIOD_US     (1000000.0f / SERVO_FREQ_HZ)   // 20000us

// Angle range a standard hobby servo maps its pulse range across.
#define SERVO_SWEEP_DEG     180.0f


// --------------------------------------------------------------------------
// PCA9685 timing
// --------------------------------------------------------------------------

/*
 * Prescale value for a target PWM frequency, per the PCA9685 datasheet:
 *   prescale = round( osc / (4096 * freq) ) - 1
 * At 50Hz this comes out to 121.
 */
inline uint8_t pca9685Prescale(float freqHz) {
    float value = (PCA9685_OSC_HZ / (PCA9685_STEPS * freqHz)) - 1.0f;
    if (value < 3.0f)   value = 3.0f;      // datasheet minimum
    if (value > 255.0f) value = 255.0f;
    return (uint8_t)(value + 0.5f);
}

/*
 * Convert a pulse width in microseconds into a PCA9685 "off" tick count.
 * The channel turns on at tick 0 and off at the returned tick, so the tick
 * count is just the pulse's share of the 20ms frame scaled to 4096 steps.
 */
inline uint16_t pulseUsToCount(float pulseUs) {
    if (pulseUs < 0.0f) pulseUs = 0.0f;
    float count = pulseUs * PCA9685_STEPS / SERVO_PERIOD_US;
    if (count > 4095.0f) count = 4095.0f;
    return (uint16_t)(count + 0.5f);
}


// --------------------------------------------------------------------------
// Angle handling
// --------------------------------------------------------------------------

inline float clampf(float v, float lo, float hi) {
    if (lo > hi) { float t = lo; lo = hi; hi = t; }
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

/*
 * Map a servo angle to a pulse width.
 *
 * The 0..180 sweep always maps linearly across [minPulseUs, maxPulseUs] —
 * that's the servo's physical characteristic and doesn't change. minAngle /
 * maxAngle are *travel limits* applied on top, so you can stop the gripper
 * closing past the point where the fingers bind without distorting the rest
 * of the scale.
 *
 * Clamping here (not just in the app) is deliberate: a servo driven into a
 * mechanical stop stalls and will cook itself, so the firmware refuses
 * out-of-range angles even if the host asks for them.
 */
inline float angleToPulseUs(float angle, float minAngle, float maxAngle,
                            float minPulseUs, float maxPulseUs) {
    angle = clampf(angle, minAngle, maxAngle);
    angle = clampf(angle, 0.0f, SERVO_SWEEP_DEG);
    float t = angle / SERVO_SWEEP_DEG;
    return minPulseUs + t * (maxPulseUs - minPulseUs);
}

inline uint16_t angleToCount(float angle, float minAngle, float maxAngle,
                             float minPulseUs, float maxPulseUs) {
    return pulseUsToCount(angleToPulseUs(angle, minAngle, maxAngle,
                                         minPulseUs, maxPulseUs));
}


// --------------------------------------------------------------------------
// Move interpolation
// --------------------------------------------------------------------------

/*
 * Smoothstep easing: 3t^2 - 2t^3. Zero velocity at both ends, so the servo
 * eases in and out instead of slamming. Gentler on the Fin Ray fingers,
 * avoids the current spike of a full-speed snap, and looks far better on
 * video than a step change.
 */
inline float easeSmooth(float t) {
    t = clampf(t, 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

/*
 * Duration for a move, from a sweep rate in degrees/second. Returns at least
 * 1ms so a zero-distance move can't produce a divide-by-zero downstream.
 */
inline uint32_t moveDurationMs(float fromAngle, float toAngle, float degPerSec) {
    if (degPerSec <= 0.0f) return 1;
    float delta = fabsf(toAngle - fromAngle);
    float ms = (delta / degPerSec) * 1000.0f;
    if (ms < 1.0f) ms = 1.0f;
    if (ms > 60000.0f) ms = 60000.0f;      // sanity ceiling
    return (uint32_t)(ms + 0.5f);
}

/*
 * Interpolated position at `elapsed` ms into a move. Returns the target once
 * the move is complete, so callers can compare against target to detect
 * "arrived" without tracking a separate flag.
 */
inline float interpolateAngle(float startAngle, float targetAngle,
                              uint32_t elapsedMs, uint32_t durationMs) {
    if (durationMs == 0 || elapsedMs >= durationMs) return targetAngle;
    float t = (float)elapsedMs / (float)durationMs;
    return startAngle + (targetAngle - startAngle) * easeSmooth(t);
}


// --------------------------------------------------------------------------
// Command parser
// --------------------------------------------------------------------------

/*
 * Wire format: one ASCII command per line, '\n' terminated. Case-insensitive.
 * An optional "@<n> " prefix targets a servo channel; without it, channel 0.
 *
 *   V?                 identify
 *   ?                  status
 *   A[angle]           attach (optionally declaring assumed current angle)
 *   D                  detach — servo goes limp
 *   O / C              go to the open / close preset
 *   S<angle>           move to angle at the default rate
 *   S<angle> T<ms>     move to angle over an explicit duration
 *   R<degPerSec>       set default sweep rate
 *   L<min> <max>       set travel limits
 *   E<open> <close>    set the open / close presets
 *   U<minUs> <maxUs>   set the servo's pulse-width range
 *   X / Z              emergency output disable / re-enable
 *   H                  help
 *
 * Kept human-readable on purpose: you can drive the whole board from a serial
 * monitor to bring up the hardware before any app code exists.
 */

struct ParsedCommand {
    char  cmd;        // primary letter, uppercased; 0 if unparseable
    bool  query;      // command was followed by '?'
    int   channel;    // -1 when no @n prefix was given
    float arg1;
    float arg2;
    bool  hasArg1;
    bool  hasArg2;
    bool  valid;
};

inline bool isSpaceChar(char c) { return c == ' ' || c == '\t'; }

inline char toUpperChar(char c) {
    if (c >= 'a' && c <= 'z') return (char)(c - 'a' + 'A');
    return c;
}

/*
 * Parse one line into a ParsedCommand. Tolerant of leading/trailing spaces,
 * mixed case, and CR from CRLF line endings.
 */
inline ParsedCommand parseCommand(const char *line) {
    ParsedCommand out;
    out.cmd = 0;
    out.query = false;
    out.channel = -1;
    out.arg1 = 0.0f;
    out.arg2 = 0.0f;
    out.hasArg1 = false;
    out.hasArg2 = false;
    out.valid = false;

    if (line == 0) return out;

    const char *p = line;
    while (*p && (isSpaceChar(*p) || *p == '\r' || *p == '\n')) p++;

    // Optional "@<n>" channel prefix.
    if (*p == '@') {
        p++;
        if (*p < '0' || *p > '9') return out;     // '@' with no number
        out.channel = 0;
        while (*p >= '0' && *p <= '9') {
            out.channel = out.channel * 10 + (*p - '0');
            p++;
        }
        while (*p && isSpaceChar(*p)) p++;
    }

    if (*p == 0 || *p == '\r' || *p == '\n') return out;   // nothing left

    out.cmd = toUpperChar(*p);
    p++;

    if (*p == '?') {
        out.query = true;
        p++;
    }

    // Up to two numeric arguments, whitespace separated. Also tolerates the
    // "T" marker in "S90 T500" by skipping any letter that precedes a number.
    for (int i = 0; i < 2; i++) {
        while (*p && isSpaceChar(*p)) p++;
        if (*p == 0 || *p == '\r' || *p == '\n') break;

        if (toUpperChar(*p) == 'T' || toUpperChar(*p) == 'C') p++;   // marker
        while (*p && isSpaceChar(*p)) p++;

        bool numeric = (*p == '-' || *p == '+' || *p == '.' ||
                        (*p >= '0' && *p <= '9'));
        if (!numeric) break;

        char *endp = 0;
        float v = (float)strtod(p, &endp);
        if (endp == p) break;
        p = endp;

        if (i == 0) { out.arg1 = v; out.hasArg1 = true; }
        else        { out.arg2 = v; out.hasArg2 = true; }
    }

    out.valid = (out.cmd != 0);
    return out;
}

#endif  // GRIPPER_LOGIC_H
